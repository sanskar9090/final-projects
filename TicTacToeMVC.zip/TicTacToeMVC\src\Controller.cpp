#include "ttt/Controller.hpp"

#include <iostream>
#include <ostream>
#include <stdexcept>
#include <string>
#include <utility>

namespace ttt {

void ConsoleView::draw(const Board& board) const {
    output_ << "\n";
    for (int row = 0; row < board.size(); ++row) {
        for (int col = 0; col < board.size(); ++col) {
            output_ << ' ' << board.at(row, col) << ' ';
            if (col + 1 < board.size()) {
                output_ << '|';
            }
        }
        output_ << '\n';
        if (row + 1 < board.size()) {
            for (int col = 0; col < board.size(); ++col) {
                output_ << "---";
                if (col + 1 < board.size()) {
                    output_ << '+';
                }
            }
            output_ << '\n';
        }
    }
    output_ << '\n';
}

void ConsoleView::showMessage(const char* message) const {
    output_ << message << '\n';
}

bool ConsoleView::askMove(const Board& board, std::istream& input, int& row, int& col) const {
    output_ << "Enter row and column (0-" << board.size() - 1 << "): ";
    return static_cast<bool>(input >> row >> col);
}

GameController::GameController(Board board, std::ostream& output, std::istream& input,
                               int aiDepth, std::unique_ptr<NetworkPeer> network)
    : board_(std::move(board)), view_(output), input_(input), ai_(aiDepth),
      network_(std::move(network)) {}

void GameController::run() {
    char current = 'X';
    const char localMark = network_ ? network_->localMark() : 'X';
    while (true) {
        view_.draw(board_);
        int row = -1;
        int col = -1;
        if (network_ && current != localMark) {
            view_.showMessage("Waiting for the other player...");
            network_->receiveMove(row, col);
        } else if (!network_ && current == 'O') {
            const auto move = ai_.chooseMove(board_, 'O');
            row = move.row;
            col = move.col;
            view_.showMessage("Computer is thinking...");
        } else {
            if (!view_.askMove(board_, input_, row, col)) {
                throw std::runtime_error("Input ended before the game finished.");
            }
        }

        if (!board_.play(row, col, current)) {
            if (network_ && current != localMark) {
                throw std::runtime_error("The network peer sent an illegal move.");
            }
            view_.showMessage("Invalid move. Try again.");
            continue;
        }
        if (network_ && current == localMark) {
            network_->sendMove(row, col);
        }
        if (board_.hasWon(current)) {
            view_.draw(board_);
            const std::string message = std::string("Player ") + current + " wins!";
            view_.showMessage(message.c_str());
            return;
        }
        if (board_.isFull()) {
            view_.draw(board_);
            view_.showMessage("It's a draw!");
            return;
        }
        current = current == 'X' ? 'O' : 'X';
    }
}

} // namespace ttt
