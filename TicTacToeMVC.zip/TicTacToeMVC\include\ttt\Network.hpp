#pragma once

#include <cstdint>
#include <memory>
#include <string>

namespace ttt {

struct NetworkConfig {
    int boardSize;
    int connect;
};

class NetworkPeer {
public:
    enum class Role { Host, Join };

    NetworkPeer(Role role, const std::string& host, std::uint16_t port,
                NetworkConfig hostConfig);
    ~NetworkPeer();

    NetworkPeer(const NetworkPeer&) = delete;
    NetworkPeer& operator=(const NetworkPeer&) = delete;

    char localMark() const noexcept { return localMark_; }
    NetworkConfig config() const noexcept { return config_; }
    void sendMove(int row, int col);
    bool receiveMove(int& row, int& col);

private:
    struct Impl;
    std::unique_ptr<Impl> impl_;
    char localMark_;
    NetworkConfig config_;
};

} // namespace ttt
