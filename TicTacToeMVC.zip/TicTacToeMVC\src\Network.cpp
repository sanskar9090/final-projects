#include "ttt/Network.hpp"

#include <limits>
#include <stdexcept>
#include <cstring>

#ifdef _WIN32
#ifndef NOMINMAX
#define NOMINMAX
#endif
#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0600
#endif
#include <winsock2.h>
#include <ws2tcpip.h>
#else
#include <netdb.h>
#include <sys/socket.h>
#include <unistd.h>
#endif

namespace ttt {
namespace {

#ifdef _WIN32
using Socket = SOCKET;
constexpr Socket InvalidSocket = INVALID_SOCKET;
void closeSocket(Socket socket) {
    if (socket != InvalidSocket) {
        closesocket(socket);
    }
}
class SocketRuntime {
public:
    SocketRuntime() {
        WSADATA data{};
        if (WSAStartup(MAKEWORD(2, 2), &data) != 0) {
            throw std::runtime_error("Winsock initialization failed.");
        }
    }
    ~SocketRuntime() { WSACleanup(); }
};
#else
using Socket = int;
constexpr Socket InvalidSocket = -1;
void closeSocket(Socket socket) {
    if (socket != InvalidSocket) {
        ::close(socket);
    }
}
class SocketRuntime {};
#endif

struct SocketHandle {
    Socket value = InvalidSocket;
    ~SocketHandle() { closeSocket(value); }
    SocketHandle() = default;
    explicit SocketHandle(Socket socket) : value(socket) {}
    SocketHandle(const SocketHandle&) = delete;
    SocketHandle& operator=(const SocketHandle&) = delete;
    SocketHandle(SocketHandle&& other) noexcept : value(other.value) {
        other.value = InvalidSocket;
    }
    SocketHandle& operator=(SocketHandle&& other) noexcept {
        if (this != &other) {
            closeSocket(value);
            value = other.value;
            other.value = InvalidSocket;
        }
        return *this;
    }
};

void sendAll(Socket socket, const std::string& text) {
    std::size_t sent = 0;
    while (sent < text.size()) {
#ifdef _WIN32
        const int result = ::send(socket, text.data() + sent,
                                  static_cast<int>(text.size() - sent), 0);
#else
        const auto result = ::send(socket, text.data() + sent, text.size() - sent, 0);
#endif
        if (result <= 0) {
            throw std::runtime_error("Network send failed or peer disconnected.");
        }
        sent += static_cast<std::size_t>(result);
    }
}

std::string receiveLine(Socket socket) {
    std::string line;
    char ch = '\0';
    while (line.size() < 128) {
#ifdef _WIN32
        const int result = ::recv(socket, &ch, 1, 0);
#else
        const auto result = ::recv(socket, &ch, 1, 0);
#endif
        if (result <= 0) {
            throw std::runtime_error("Network peer disconnected while sending a message.");
        }
        if (ch == '\n') {
            return line;
        }
        if (ch != '\r') {
            line.push_back(ch);
        }
    }
    throw std::runtime_error("Received an overlong network message.");
}

bool parsePair(const std::string& text, int& first, int& second) {
    const auto separator = text.find(' ');
    if (separator == std::string::npos) {
        return false;
    }
    const auto parseNumber = [](const std::string& value, int& result) {
        if (value.empty()) {
            return false;
        }
        int parsed = 0;
        for (char ch : value) {
            if (ch < '0' || ch > '9') {
                return false;
            }
            const int digit = ch - '0';
            if (parsed > (std::numeric_limits<int>::max() - digit) / 10) {
                return false;
            }
            parsed = parsed * 10 + digit;
        }
        result = parsed;
        return true;
    };
    return parseNumber(text.substr(0, separator), first) &&
           parseNumber(text.substr(separator + 1), second);
}

SocketHandle connectTo(const std::string& host, std::uint16_t port) {
    hostent* resolved = gethostbyname(host.c_str());
    if (resolved == nullptr || resolved->h_addr_list == nullptr ||
        resolved->h_addr_list[0] == nullptr) {
        throw std::runtime_error("Could not resolve the host name.");
    }
    SocketHandle connection(::socket(AF_INET, SOCK_STREAM, 0));
    if (connection.value == InvalidSocket) {
        throw std::runtime_error("Could not create the client socket.");
    }
    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_port = htons(port);
    std::memcpy(&address.sin_addr, resolved->h_addr_list[0],
                static_cast<std::size_t>(resolved->h_length));
    if (::connect(connection.value, reinterpret_cast<sockaddr*>(&address),
                  static_cast<int>(sizeof(address))) != 0) {
        throw std::runtime_error("Could not connect to the host.");
    }
    return connection;
}

SocketHandle acceptOne(std::uint16_t port) {
    SocketHandle listener(::socket(AF_INET, SOCK_STREAM, 0));
    if (listener.value == InvalidSocket) {
        throw std::runtime_error("Could not create the listening socket.");
    }
    int yes = 1;
    setsockopt(listener.value, SOL_SOCKET, SO_REUSEADDR,
               reinterpret_cast<const char*>(&yes), sizeof(yes));

    sockaddr_in address{};
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(port);
    if (::bind(listener.value, reinterpret_cast<sockaddr*>(&address), sizeof(address)) != 0 ||
        ::listen(listener.value, 1) != 0) {
        throw std::runtime_error("Could not bind/listen; check the port and firewall.");
    }
    Socket accepted = ::accept(listener.value, nullptr, nullptr);
    if (accepted == InvalidSocket) {
        throw std::runtime_error("Accepting the network player failed.");
    }
    return SocketHandle(accepted);
}

} // namespace

struct NetworkPeer::Impl {
    SocketRuntime runtime;
    SocketHandle connection;

    Impl(Role role, const std::string& host, std::uint16_t port, NetworkConfig& config) {
        if (role == Role::Host) {
            connection = acceptOne(port);
            sendAll(connection.value, "CONFIG " + std::to_string(config.boardSize) + " " +
                                         std::to_string(config.connect) + "\n");
        } else {
            connection = connectTo(host, port);
            const std::string line = receiveLine(connection.value);
            int size = 0;
            int connectLength = 0;
            if (line.compare(0, 7, "CONFIG ") != 0 ||
                !parsePair(line.substr(7), size, connectLength) ||
                size < 1 || size > 30 || connectLength < 1 || connectLength > size) {
                throw std::runtime_error("Host sent invalid board settings.");
            }
            config = {size, connectLength};
        }
    }

    void send(int row, int col) {
        sendAll(connection.value, "MOVE " + std::to_string(row) + " " +
                                      std::to_string(col) + "\n");
    }

    bool receive(int& row, int& col) {
        const std::string line = receiveLine(connection.value);
        if (line.compare(0, 5, "MOVE ") != 0 ||
            !parsePair(line.substr(5), row, col)) {
            throw std::runtime_error("Received an invalid move from the network peer.");
        }
        return true;
    }
};

NetworkPeer::NetworkPeer(Role role, const std::string& host, std::uint16_t port,
                         NetworkConfig hostConfig)
    : impl_(std::make_unique<Impl>(role, host, port, hostConfig)),
      localMark_(role == Role::Host ? 'X' : 'O'), config_(hostConfig) {}

NetworkPeer::~NetworkPeer() = default;

void NetworkPeer::sendMove(int row, int col) {
    impl_->send(row, col);
}

bool NetworkPeer::receiveMove(int& row, int& col) {
    return impl_->receive(row, col);
}

} // namespace ttt
