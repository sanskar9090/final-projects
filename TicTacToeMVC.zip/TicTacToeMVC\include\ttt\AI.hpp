#pragma once

#include "ttt/Board.hpp"

namespace ttt {

struct SearchResult {
    int row;
    int col;
    int score;
};

class AI {
public:
    explicit AI(int depth = 4, int candidateLimit = 16);
    SearchResult chooseMove(const Board& board, char aiMark) const;

private:
    int depth_;
    int candidateLimit_;
};

} // namespace ttt
