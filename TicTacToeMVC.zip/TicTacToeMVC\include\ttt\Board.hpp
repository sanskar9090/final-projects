#pragma once

#include <cstddef>
#include <vector>

namespace ttt {

class Board {
public:
    Board(int size, int connect);

    int size() const noexcept { return size_; }
    int connect() const noexcept { return connect_; }
    char at(int row, int col) const;
    bool isLegal(int row, int col) const noexcept;
    bool play(int row, int col, char mark);
    bool isFull() const noexcept;
    bool hasWon(char mark) const noexcept;
    int emptyCount() const noexcept;
    const std::vector<char>& cells() const noexcept { return cells_; }

private:
    int size_;
    int connect_;
    std::vector<char> cells_;
};

} // namespace ttt
