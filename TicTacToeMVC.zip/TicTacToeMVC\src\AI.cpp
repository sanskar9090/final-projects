#include "ttt/AI.hpp"

#include <algorithm>
#include <cmath>
#include <limits>
#include <stdexcept>
#include <vector>

namespace ttt {
namespace {

constexpr int WinScore = 1'000'000;

char other(char mark) {
    return mark == 'X' ? 'O' : 'X';
}

int evaluate(const Board& board, char perspective) {
    if (board.hasWon(perspective)) {
        return WinScore;
    }
    if (board.hasWon(other(perspective))) {
        return -WinScore;
    }

    int score = 0;
    const int n = board.size();
    const int k = board.connect();
    constexpr int directions[4][2] = {{0, 1}, {1, 0}, {1, 1}, {1, -1}};
    for (int row = 0; row < n; ++row) {
        for (int col = 0; col < n; ++col) {
            for (const auto& direction : directions) {
                const int endRow = row + (k - 1) * direction[0];
                const int endCol = col + (k - 1) * direction[1];
                if (endRow < 0 || endRow >= n || endCol < 0 || endCol >= n) {
                    continue;
                }
                int own = 0;
                int opponent = 0;
                for (int offset = 0; offset < k; ++offset) {
                    const char cell = board.at(row + offset * direction[0],
                                               col + offset * direction[1]);
                    own += cell == perspective ? 1 : 0;
                    opponent += cell == other(perspective) ? 1 : 0;
                }
                if (own != 0 && opponent != 0) {
                    continue;
                }
                const int pieces = own != 0 ? own : opponent;
                if (pieces == 0) {
                    continue;
                }
                int value = 1;
                for (int i = 0; i < pieces; ++i) {
                    value = std::min(value * 8, WinScore / 4);
                }
                score += own != 0 ? value : -value;
                if (score > WinScore / 2) {
                    score = WinScore / 2;
                } else if (score < -WinScore / 2) {
                    score = -WinScore / 2;
                }
            }
        }
    }
    return score;
}

std::vector<std::pair<int, int>> candidates(const Board& board, int limit) {
    std::vector<std::pair<int, int>> moves;
    const int n = board.size();
    const int radius = std::min(board.connect(), 3);
    const int center = n / 2;
    const auto& cells = board.cells();
    bool hasPiece = false;
    for (char cell : cells) {
        hasPiece = hasPiece || cell != ' ';
    }
    if (!hasPiece) {
        moves.emplace_back(center, center);
        return moves;
    }

    std::vector<bool> considered(cells.size(), false);
    for (int row = 0; row < n; ++row) {
        for (int col = 0; col < n; ++col) {
            if (cells[static_cast<std::size_t>(row) * n + col] == ' ') {
                continue;
            }
            for (int dr = -radius; dr <= radius; ++dr) {
                for (int dc = -radius; dc <= radius; ++dc) {
                    const int r = row + dr;
                    const int c = col + dc;
                    if (board.isLegal(r, c)) {
                        considered[static_cast<std::size_t>(r) * n + c] = true;
                    }
                }
            }
        }
    }

    for (int row = 0; row < n; ++row) {
        for (int col = 0; col < n; ++col) {
            const auto index = static_cast<std::size_t>(row) * n + col;
            if (considered[index]) {
                moves.emplace_back(row, col);
            }
        }
    }
    std::sort(moves.begin(), moves.end(), [center](const auto& a, const auto& b) {
        const int da = std::abs(a.first - center) + std::abs(a.second - center);
        const int db = std::abs(b.first - center) + std::abs(b.second - center);
        return da < db;
    });
    if (moves.size() > static_cast<std::size_t>(limit)) {
        moves.resize(static_cast<std::size_t>(limit));
    }
    return moves;
}

int search(const Board& board, char toMove, char aiMark, int depth, int alpha, int beta) {
    if (board.hasWon(aiMark)) {
        return WinScore + depth;
    }
    if (board.hasWon(other(aiMark))) {
        return -WinScore - depth;
    }
    if (depth == 0 || board.isFull()) {
        return evaluate(board, aiMark);
    }

    const auto moves = candidates(board, 16);
    if (moves.empty()) {
        return evaluate(board, aiMark);
    }
    const bool maximizing = toMove == aiMark;
    int best = maximizing ? std::numeric_limits<int>::min() : std::numeric_limits<int>::max();
    for (const auto& move : moves) {
        Board next = board;
        next.play(move.first, move.second, toMove);
        const int score = search(next, other(toMove), aiMark, depth - 1, alpha, beta);
        if (maximizing) {
            best = std::max(best, score);
            alpha = std::max(alpha, best);
        } else {
            best = std::min(best, score);
            beta = std::min(beta, best);
        }
        if (beta <= alpha) {
            break;
        }
    }
    return best;
}

} // namespace

AI::AI(int depth, int candidateLimit) : depth_(depth), candidateLimit_(candidateLimit) {
    if (depth < 1 || depth > 10 || candidateLimit < 1 || candidateLimit > 64) {
        throw std::invalid_argument("AI depth must be 1..10 and candidate limit must be 1..64.");
    }
}

SearchResult AI::chooseMove(const Board& board, char aiMark) const {
    if (aiMark != 'X' && aiMark != 'O') {
        throw std::invalid_argument("AI mark must be X or O.");
    }
    auto moves = candidates(board, candidateLimit_);
    if (moves.empty()) {
        throw std::runtime_error("AI was asked to move on a full board.");
    }
    int bestScore = std::numeric_limits<int>::min();
    SearchResult best{moves.front().first, moves.front().second, bestScore};
    int alpha = std::numeric_limits<int>::min();
    const int beta = std::numeric_limits<int>::max();
    for (const auto& move : moves) {
        Board next = board;
        next.play(move.first, move.second, aiMark);
        const int score = search(next, other(aiMark), aiMark, depth_ - 1, alpha, beta);
        if (score > bestScore) {
            best = {move.first, move.second, score};
        }
        alpha = std::max(alpha, bestScore);
    }
    return best;
}

} // namespace ttt
