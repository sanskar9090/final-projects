#include "ttt/Controller.hpp"

#include <cstdlib>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <utility>

namespace {

struct Options {
    int size = 3;
    int connect = 3;
    int depth = 4;
    std::string mode = "ai";
    std::string host;
    std::uint16_t port = 5050;
};

int parseInt(const char* text, const char* option) {
    try {
        std::size_t parsed = 0;
        const int value = std::stoi(text, &parsed);
        if (parsed != std::string(text).size()) {
            throw std::invalid_argument("trailing characters");
        }
        return value;
    } catch (const std::exception&) {
        throw std::invalid_argument(std::string("Invalid value for ") + option + ".");
    }
}

Options parseOptions(int argc, char** argv) {
    Options options;
    for (int i = 1; i < argc; ++i) {
        const std::string key = argv[i];
        if (key == "--help") {
            std::cout << "Usage: tictactoe [--mode ai|host|join] [--size N] [--connect K]\n"
                         "                  [--depth D] [--host ADDRESS] [--port PORT]\n"
                         "Defaults: --mode ai --size 3 --connect 3 --depth 4 --port 5050\n"
                         "Host is X; joining player is O. Coordinates are zero-based.\n";
            std::exit(0);
        }
        if (i + 1 >= argc) {
            throw std::invalid_argument("Missing value for " + key + ".");
        }
        const char* value = argv[++i];
        if (key == "--mode") {
            options.mode = value;
        } else if (key == "--size") {
            options.size = parseInt(value, "--size");
        } else if (key == "--connect") {
            options.connect = parseInt(value, "--connect");
        } else if (key == "--depth") {
            options.depth = parseInt(value, "--depth");
        } else if (key == "--host") {
            options.host = value;
        } else if (key == "--port") {
            const int port = parseInt(value, "--port");
            if (port < 1 || port > 65535) {
                throw std::invalid_argument("Port must be in the range 1..65535.");
            }
            options.port = static_cast<std::uint16_t>(port);
        } else {
            throw std::invalid_argument("Unknown option: " + key);
        }
    }
    if (options.mode != "ai" && options.mode != "host" && options.mode != "join") {
        throw std::invalid_argument("Mode must be ai, host, or join.");
    }
    if (options.mode == "join" && options.host.empty()) {
        throw std::invalid_argument("Joining requires --host ADDRESS.");
    }
    return options;
}

} // namespace

int main(int argc, char** argv) {
    try {
        const Options options = parseOptions(argc, argv);
        std::unique_ptr<ttt::NetworkPeer> network;
        ttt::Board board(options.size, options.connect);
        if (options.mode == "host") {
            std::cout << "Waiting for a player on port " << options.port << "...\n";
            network = std::make_unique<ttt::NetworkPeer>(
                ttt::NetworkPeer::Role::Host, "", options.port,
                ttt::NetworkConfig{options.size, options.connect});
        } else if (options.mode == "join") {
            network = std::make_unique<ttt::NetworkPeer>(
                ttt::NetworkPeer::Role::Join, options.host, options.port,
                ttt::NetworkConfig{options.size, options.connect});
            const auto config = network->config();
            board = ttt::Board(config.boardSize, config.connect);
        }
        std::cout << "Welcome to configurable Tic-Tac-Toe. You are "
                  << (network ? network->localMark() : 'X') << ".\n";
        ttt::GameController game(std::move(board), std::cout, std::cin, options.depth,
                                 std::move(network));
        game.run();
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "Error: " << error.what() << '\n';
        return 1;
    }
}
