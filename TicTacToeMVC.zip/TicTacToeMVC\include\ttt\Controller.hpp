#pragma once

#include "ttt/AI.hpp"
#include "ttt/Board.hpp"
#include "ttt/Network.hpp"

#include <iosfwd>
#include <memory>

namespace ttt {

class ConsoleView {
public:
    explicit ConsoleView(std::ostream& output) : output_(output) {}
    void draw(const Board& board) const;
    void showMessage(const char* message) const;
    bool askMove(const Board& board, std::istream& input, int& row, int& col) const;

private:
    std::ostream& output_;
};

class GameController {
public:
    GameController(Board board, std::ostream& output, std::istream& input,
                   int aiDepth, std::unique_ptr<NetworkPeer> network = nullptr);
    void run();

private:
    Board board_;
    ConsoleView view_;
    std::istream& input_;
    AI ai_;
    std::unique_ptr<NetworkPeer> network_;
};

} // namespace ttt
