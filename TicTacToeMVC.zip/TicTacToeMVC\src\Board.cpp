#include "ttt/Board.hpp"

#include <stdexcept>

namespace ttt {

Board::Board(int size, int connect)
    : size_(size), connect_(connect) {
    if (size < 1 || size > 30 || connect < 1 || connect > size) {
        throw std::invalid_argument("Board size must be 1..30 and connect length must be 1..board size.");
    }
    cells_.resize(static_cast<std::size_t>(size) * size, ' ');
}

char Board::at(int row, int col) const {
    if (row < 0 || row >= size_ || col < 0 || col >= size_) {
        throw std::out_of_range("Board position is outside the board.");
    }
    return cells_[static_cast<std::size_t>(row) * size_ + col];
}

bool Board::isLegal(int row, int col) const noexcept {
    return row >= 0 && row < size_ && col >= 0 && col < size_ &&
           cells_[static_cast<std::size_t>(row) * size_ + col] == ' ';
}

bool Board::play(int row, int col, char mark) {
    if ((mark != 'X' && mark != 'O') || !isLegal(row, col)) {
        return false;
    }
    cells_[static_cast<std::size_t>(row) * size_ + col] = mark;
    return true;
}

bool Board::isFull() const noexcept {
    return emptyCount() == 0;
}

int Board::emptyCount() const noexcept {
    int count = 0;
    for (char cell : cells_) {
        count += cell == ' ' ? 1 : 0;
    }
    return count;
}

bool Board::hasWon(char mark) const noexcept {
    constexpr int directions[4][2] = {{0, 1}, {1, 0}, {1, 1}, {1, -1}};
    for (int row = 0; row < size_; ++row) {
        for (int col = 0; col < size_; ++col) {
            if (cells_[static_cast<std::size_t>(row) * size_ + col] != mark) {
                continue;
            }
            for (const auto& direction : directions) {
                const int endRow = row + (connect_ - 1) * direction[0];
                const int endCol = col + (connect_ - 1) * direction[1];
                if (endRow < 0 || endRow >= size_ || endCol < 0 || endCol >= size_) {
                    continue;
                }
                int matched = 1;
                while (matched < connect_ &&
                       cells_[static_cast<std::size_t>(row + matched * direction[0]) * size_ +
                              col + matched * direction[1]] == mark) {
                    ++matched;
                }
                if (matched == connect_) {
                    return true;
                }
            }
        }
    }
    return false;
}

} // namespace ttt
