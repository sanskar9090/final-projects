# TicTacToeMVC

A C++17 console Tic-Tac-Toe project structured around MVC, with configurable
N-by-N boards, a connect-K win condition, a minimax AI with alpha-beta pruning,
and TCP host/join multiplayer.

## Build

Requires CMake 3.16+ and a C++17 compiler. Windows uses Winsock; Linux/macOS use
POSIX sockets.

```powershell
cmake -S . -B build
cmake --build build --config Release
```

The executable is `build\Release\tictactoe.exe` with Visual Studio generators,
or `build\tictactoe.exe` with single-configuration Windows generators.

## Play against the computer

```powershell
.\build\tictactoe.exe
.\build\tictactoe.exe --size 5 --connect 4 --depth 4
```

You play X and the computer plays O. Coordinates start at zero. Board sizes
range from 1 to 30, connect length from 1 to board size, and AI depth from 1 to
10. The depth-limited search uses alpha-beta pruning and searches nearby empty
cells to keep larger-board play practical; the AI is a heuristic opponent, not
a guarantee of perfect play. Search positions use local board values and
standard C++ containers, with no manually managed game-state allocations.

## TCP multiplayer

Start the host first (host is X):

```powershell
.\build\tictactoe.exe --mode host --size 5 --connect 4 --port 5050
```

Join from the other machine (joining player is O):

```powershell
.\build\tictactoe.exe --mode join --host 192.168.1.20 --port 5050
```

The host's board settings are sent to the joining player. Allow the selected TCP
port through the host firewall. This is a small trusted-peer game protocol: it
does not encrypt or authenticate traffic.

## MVC layout

- `Board` is the game model and owns the board cells.
- `ConsoleView` renders the board and prompts for moves.
- `GameController` coordinates turns, win/draw checks, AI, and network moves.
- `AI` contains the heuristic minimax/alpha-beta search.
- `NetworkPeer` owns socket lifetime using RAII and exchanges newline-delimited
  configuration and move messages.
