import os
import zipfile

root = r"C:\Users\rawat\Documents\EnterpriseRAG-RBAC"
out = r"C:\Users\rawat\Documents\enterprise-rag-rbac.zip"

with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
    for folder, _, files in os.walk(root):
        for name in files:
            full = os.path.join(folder, name)
            if os.path.abspath(full) == os.path.abspath(out):
                continue
            rel = os.path.relpath(full, root)
            z.write(full, rel)

print(f"zip-created: {out}")
