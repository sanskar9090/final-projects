import numpy as np
from PIL import Image, ImageDraw, ImageFont
import imageio

OUT = "C:/Users/rawat/Documents/EnterpriseRAG-RBAC/enterprise-rag-demo-60s.mp4"
W, H = 1280, 720
FPS = 30
TOTAL_SECONDS = 60
FRAMES = FPS * TOTAL_SECONDS

font_title = ImageFont.truetype("C:/Windows/Fonts/arialbd.ttf", 50)
font_body = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 26)
font_small = ImageFont.truetype("C:/Windows/Fonts/arial.ttf", 18)


def make_frame(t):
    img = Image.new("RGB", (W, H), (9, 14, 30))
    d = ImageDraw.Draw(img)

    for y in range(H):
        ratio = y / H
        d.line((0, y, W, y), fill=(12 + int(24 * ratio), 18 + int(28 * ratio), 38 + int(42 * ratio)))

    d.text((60, 40), "Enterprise RAG Demo", fill=(255, 255, 255), font=font_title)
    d.text((60, 108), "RBAC + Guardrails + Internal Document Q&A", fill=(176, 220, 255), font=font_body)

    # panels
    for x1, y1, x2, y2, label, color in [
        (60, 170, 560, 280, "AUTH", (72, 136, 255)),
        (600, 170, 1210, 280, "CHAT / PROMPT", (26, 186, 116)),
        (60, 315, 560, 560, "ROLE FILTER", (247, 154, 76)),
        (600, 315, 1210, 560, "GUARDRAILS + RAGAS", (169, 117, 255)),
    ]:
        d.rounded_rectangle((x1, y1, x2, y2), radius=16, fill=(15, 24, 40), outline=color, width=2)
        d.text((x1 + 22, y1 + 14), label, fill=color, font=font_body)

    d.text((90, 205), "Email: finance@corp.local", fill=(255, 255, 255), font=font_body)
    d.text((90, 240), "Role: finance", fill=(152, 255, 182), font=font_body)

    # query
    q = 'What expense reimbursements require manager approval?'
    d.text((630, 214), q, fill=(220, 255, 225), font=font_small)
    d.text((630, 250), "Authorized set: finance policy", fill=(210, 228, 255), font=font_body)

    d.text((90, 355), "RBAC access rule:", fill=(255,255,255), font=font_body)
    d.text((90, 395), "- Finance role can only view finance documents", fill=(255,255,255), font=font_small)
    d.text((90, 430), "- Manager and admin roles retain broader access", fill=(255,255,255), font=font_small)
    d.text((90, 465), "- Contractor requests are filtered out", fill=(255,255,255), font=font_small)

    d.text((630, 355), "Guardrails:", fill=(255,255,255), font=font_body)
    d.text((630, 395), "- Prompt injection: blocked", fill=(255,255,255), font=font_small)
    d.text((630, 430), "- Sensitive data: SSN, API keys, cards redacted", fill=(255,255,255), font=font_small)
    d.text((630, 465), "- Output sanitization enabled", fill=(255,255,255), font=font_small)
    d.text((630, 500), "RAGAS-inspired evaluation: groundedness + risk summary", fill=(255,255,255), font=font_small)

    answer = "Reimbursements above $5,000 require manager approval and finance review."
    d.text((90, 518), answer, fill=(246, 235, 124), font=font_body)
    d.text((630, 530), "Vector store: Chroma + Qdrant-ready metadata", fill=(195, 206, 255), font=font_small)

    d.rounded_rectangle((60, 600, 1210, 675), radius=18, fill=(4, 10, 18), outline=(106, 158, 255), width=2)
    d.text((90, 622), "Operations shown: login, RBAC filtering, prompt-injection blocking, redaction, and internal doc answer generation.", fill=(255,255,255), font=font_small)
    return np.array(img)

frames = [make_frame(i / FPS) for i in range(FRAMES)]
writer = imageio.get_writer(OUT, fps=FPS, codec='libx264', quality=8)
for frame in frames:
    writer.append_data(frame)
writer.close()
print(f"Created: {OUT}")
