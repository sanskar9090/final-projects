# Finance Policy

## Expense Authorization

- Expense reimbursements above $5,000 require manager approval and finance review.
- Travel bookings must be aligned with the annual travel budget.
- All reimbursements must include itemized receipts and project codes.

## Sensitive Financial Data

- Payroll and bank routing numbers must only be discussed by finance-approved roles.
- Finance and admin users can review annual spend, but contractors may not access full transactional data.
- Disallowed: external sharing of accounting reports beyond enterprise-approved channels.
