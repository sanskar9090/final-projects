# Sales Enablement Guide

## Approved Messaging

- Sales teams may reference approved product capabilities and pricing ranges.
- Customer-facing claims require review from marketing or legal before publication.
- Confidential customer references should be shared only as approved in the CRM.

## CRM Access Rules

- Sales representatives can access customer meeting notes and opportunity data.
- Managers can review forecast summaries and strategic accounts.
- Contractors cannot view customer support notes or internal pricing.
