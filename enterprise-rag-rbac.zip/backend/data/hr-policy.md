# HR Workplace Policy

## Access and Data Handling

- Human resources content is accessible to the HR role, managers, and administrators.
- Employee records should only be discussed with authorized HR personnel.
- If an employee requests a leave accommodation, managers should route the request to HR review.

## Employee Conduct

- Respect workplace security and privacy policies.
- Do not share payroll-related information outside of HR-approved workflows.
- Complaints should be escalated to the HR manager and documented in the case system.
