from __future__ import annotations

from typing import Any

ROLE_PERMISSIONS = {
    "admin": {"all"},
    "manager": {"hr", "finance", "security", "sales", "engineering"},
    "finance": {"finance"},
    "hr": {"hr"},
    "engineering": {"engineering", "security"},
    "sales": {"sales"},
    "contractor": {"engineering"},
}

USER_DB = {
    "admin@corp.local": {"password": "admin123", "role": "admin", "name": "Alicia Chen"},
    "finance@corp.local": {"password": "finance123", "role": "finance", "name": "Daniel Ortiz"},
    "hr@corp.local": {"password": "hr123", "role": "hr", "name": "Priya Nair"},
    "eng@corp.local": {"password": "eng123", "role": "engineering", "name": "Leo Martin"},
    "sales@corp.local": {"password": "sales123", "role": "sales", "name": "Mia Simmons"},
    "contractor@corp.local": {"password": "contractor123", "role": "contractor", "name": "Ravi Shah"},
}


def get_allowed_categories(role: str) -> set[str]:
    return ROLE_PERMISSIONS.get(role.lower(), set())


def is_role_allowed(role: str, categories: set[str] | list[str] | None) -> bool:
    if not categories:
        return True
    allowed = set(categories)
    role_permissions = get_allowed_categories(role)
    if "all" in role_permissions:
        return True
    return bool(allowed & role_permissions)


def filter_documents_for_role(documents: list[Any], role: str) -> list[Any]:
    allowed: set[str] = get_allowed_categories(role)
    if "all" in allowed:
        return documents
    filtered = []
    for doc in documents:
        meta = getattr(doc, "metadata", {}) or {}
        doc_categories = set(meta.get("categories", []))
        if not doc_categories:
            doc_categories = {meta.get("category")}
        if doc_categories & allowed:
            filtered.append(doc)
    return filtered
