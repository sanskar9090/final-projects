from __future__ import annotations

from pathlib import Path

from langchain.schema import Document

from .config import PROJECT_ROOT
from .vector_store import add_documents_to_store


def infer_categories_from_filename(file_name: str) -> list[str]:
    lower = file_name.lower()
    categories = []
    if "hr" in lower:
        categories.append("hr")
    if "finance" in lower:
        categories.append("finance")
    if "security" in lower or "engineering" in lower:
        categories.append("security")
        categories.append("engineering")
    if "sales" in lower:
        categories.append("sales")
    if not categories:
        categories = ["general"]
    return categories


def load_documents(data_dir: str | Path | None = None) -> list[Document]:
    root = Path(data_dir) if data_dir else PROJECT_ROOT / "backend" / "data"
    docs = []
    for path in sorted(root.glob("*.md")):
        text = path.read_text(encoding="utf-8")
        categories = infer_categories_from_filename(path.name)
        docs.append(
            Document(
                page_content=text,
                metadata={
                    "source": str(path.name),
                    "category": categories[0],
                    "categories": categories,
                    "allowed_roles": ["admin", "manager", *categories],
                },
            )
        )
    return docs


def bulk_ingest(data_dir: str | Path | None = None):
    docs = load_documents(data_dir)
    return add_documents_to_store(docs)
