"""Enterprise RAG RBAC package."""
