from __future__ import annotations

from pydantic import BaseModel, Field


class LoginRequest(BaseModel):
    email: str
    password: str


class QueryRequest(BaseModel):
    question: str = Field(..., min_length=4, max_length=2000)


class QueryResponse(BaseModel):
    answer: str
    role: str
    allowed_categories: list[str]
    citations: list[str]
    blocked: bool = False
    guardrail_issues: list[str] = []


class HealthResponse(BaseModel):
    status: str
    service: str
