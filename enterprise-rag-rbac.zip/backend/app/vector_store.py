from __future__ import annotations

from pathlib import Path

from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import Chroma

from .config import get_settings

settings = get_settings()


def build_embedding_model():
    return HuggingFaceEmbeddings(model_name="sentence-transformers/all-MiniLM-L6-v2")


def get_vector_store():
    embedding_model = build_embedding_model()
    path = Path(settings.chroma_path)
    path.mkdir(parents=True, exist_ok=True)
    return Chroma(
        collection_name="enterprise-corp-docs",
        embedding_function=embedding_model,
        persist_directory=str(path),
    )


def split_documents(documents: list[Document]) -> list[Document]:
    splitter = RecursiveCharacterTextSplitter(chunk_size=700, chunk_overlap=120, separators=["\n\n", "\n", ". ", " "])
    chunks = []
    for doc in documents:
        for chunk in splitter.split_documents([doc]):
            meta = dict(doc.metadata)
            meta.setdefault("categories", meta.get("category", "general"))
            chunk.metadata = meta
            chunks.append(chunk)
    return chunks


def add_documents_to_store(documents: list[Document]):
    store = get_vector_store()
    chunks = split_documents(documents)
    if chunks:
        store.add_documents(chunks)
        store.persist()
    return store
