from __future__ import annotations

import re
from typing import List

SENSITIVE_PATTERNS = [
    re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    re.compile(r"\b(?:\d[ -]?){13,19}\b"),
    re.compile(r"(?i)sk-[A-Za-z0-9]{20,}"),
    re.compile(r"(?i)AKIA[0-9A-Z]{16}"),
    re.compile(r"(?i)aws_secret_access_key"),
    re.compile(r"(?i)password\s*[:=]\s*\S+"),
    re.compile(r"(?i)api[_ -]?key\s*[:=]\s*\S+"),
    re.compile(r"\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b"),
]

PROMPT_INJECTION_PATTERNS = [
    r"ignore previous instructions",
    r"ignore all prior instructions",
    r"system prompt",
    r"developer prompt",
    r"act as",
    r"bypass safety",
    r"override policy",
    r"disregard the rules",
    r"jailbreak",
    r"reveal the hidden prompt",
]


class GuardrailResult:
    def __init__(self, allowed: bool, issues: list[str] | None = None):
        self.allowed = allowed
        self.issues = issues or []


def redact_sensitive_data(text: str) -> str:
    redacted = text
    for pattern in SENSITIVE_PATTERNS:
        redacted = pattern.sub("[REDACTED]", redacted)
    return redacted


def detect_sensitive_data(text: str) -> list[str]:
    issues = []
    for pattern in SENSITIVE_PATTERNS:
        if pattern.search(text):
            issues.append(f"Sensitive pattern matched: {pattern.pattern}")
    return issues


def check_prompt_injection(text: str) -> list[str]:
    issues = []
    lowered = text.lower()
    for pattern in PROMPT_INJECTION_PATTERNS:
        if re.search(pattern, lowered):
            issues.append(f"Potential prompt injection: {pattern}")
    return issues


class InputGuardrail:
    @staticmethod
    def validate(question: str) -> GuardrailResult:
        issues: List[str] = []
        issues.extend(check_prompt_injection(question))
        issues.extend(detect_sensitive_data(question))
        allowed = not issues
        return GuardrailResult(allowed=allowed, issues=issues)


class OutputGuardrail:
    @staticmethod
    def sanitize(answer: str) -> str:
        return redact_sensitive_data(answer)


class LlamaGuardProxy:
    def __init__(self, endpoint: str | None = None):
        self.endpoint = endpoint

    def check(self, text: str) -> GuardrailResult:
        if not self.endpoint:
            return InputGuardrail.validate(text)
        try:
            import requests

            payload = {"text": text}
            response = requests.post(self.endpoint, json=payload, timeout=10)
            response.raise_for_status()
            data = response.json()
            allowed = bool(data.get("allowed", True))
            issues = data.get("issues", [])
            return GuardrailResult(allowed=allowed, issues=issues)
        except Exception:
            return InputGuardrail.validate(text)
