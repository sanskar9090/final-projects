from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    app_name: str = "EnterpriseRAG"
    jwt_secret: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    data_dir: str = "./backend/data"
    chroma_path: str = "./vector_store/chroma"
    qdrant_url: str = "http://localhost:6333"
    use_qdrant: bool = False
    llama_guard_endpoint: str | None = None
    model_name: str = "meta-llama/Llama-Guard-3-8B"

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache
def get_settings() -> Settings:
    return Settings()


ROOT_DIR = Path(__file__).resolve().parents[2]
PROJECT_ROOT = ROOT_DIR
