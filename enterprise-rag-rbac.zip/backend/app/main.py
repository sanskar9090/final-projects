from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

import jwt
from fastapi import Depends, FastAPI, Header, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from langchain.schema import Document

from .auth import authenticate_user, create_token
from .config import get_settings
from .evaluate import evaluate_hallucination
from .guardrails import InputGuardrail, LlamaGuardProxy, OutputGuardrail
from .ingest import bulk_ingest, load_documents
from .rbac import filter_documents_for_role, get_allowed_categories
from .schemas import HealthResponse, LoginRequest, QueryRequest, QueryResponse
from .vector_store import get_vector_store

settings = get_settings()
app = FastAPI(title=settings.app_name, version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_current_user_from_token(authorization: str | None = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Missing bearer token")
    token = authorization.split(" ", 1)[1]
    try:
        payload = jwt.decode(token, settings.jwt_secret, algorithms=[settings.jwt_algorithm])
        return payload
    except jwt.PyJWTError as exc:  # pragma: no cover
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid token") from exc


@app.on_event("startup")
def startup_event():
    try:
        docs = load_documents(settings.data_dir)
        store = get_vector_store()
        if docs:
            store.add_documents([doc for doc in docs])
            store.persist()
    except Exception:
        pass


@app.get("/health", response_model=HealthResponse)
def health() -> HealthResponse:
    return HealthResponse(status="ok", service=settings.app_name)


@app.post("/api/login")
def login(payload: LoginRequest):
    user = authenticate_user(payload.email, payload.password)
    if not user:
        raise HTTPException(status_code=401, detail="Invalid credentials")
    token = create_token(user)
    return {
        "token": token,
        "role": user["role"],
        "name": user["name"],
        "allowed_categories": sorted(get_allowed_categories(user["role"])),
    }


@app.post("/api/query", response_model=QueryResponse)
def query(payload: QueryRequest, user=Depends(get_current_user_from_token)):
    role = user["role"]
    guard = InputGuardrail.validate(payload.question)
    if not guard.allowed:
        return QueryResponse(
            answer="Your query was blocked because it appears to contain a prompt injection or sensitive-data pattern.",
            role=role,
            allowed_categories=sorted(get_allowed_categories(role)),
            citations=[],
            blocked=True,
            guardrail_issues=guard.issues,
        )

    store = get_vector_store()
    raw_docs = store.similarity_search(payload.question, k=8)
    authorized = filter_documents_for_role(raw_docs, role)
    if not authorized:
        return QueryResponse(
            answer="No authorized internal documents were found for your role. Please ask within your permitted policy domain.",
            role=role,
            allowed_categories=sorted(get_allowed_categories(role)),
            citations=[],
            blocked=False,
            guardrail_issues=[],
        )

    answer_text = "\n\n".join(getattr(doc, "page_content", str(doc)) for doc in authorized[:3])
    answer_text = OutputGuardrail.sanitize(answer_text)
    citations = [doc.metadata.get("source", "internal-doc") for doc in authorized[:3]]
    eval_result = evaluate_hallucination(payload.question, answer_text, authorized[:3])
    llama_guard = LlamaGuardProxy(settings.llama_guard_endpoint)
    guard_after = llama_guard.check(payload.question)
    if not guard_after.allowed:
        return QueryResponse(
            answer="The request was refused by the model guardrail layer.",
            role=role,
            allowed_categories=sorted(get_allowed_categories(role)),
            citations=[],
            blocked=True,
            guardrail_issues=guard_after.issues,
        )

    return QueryResponse(
        answer=answer_text[:4000],
        role=role,
        allowed_categories=sorted(get_allowed_categories(role)),
        citations=citations,
        blocked=False,
        guardrail_issues=[f"Evaluation: {eval_result['hallucination_risk']}"] ,
    )


@app.post("/api/ingest")
def ingest(user=Depends(get_current_user_from_token)):
    if user["role"] != "admin":
        raise HTTPException(status_code=403, detail="Only admins can ingest documents")
    docs = load_documents(settings.data_dir)
    bulk_ingest(settings.data_dir)
    return {"status": "ok", "count": len(docs)}
