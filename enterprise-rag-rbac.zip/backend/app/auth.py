from __future__ import annotations

from datetime import datetime, timedelta, timezone

import jwt

from .config import get_settings
from .rbac import USER_DB

settings = get_settings()


def authenticate_user(email: str, password: str):
    user = USER_DB.get(email.lower())
    if not user:
        return None
    if user["password"] != password:
        return None
    return user


def create_token(user: dict) -> str:
    payload = {
        "sub": user["name"],
        "email": next((k for k, v in USER_DB.items() if v == user), ""),
        "role": user["role"],
        "exp": datetime.now(timezone.utc) + timedelta(hours=12),
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=settings.jwt_algorithm)
