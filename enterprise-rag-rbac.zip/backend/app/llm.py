from __future__ import annotations

from typing import Any


class SimpleRAGAnswerer:
    """Fallback answerer for a local Enterprise RAG demo."""

    def answer(self, question: str, contexts: list[Any], role: str) -> str:
        if not contexts:
            return (
                "I could not find authorized internal documents for your role. "
                "Please ask a question within your accessible policy areas or request access from an administrator."
            )

        joined_context = "\n\n".join(
            getattr(item, "page_content", str(item)) for item in contexts
        )
        answer = (
            "Based on the authorized internal documents available to the "
            f"{role} role, the best-supported answer is: \n\n"
            f"{joined_context[:1800]}"
        )

        if "policy" in question.lower() or "security" in question.lower():
            answer += "\n\nThis answer is limited to the internal policy set and should be validated against the official policy owner before action."
        return answer
