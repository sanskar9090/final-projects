from __future__ import annotations

from typing import Any


def evaluate_hallucination(question: str, answer: str, contexts: list[Any]) -> dict[str, Any]:
    """A lightweight RAGAS-style evaluation heuristic for demonstration purposes."""
    context_text = "\n".join(getattr(item, "page_content", str(item)) for item in contexts)
    answer_lower = answer.lower()
    context_lower = context_text.lower()

    grounded_tokens = sum(1 for token in question.lower().split() if token in context_lower)
    term_overlap = grounded_tokens / max(1, len(set(question.lower().split())))
    grounded = term_overlap >= 0.05 or len(context_text) > 0
    score = round(min(1.0, max(0.0, term_overlap * 2 + (0.2 if grounded else -0.1))), 3)
    return {
        "groundedness": score,
        "hallucination_risk": "low" if grounded else "high",
        "notes": "This is a lightweight heuristic; production systems should use ragas/LLM-as-judge metrics on a labeled benchmark.",
    }
