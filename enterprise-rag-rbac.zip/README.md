# Enterprise RAG with RBAC and Guardrails

This project is a production-oriented starter for a corporate internal document Q&A assistant. It combines:

- FastAPI backend
- LangChain + Chroma vector retrieval
- Optional Qdrant compatibility
- Role-based access control for document categories
- Input/output guardrails for prompt injection and sensitive data
- Streamlit dashboard and React UI
- Lightweight hallucination checks inspired by RAGAS

## Included features

- Secure login using JWT and role-based policies
- Restrict retrieval by user role and document category
- Block prompt-injection phrases and reveal-attempts
- Redact sensitive values such as SSNs, card numbers, API keys, and emails
- Query internal corporate documents with high-quality chunking
- Demonstrate enterprise guardrails and evaluation boundaries

## Role model

- admin: full access
- manager: view HR, finance, sales, security, engineering
- finance: finance only
- hr: HR only
- engineering: engineering + security
- sales: sales only
- contractor: engineering only

## Getting started

1. Create a virtual environment.
2. Install backend dependencies.
3. Run the FastAPI app.
4. Use the Streamlit or React UI to log in and ask questions.

```bash
cd backend
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Then run one of the frontends:

```bash
cd frontend
streamlit run streamlit_app.py
```

Or, for React:

```bash
cd frontend/react-app
npm install
npm run dev
```

## Demo users

- admin@corp.local / admin123
- finance@corp.local / finance123
- hr@corp.local / hr123
- eng@corp.local / eng123
- sales@corp.local / sales123
- contractor@corp.local / contractor123

## Notes

This is intentionally a secure demo environment: it protects access using role-based metadata, static input guardrails, and output redaction. For production, add a real LLM gateway, hardened secret management, audit logs, persistent vector storage, and a full benchmark suite using RAGAS on labeled evaluation sets.
