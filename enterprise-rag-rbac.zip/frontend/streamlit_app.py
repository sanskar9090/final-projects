import os

import requests
import streamlit as st

API_BASE = os.getenv("API_BASE", "http://localhost:8000")

st.set_page_config(page_title="Enterprise RAG Console", layout="wide")
st.title("Enterprise RAG Console")

with st.sidebar:
    st.subheader("Login")
    email = st.text_input("Email", value="finance@corp.local")
    password = st.text_input("Password", type="password", value="finance123")
    if st.button("Login"):
        res = requests.post(f"{API_BASE}/api/login", json={"email": email, "password": password}, timeout=15)
        if res.ok:
            st.session_state.token = res.json()["token"]
            st.session_state.role = res.json()["role"]
            st.success("Logged in")
        else:
            st.error("Login failed")

if "token" in st.session_state:
    st.write(f"Role: {st.session_state.role}")
    question = st.text_area("Ask a policy-related question")
    if st.button("Run RAG query"):
        res = requests.post(
            f"{API_BASE}/api/query",
            json={"question": question},
            headers={"Authorization": f"Bearer {st.session_state.token}"},
            timeout=30,
        )
        if res.ok:
            data = res.json()
            st.write("### Answer")
            st.write(data["answer"])
            st.write("### Guardrail issues")
            st.write(data.get("guardrail_issues", []))
            st.write("### Citations")
            st.write(data.get("citations", []))
        else:
            st.error(res.text)
else:
    st.info("Please log in to query internal documents.")
