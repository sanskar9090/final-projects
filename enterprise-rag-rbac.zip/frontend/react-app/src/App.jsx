import { useState } from 'react';

const API_BASE = 'http://localhost:8000';

export default function App() {
  const [email, setEmail] = useState('finance@corp.local');
  const [password, setPassword] = useState('finance123');
  const [token, setToken] = useState('');
  const [role, setRole] = useState('');
  const [question, setQuestion] = useState('What reimbursement approvals require manager sign-off?');
  const [answer, setAnswer] = useState('');
  const [error, setError] = useState('');

  async function login() {
    const res = await fetch(`${API_BASE}/api/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.detail || 'Login failed');
      return;
    }
    setToken(data.token);
    setRole(data.role);
    setError('');
  }

  async function askQuestion() {
    const res = await fetch(`${API_BASE}/api/query`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify({ question }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.detail || 'Query failed');
      return;
    }
    setAnswer(data.answer);
    setError('');
  }

  return (
    <div style={{ fontFamily: 'Arial, sans-serif', maxWidth: 900, margin: '40px auto', padding: 20 }}>
      <h1>Enterprise RAG Console</h1>
      <div style={{ display: 'grid', gap: 12 }}>
        <label>Email<input value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <label>Password<input type="password" value={password} onChange={(e) => setPassword(e.target.value)} /></label>
        <button onClick={login}>Login</button>
        {role && <p>Logged in as: <strong>{role}</strong></p>}
        {error && <p style={{ color: 'red' }}>{error}</p>}
        <textarea value={question} onChange={(e) => setQuestion(e.target.value)} rows={4} />
        <button onClick={askQuestion} disabled={!token}>Ask Internal Docs</button>
        {answer && <div><h3>Answer</h3><p>{answer}</p></div>}
      </div>
    </div>
  );
}
