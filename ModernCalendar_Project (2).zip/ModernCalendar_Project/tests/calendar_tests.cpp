#include "calendar/calendar.hpp"
#include "calendar/date.hpp"
#include "calendar/serialization.hpp"

#include <cassert>
#include <filesystem>
#include <memory>

int main() {
    using namespace calendar;

    assert((Date{2024, 2, 29}.isValid()));
    assert((!Date{1900, 2, 29}.isValid()));
    assert((Date{2000, 2, 29}.isValid()));
    assert((Date{2024, 1, 1}.weekday() == 1));
    assert((Date{2024, 6, 1}.weekday() == 6));
    assert(Date::parse("2024-02-29").has_value());
    assert(!Date::parse("2023-02-29").has_value());

    Calendar calendar;
    calendar.add(std::make_unique<Appointment>(
        calendar.nextId(), Date{2026, 10, 2}, "Project demo", "14:00", "Lab 3"));
    calendar.add(std::make_unique<Reminder>(
        calendar.nextId(), Date{2026, 10, 2}, "Bring report", "Print final copy"));
    calendar.add(std::make_unique<Task>(
        calendar.nextId(), Date{2026, 10, 3}, "Submit project"));

    assert(calendar.eventsOn(Date{2026, 10, 2}).size() == 2);
    assert(calendar.markTaskCompleted(3));
    assert(static_cast<const Task*>(calendar.find(3))->isCompleted());
    assert(!calendar.markTaskCompleted(1));

    const auto path = std::filesystem::temp_directory_path() /
                      "modern_calendar_test.db";
    SerializationEngine::save(path, calendar.events());
    auto loaded = SerializationEngine::load(path);
    assert(loaded.size() == 3);
    assert(loaded[0]->kind() == "APPOINTMENT");
    assert(loaded[1]->kind() == "REMINDER");
    assert(loaded[2]->kind() == "TASK");
    assert(static_cast<const Task*>(loaded[2].get())->isCompleted());

    Calendar restored;
    for (auto& event : loaded) {
        restored.add(std::move(event));
    }
    assert(restored.nextId() == 4);
    assert(restored.remove(2));
    assert(restored.find(2) == nullptr);
    std::filesystem::remove(path);
}
