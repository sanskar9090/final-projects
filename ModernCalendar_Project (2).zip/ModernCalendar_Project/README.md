# Modern Calendar (C++20)

A terminal-based calendar and event tracker built with standard C++20. It uses
Zeller's congruence for weekday calculation, polymorphic event types, smart
pointers for ownership, and a versioned file format for persistence.

## Features

- Display any month from years 1 through 9999; `*` marks days with events.
- Create appointments, reminders, and tasks, then browse by date or list all.
- Mark tasks complete and delete events.
- Automatically save changes to `calendar.db` in the current working directory.
- Validate calendar dates and reject malformed or unsupported data files.
- No external libraries are required.

## Design and algorithms

- `Date` validates Gregorian dates, including leap years, and calculates
  Sunday-first weekdays with Zeller's congruence.
- The abstract `Event` base class is extended by `Appointment`, `Reminder`,
  and `Task`; virtual methods provide type-specific display and serialization.
- `Calendar` owns events through `std::unique_ptr`, preventing accidental
  copying of ownership and cleaning up events automatically.
- `SerializationEngine` reads and writes a versioned, quoted-text format.
  Saves are written to a temporary file first, with a backup-and-restore path
  when the target cannot be replaced directly.

## Build

From this project directory, use CMake:

```powershell
cmake -S . -B build
cmake --build build
```

Run the application:

```powershell
.\build\modern_calendar.exe
```

Run the test suite:

```powershell
ctest --test-dir build --output-on-failure
```

Alternatively, compile directly with a C++20 compiler:

```powershell
g++ -std=c++20 -Wall -Wextra -Wpedantic -I include src\main.cpp src\date.cpp src\event.cpp src\calendar.cpp src\serialization.cpp -o modern_calendar.exe
```

## Project layout

```text
include/calendar/    Public date, event, calendar, and serialization interfaces
src/                 Application and implementation files
tests/               Core behavior and persistence tests
```

## Persistence format

The application stores records in `calendar.db`, beginning with the header
`MODERN_CALENDAR 1`.
