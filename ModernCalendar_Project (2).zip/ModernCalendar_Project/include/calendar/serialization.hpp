#pragma once

#include "calendar/event.hpp"

#include <filesystem>
#include <memory>
#include <vector>

namespace calendar {

class SerializationEngine {
public:
    [[nodiscard]] static std::vector<std::unique_ptr<Event>>
    load(const std::filesystem::path& path);

    static void save(const std::filesystem::path& path,
                     const std::vector<std::unique_ptr<Event>>& events);
};

} // namespace calendar
