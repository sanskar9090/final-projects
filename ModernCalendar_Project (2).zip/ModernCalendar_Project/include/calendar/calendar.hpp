#pragma once

#include "calendar/event.hpp"

#include <cstdint>
#include <memory>
#include <vector>

namespace calendar {

class Calendar {
public:
    [[nodiscard]] std::uint64_t nextId() const noexcept { return nextId_; }
    void add(std::unique_ptr<Event> event);
    [[nodiscard]] bool remove(std::uint64_t id);
    [[nodiscard]] bool markTaskCompleted(std::uint64_t id);
    [[nodiscard]] const Event* find(std::uint64_t id) const noexcept;
    [[nodiscard]] std::vector<const Event*> eventsOn(Date date) const;
    [[nodiscard]] const std::vector<std::unique_ptr<Event>>& events() const noexcept {
        return events_;
    }

private:
    std::uint64_t nextId_{1};
    std::vector<std::unique_ptr<Event>> events_;
};

} // namespace calendar
