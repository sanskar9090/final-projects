#pragma once

#include <compare>
#include <optional>
#include <string>
#include <string_view>

namespace calendar {

struct Date {
    int year{};
    int month{};
    int day{};

    [[nodiscard]] bool isValid() const noexcept;
    [[nodiscard]] int weekday() const noexcept;
    [[nodiscard]] std::string toString() const;

    [[nodiscard]] static bool isLeapYear(int year) noexcept;
    [[nodiscard]] static int daysInMonth(int month, int year) noexcept;
    [[nodiscard]] static std::optional<Date> parse(std::string_view text);

    auto operator<=>(const Date&) const = default;
};

} // namespace calendar
