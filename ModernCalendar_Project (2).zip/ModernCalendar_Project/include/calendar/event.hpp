#pragma once

#include "calendar/date.hpp"

#include <cstdint>
#include <iosfwd>
#include <string>
#include <string_view>

namespace calendar {

class Event {
public:
    Event(std::uint64_t id, Date date, std::string title);
    virtual ~Event() = default;

    [[nodiscard]] std::uint64_t id() const noexcept { return id_; }
    [[nodiscard]] const Date& date() const noexcept { return date_; }
    [[nodiscard]] const std::string& title() const noexcept { return title_; }

    [[nodiscard]] virtual std::string_view kind() const noexcept = 0;
    virtual void writeRecord(std::ostream& output) const = 0;
    virtual void printDetails(std::ostream& output) const = 0;

private:
    std::uint64_t id_;
    Date date_;
    std::string title_;
};

class Appointment final : public Event {
public:
    Appointment(std::uint64_t id, Date date, std::string title,
                std::string time, std::string location);

    [[nodiscard]] const std::string& time() const noexcept { return time_; }
    [[nodiscard]] const std::string& location() const noexcept { return location_; }
    [[nodiscard]] std::string_view kind() const noexcept override;
    void writeRecord(std::ostream& output) const override;
    void printDetails(std::ostream& output) const override;

private:
    std::string time_;
    std::string location_;
};

class Reminder final : public Event {
public:
    Reminder(std::uint64_t id, Date date, std::string title, std::string message);

    [[nodiscard]] const std::string& message() const noexcept { return message_; }
    [[nodiscard]] std::string_view kind() const noexcept override;
    void writeRecord(std::ostream& output) const override;
    void printDetails(std::ostream& output) const override;

private:
    std::string message_;
};

class Task final : public Event {
public:
    Task(std::uint64_t id, Date date, std::string title, bool completed = false);

    [[nodiscard]] bool isCompleted() const noexcept { return completed_; }
    void markCompleted() noexcept { completed_ = true; }
    [[nodiscard]] std::string_view kind() const noexcept override;
    void writeRecord(std::ostream& output) const override;
    void printDetails(std::ostream& output) const override;

private:
    bool completed_;
};

} // namespace calendar
