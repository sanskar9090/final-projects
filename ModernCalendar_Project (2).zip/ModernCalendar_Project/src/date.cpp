#include "calendar/date.hpp"

#include <charconv>
#include <cstdio>

namespace calendar {

bool Date::isLeapYear(int year) noexcept {
    return year % 400 == 0 || (year % 4 == 0 && year % 100 != 0);
}

int Date::daysInMonth(int month, int year) noexcept {
    constexpr int monthLengths[] = {31, 28, 31, 30, 31, 30,
                                    31, 31, 30, 31, 30, 31};
    if (month < 1 || month > 12) {
        return 0;
    }
    if (month == 2 && isLeapYear(year)) {
        return 29;
    }
    return monthLengths[month - 1];
}

bool Date::isValid() const noexcept {
    return year >= 1 && month >= 1 && month <= 12 &&
           day >= 1 && day <= daysInMonth(month, year);
}

int Date::weekday() const noexcept {
    // Zeller's congruence returns Saturday=0; convert to Sunday=0.
    int adjustedMonth = month;
    int adjustedYear = year;
    if (adjustedMonth < 3) {
        adjustedMonth += 12;
        --adjustedYear;
    }
    const int century = adjustedYear / 100;
    const int yearOfCentury = adjustedYear % 100;
    const int zeller = (day + (13 * (adjustedMonth + 1)) / 5 +
                        yearOfCentury + yearOfCentury / 4 + century / 4 +
                        5 * century) % 7;
    return (zeller + 6) % 7;
}

std::string Date::toString() const {
    char buffer[11]{};
    std::snprintf(buffer, sizeof(buffer), "%04d-%02d-%02d", year, month, day);
    return buffer;
}

std::optional<Date> Date::parse(std::string_view text) {
    if (text.size() != 10 || text[4] != '-' || text[7] != '-') {
        return std::nullopt;
    }

    Date result;
    const auto parsePart = [text](std::size_t begin, std::size_t length, int& value) {
        const char* first = text.data() + begin;
        const char* last = first + length;
        const auto parsed = std::from_chars(first, last, value);
        return parsed.ec == std::errc{} && parsed.ptr == last;
    };

    if (!parsePart(0, 4, result.year) ||
        !parsePart(5, 2, result.month) ||
        !parsePart(8, 2, result.day) || !result.isValid()) {
        return std::nullopt;
    }
    return result;
}

} // namespace calendar
