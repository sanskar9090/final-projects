#include "calendar/calendar.hpp"

#include <algorithm>
#include <limits>
#include <stdexcept>

namespace calendar {

void Calendar::add(std::unique_ptr<Event> event) {
    if (!event) {
        throw std::invalid_argument("Cannot add an empty event.");
    }
    if (find(event->id()) != nullptr) {
        throw std::invalid_argument("An event with that ID already exists.");
    }

    if (event->id() >= nextId_ &&
        event->id() != std::numeric_limits<std::uint64_t>::max()) {
        nextId_ = event->id() + 1;
    }
    events_.push_back(std::move(event));
}

bool Calendar::remove(std::uint64_t id) {
    const auto found = std::find_if(events_.begin(), events_.end(),
                                    [id](const auto& event) {
                                        return event->id() == id;
                                    });
    if (found == events_.end()) {
        return false;
    }
    events_.erase(found);
    return true;
}

bool Calendar::markTaskCompleted(std::uint64_t id) {
    for (const auto& event : events_) {
        if (event->id() == id) {
            auto* task = dynamic_cast<Task*>(event.get());
            if (task == nullptr) {
                return false;
            }
            task->markCompleted();
            return true;
        }
    }
    return false;
}

const Event* Calendar::find(std::uint64_t id) const noexcept {
    const auto found = std::find_if(events_.begin(), events_.end(),
                                    [id](const auto& event) {
                                        return event->id() == id;
                                    });
    return found == events_.end() ? nullptr : found->get();
}

std::vector<const Event*> Calendar::eventsOn(Date date) const {
    std::vector<const Event*> result;
    for (const auto& event : events_) {
        if (event->date() == date) {
            result.push_back(event.get());
        }
    }
    std::sort(result.begin(), result.end(), [](const Event* left, const Event* right) {
        return left->id() < right->id();
    });
    return result;
}

} // namespace calendar
