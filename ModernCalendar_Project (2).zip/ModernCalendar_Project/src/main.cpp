#include "calendar/calendar.hpp"
#include "calendar/date.hpp"
#include "calendar/serialization.hpp"

#include <algorithm>
#include <charconv>
#include <cctype>
#include <cstdint>
#include <filesystem>
#include <iomanip>
#include <iostream>
#include <memory>
#include <sstream>
#include <stdexcept>
#include <string>
#include <string_view>
#include <vector>

namespace {

using calendar::Appointment;
using calendar::Calendar;
using calendar::Date;
using calendar::Event;
using calendar::Reminder;
using calendar::SerializationEngine;
using calendar::Task;

constexpr const char* reset = "\033[0m";
constexpr const char* cyan = "\033[36m";
constexpr const char* green = "\033[32m";
constexpr const char* yellow = "\033[33m";
constexpr const char* red = "\033[31m";
constexpr const char* bold = "\033[1m";
const std::filesystem::path dataFile = "calendar.db";

std::string readLine(const std::string& prompt) {
    std::cout << prompt;
    std::string value;
    if (!std::getline(std::cin, value)) {
        throw std::runtime_error("Input stream closed.");
    }
    return value;
}

int readInteger(const std::string& prompt, int minimum, int maximum) {
    while (true) {
        const std::string text = readLine(prompt);
        int value{};
        const auto result = std::from_chars(text.data(), text.data() + text.size(), value);
        if (result.ec == std::errc{} && result.ptr == text.data() + text.size() &&
            value >= minimum && value <= maximum) {
            return value;
        }
        std::cout << red << "Enter a whole number from " << minimum << " to "
                  << maximum << "." << reset << '\n';
    }
}

std::uint64_t readId(const std::string& prompt) {
    while (true) {
        const std::string text = readLine(prompt);
        std::uint64_t value{};
        const auto result = std::from_chars(text.data(), text.data() + text.size(), value);
        if (result.ec == std::errc{} && result.ptr == text.data() + text.size() &&
            value > 0) {
            return value;
        }
        std::cout << red << "Enter a positive event ID." << reset << '\n';
    }
}

Date readDate() {
    while (true) {
        const std::string text = readLine("Date (YYYY-MM-DD): ");
        if (const auto date = Date::parse(text)) {
            return *date;
        }
        std::cout << red << "That date is invalid. Please use YYYY-MM-DD."
                  << reset << '\n';
    }
}

std::string readRequired(const std::string& prompt) {
    while (true) {
        std::string value = readLine(prompt);
        const auto hasVisibleText = std::any_of(
            value.begin(), value.end(),
            [](unsigned char character) { return !std::isspace(character); });
        if (hasVisibleText) {
            return value;
        }
        std::cout << red << "This field cannot be empty." << reset << '\n';
    }
}

std::string monthName(int month) {
    static constexpr const char* names[] = {
        "January", "February", "March", "April", "May", "June",
        "July", "August", "September", "October", "November", "December"};
    return names[month - 1];
}

void printEvent(const Event& event) {
    std::cout << "  " << cyan << '#' << event.id() << reset << "  "
              << event.date().toString() << "  " << bold << event.title()
              << reset << "  [" << event.kind() << "] ";
    event.printDetails(std::cout);
    std::cout << '\n';
}

void showCalendar(const Calendar& calendar) {
    const int year = readInteger("Year (1-9999): ", 1, 9999);
    const int month = readInteger("Month (1-12): ", 1, 12);
    std::cout << "\n" << bold << cyan << "  " << monthName(month) << ' '
              << year << reset << "\n";
    std::cout << "  Su   Mo   Tu   We   Th   Fr   Sa\n";

    const Date firstDay{year, month, 1};
    for (int blank = 0; blank < firstDay.weekday(); ++blank) {
        std::cout << "     ";
    }
    for (int day = 1; day <= Date::daysInMonth(month, year); ++day) {
        const Date date{year, month, day};
        const bool hasEvents = !calendar.eventsOn(date).empty();
        std::cout << std::setw(3) << day << (hasEvents ? "*" : " ") << ' ';
        if (date.weekday() == 6) {
            std::cout << '\n';
        }
    }
    std::cout << "\n\n" << yellow << "* has one or more events" << reset << '\n';
}

void listEvents(const Calendar& calendar) {
    std::vector<const Event*> sorted;
    sorted.reserve(calendar.events().size());
    for (const auto& event : calendar.events()) {
        sorted.push_back(event.get());
    }
    std::sort(sorted.begin(), sorted.end(), [](const Event* left, const Event* right) {
        if (left->date() != right->date()) {
            return left->date() < right->date();
        }
        return left->id() < right->id();
    });

    std::cout << '\n' << bold << "Your events (" << sorted.size() << ")"
              << reset << '\n';
    if (sorted.empty()) {
        std::cout << "  Nothing scheduled yet.\n";
        return;
    }
    for (const Event* event : sorted) {
        printEvent(*event);
    }
}

void addEvent(Calendar& calendar) {
    std::cout << "\n1. Appointment\n2. Reminder\n3. Task\n";
    const int type = readInteger("Choose event type: ", 1, 3);
    const Date date = readDate();
    const std::string title = readRequired("Title: ");
    const auto id = calendar.nextId();

    if (type == 1) {
        const std::string time = readRequired("Time (for example 14:30): ");
        const std::string location = readRequired("Location: ");
        calendar.add(std::make_unique<Appointment>(id, date, title, time, location));
    } else if (type == 2) {
        const std::string message = readRequired("Reminder message: ");
        calendar.add(std::make_unique<Reminder>(id, date, title, message));
    } else {
        calendar.add(std::make_unique<Task>(id, date, title));
    }
    SerializationEngine::save(dataFile, calendar.events());
    std::cout << green << "Event #" << id << " added and saved." << reset << '\n';
}

void showEventsForDate(const Calendar& calendar) {
    const Date date = readDate();
    const auto events = calendar.eventsOn(date);
    if (events.empty()) {
        std::cout << "No events on " << date.toString() << ".\n";
        return;
    }
    std::cout << "\nEvents on " << date.toString() << ":\n";
    for (const Event* event : events) {
        printEvent(*event);
    }
}

void showMenu() {
    std::cout << "\n" << bold << "  MODERN CALENDAR" << reset << '\n'
              << "  1  View a month\n"
              << "  2  Add an event\n"
              << "  3  List all events\n"
              << "  4  Find events by date\n"
              << "  5  Complete a task\n"
              << "  6  Delete an event\n"
              << "  7  Save now\n"
              << "  0  Save and exit\n";
}

void run() {
    Calendar calendar;
    for (auto& event : SerializationEngine::load(dataFile)) {
        calendar.add(std::move(event));
    }
    std::cout << cyan << bold << "Modern Calendar" << reset
              << "  |  Zeller's congruence  |  C++20\n"
              << "Data file: " << std::filesystem::absolute(dataFile).string()
              << "  |  Loaded " << calendar.events().size() << " event(s).\n";

    bool running = true;
    while (running) {
        showMenu();
        const int choice = readInteger("Select an option: ", 0, 7);
        switch (choice) {
        case 1:
            showCalendar(calendar);
            break;
        case 2:
            addEvent(calendar);
            break;
        case 3:
            listEvents(calendar);
            break;
        case 4:
            showEventsForDate(calendar);
            break;
        case 5: {
            const auto id = readId("Task event ID: ");
            if (calendar.markTaskCompleted(id)) {
                SerializationEngine::save(dataFile, calendar.events());
                std::cout << green << "Task marked complete and saved." << reset << '\n';
            } else {
                std::cout << red << "No task found with that ID." << reset << '\n';
            }
            break;
        }
        case 6: {
            const auto id = readId("Event ID to delete: ");
            if (calendar.remove(id)) {
                SerializationEngine::save(dataFile, calendar.events());
                std::cout << green << "Event deleted and saved." << reset << '\n';
            } else {
                std::cout << red << "No event found with that ID." << reset << '\n';
            }
            break;
        }
        case 7:
            SerializationEngine::save(dataFile, calendar.events());
            std::cout << green << "Calendar saved." << reset << '\n';
            break;
        case 0:
            SerializationEngine::save(dataFile, calendar.events());
            running = false;
            std::cout << green << "Calendar saved. Goodbye!\n" << reset;
            break;
        default:
            break;
        }
    }
}

} // namespace

int main() {
    try {
        run();
        return 0;
    } catch (const std::exception& error) {
        std::cerr << "\n" << red << "Error: " << error.what() << reset << '\n';
        return 1;
    }
}
