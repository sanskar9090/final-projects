#include "calendar/serialization.hpp"

#include <fstream>
#include <iomanip>
#include <sstream>
#include <stdexcept>
#include <string>
#include <system_error>

namespace calendar {
namespace {

constexpr int formatVersion = 1;
constexpr const char* fileHeader = "MODERN_CALENDAR";

std::unique_ptr<Event> parseRecord(const std::string& line,
                                   const std::filesystem::path& path,
                                   std::size_t lineNumber) {
    std::istringstream input(line);
    std::string kind;
    std::uint64_t id{};
    Date date;
    std::string title;
    if (!(input >> kind >> id >> date.year >> date.month >> date.day >>
          std::quoted(title))) {
        throw std::runtime_error("Malformed event at " + path.string() + ":" +
                                 std::to_string(lineNumber));
    }

    if (!date.isValid()) {
        throw std::runtime_error("Invalid event date at " + path.string() + ":" +
                                 std::to_string(lineNumber));
    }

    std::unique_ptr<Event> event;
    if (kind == "APPOINTMENT") {
        std::string time;
        std::string location;
        if (!(input >> std::quoted(time) >> std::quoted(location))) {
            throw std::runtime_error("Malformed appointment at " + path.string() +
                                     ":" + std::to_string(lineNumber));
        }
        event = std::make_unique<Appointment>(id, date, std::move(title),
                                              std::move(time), std::move(location));
    } else if (kind == "REMINDER") {
        std::string message;
        if (!(input >> std::quoted(message))) {
            throw std::runtime_error("Malformed reminder at " + path.string() +
                                     ":" + std::to_string(lineNumber));
        }
        event = std::make_unique<Reminder>(id, date, std::move(title),
                                           std::move(message));
    } else if (kind == "TASK") {
        int completed{};
        if (!(input >> completed) || (completed != 0 && completed != 1)) {
            throw std::runtime_error("Malformed task at " + path.string() + ":" +
                                     std::to_string(lineNumber));
        }
        event = std::make_unique<Task>(id, date, std::move(title), completed == 1);
    } else {
        throw std::runtime_error("Unknown event type at " + path.string() + ":" +
                                 std::to_string(lineNumber));
    }

    input >> std::ws;
    if (!input.eof()) {
        throw std::runtime_error("Unexpected data at " + path.string() + ":" +
                                 std::to_string(lineNumber));
    }
    return event;
}

} // namespace

std::vector<std::unique_ptr<Event>>
SerializationEngine::load(const std::filesystem::path& path) {
    std::ifstream input(path, std::ios::binary);
    if (!input) {
        if (!std::filesystem::exists(path)) {
            return {};
        }
        throw std::runtime_error("Unable to open calendar file: " + path.string());
    }

    std::string headerLine;
    std::string header;
    int version{};
    if (!std::getline(input, headerLine)) {
        throw std::runtime_error("Unsupported or invalid calendar file: " +
                                 path.string());
    }
    std::istringstream headerInput(headerLine);
    if (!(headerInput >> header >> version) || header != fileHeader ||
        version != formatVersion) {
        throw std::runtime_error("Unsupported or invalid calendar file: " +
                                 path.string());
    }
    headerInput >> std::ws;
    if (!headerInput.eof()) {
        throw std::runtime_error("Unexpected data in calendar file header: " +
                                 path.string());
    }

    std::string line;
    std::vector<std::unique_ptr<Event>> events;
    std::size_t lineNumber = 1;
    while (std::getline(input, line)) {
        ++lineNumber;
        if (line.empty()) {
            continue;
        }
        events.push_back(parseRecord(line, path, lineNumber));
    }
    if (input.bad()) {
        throw std::runtime_error("Error while reading calendar file: " + path.string());
    }
    return events;
}

void SerializationEngine::save(
    const std::filesystem::path& path,
    const std::vector<std::unique_ptr<Event>>& events) {
    if (path.empty()) {
        throw std::invalid_argument("Calendar file path cannot be empty.");
    }

    const std::filesystem::path temporary = path.string() + ".tmp";
    const std::filesystem::path backup = path.string() + ".bak";
    {
        std::ofstream output(temporary, std::ios::binary | std::ios::trunc);
        if (!output) {
            throw std::runtime_error("Unable to create calendar file: " +
                                     temporary.string());
        }
        output << fileHeader << ' ' << formatVersion << '\n';
        for (const auto& event : events) {
            event->writeRecord(output);
            output << '\n';
        }
        output.flush();
        if (!output) {
            throw std::runtime_error("Error while writing calendar file: " +
                                     temporary.string());
        }
    }

    std::error_code error;
    std::filesystem::rename(temporary, path, error);
    if (!error) {
        return;
    }

    error.clear();
    const bool targetExists = std::filesystem::exists(path, error);
    if (error || !targetExists) {
        std::filesystem::remove(temporary);
        throw std::runtime_error("Unable to replace calendar file: " + path.string());
    }

    error.clear();
    std::filesystem::remove(backup, error);
    if (error) {
        std::filesystem::remove(temporary);
        throw std::runtime_error("Unable to remove old calendar backup: " +
                                 backup.string());
    }
    error.clear();
    std::filesystem::rename(path, backup, error);
    if (error) {
        std::filesystem::remove(temporary);
        throw std::runtime_error("Unable to back up calendar file: " + path.string());
    }

    error.clear();
    std::filesystem::rename(temporary, path, error);
    if (error) {
        std::error_code restoreError;
        std::filesystem::rename(backup, path, restoreError);
        std::filesystem::remove(temporary);
        if (restoreError) {
            throw std::runtime_error("Unable to save or restore calendar file: " +
                                     path.string());
        }
        throw std::runtime_error("Unable to save calendar file: " + path.string());
    }

    error.clear();
    std::filesystem::remove(backup, error);
    if (error) {
        throw std::runtime_error("Calendar was saved, but its backup could not be "
                                 "removed: " + backup.string());
    }
}

} // namespace calendar
