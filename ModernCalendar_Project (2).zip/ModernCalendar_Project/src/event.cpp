#include "calendar/event.hpp"

#include <iomanip>
#include <ostream>
#include <stdexcept>
#include <utility>

namespace calendar {

Event::Event(std::uint64_t id, Date date, std::string title)
    : id_(id), date_(date), title_(std::move(title)) {
    if (id_ == 0) {
        throw std::invalid_argument("Event ID must be greater than zero.");
    }
    if (!date_.isValid()) {
        throw std::invalid_argument("Event date is invalid.");
    }
    if (title_.empty()) {
        throw std::invalid_argument("Event title cannot be empty.");
    }
}

Appointment::Appointment(std::uint64_t id, Date date, std::string title,
                         std::string time, std::string location)
    : Event(id, date, std::move(title)),
      time_(std::move(time)),
      location_(std::move(location)) {}

std::string_view Appointment::kind() const noexcept {
    return "APPOINTMENT";
}

void Appointment::writeRecord(std::ostream& output) const {
    output << kind() << ' ' << id() << ' ' << date().year << ' '
           << date().month << ' ' << date().day << ' ' << std::quoted(title())
           << ' ' << std::quoted(time_) << ' ' << std::quoted(location_);
}

void Appointment::printDetails(std::ostream& output) const {
    output << time_ << " | " << location_;
}

Reminder::Reminder(std::uint64_t id, Date date, std::string title,
                   std::string message)
    : Event(id, date, std::move(title)), message_(std::move(message)) {}

std::string_view Reminder::kind() const noexcept {
    return "REMINDER";
}

void Reminder::writeRecord(std::ostream& output) const {
    output << kind() << ' ' << id() << ' ' << date().year << ' '
           << date().month << ' ' << date().day << ' ' << std::quoted(title())
           << ' ' << std::quoted(message_);
}

void Reminder::printDetails(std::ostream& output) const {
    output << message_;
}

Task::Task(std::uint64_t id, Date date, std::string title, bool completed)
    : Event(id, date, std::move(title)), completed_(completed) {}

std::string_view Task::kind() const noexcept {
    return "TASK";
}

void Task::writeRecord(std::ostream& output) const {
    output << kind() << ' ' << id() << ' ' << date().year << ' '
           << date().month << ' ' << date().day << ' ' << std::quoted(title())
           << ' ' << (completed_ ? 1 : 0);
}

void Task::printDetails(std::ostream& output) const {
    output << (completed_ ? "Completed" : "Pending");
}

} // namespace calendar
