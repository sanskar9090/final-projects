# Multimodal Traffic Incident & Congestion Predictor

A runnable starter architecture for **localized short-horizon traffic forecasting**. It combines vehicle detections from camera frames, authorized probe-GPS speed observations, and time-stamped road events, then uses the fused forecast to recommend a lower-cost route.

> This is a prototype, not a production traffic service. The included road graph and demo observations are synthetic. Production deployment needs calibrated camera geometry, validation data, resilient stream processing, a real road-network provider, monitoring, and a trained/calibrated forecasting model.

## Included

- **Video ingestion:** OpenCV camera/file reader and optional Ultralytics YOLO vehicle detector.
- **Object tracking:** lightweight centroid association across adjacent frames.
- **Temporal features:** rolling per-segment speed history with a linear trend extrapolated to a configurable 5–60 minute horizon.
- **Multimodal fusion:** camera occupancy/stopped vehicles, GPS probe speed weighted by sample count, and severity/report-weighted events.
- **Localized predictions:** predicted speed, congestion score/level, incident probability, confidence, and evidence.
- **Dynamic routing:** Dijkstra path selection with congestion-adjusted edge travel time.
- **FastAPI:** health, ingest, predict, demo, and route endpoints.
- **Runnable example:** one command fuses synthetic A12 camera + probe + stalled-vehicle data, forecasts 15 minutes, and returns a North-to-Harbor alternate route.
- **Walkthrough video:** `assets/traffic_predictor_walkthrough.mp4` (45 seconds, silent captions).

## Quick start

Requires Python 3.10+.

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e .
traffic-demo
```

Start the API:

```powershell
traffic-api
```

Then open `http://127.0.0.1:8000/docs` or request the integrated example:

```powershell
Invoke-RestMethod http://127.0.0.1:8000/demo
```

The example returns a fused forecast for segment `A12` and a recommended route from `North` to `Harbor`. `/docs` provides interactive request forms for all operations.

## Analyze a camera/video stream

The vision dependencies are optional. Install them and provide a local stream or video:

```powershell
python -m pip install -e ".[vision]"
python -m traffic_predictor.video_cli 0
python -m traffic_predictor.video_cli C:\data\traffic.mp4
```

Ultralytics will load/download the selected weights (default `yolov8n.pt`) on first use. Video inference emits frame/detection counts; adapt the pipeline's output to your camera geometry and segment-level speed estimator before using it as a calibrated API camera observation. Camera access and model weights must be used lawfully.

## API flow

1. A camera adapter derives vehicle count, mean speed, stopped count, and optional incident hint for a road segment.
2. A GPS adapter aggregates authorized probe observations to a segment mean speed and sample count.
3. Event adapters provide a typed event and severity. Do not scrape consumer navigation apps: use an approved Waze/partner feed or another data source whose license permits this use.
4. `POST /ingest` adds observed speed to the in-memory segment history; `POST /predict` fuses a snapshot and forecasts forward.
5. `POST /route` applies supplied forecasts to the configured graph and returns the lowest generalized travel-time route.

### Example prediction request

```json
{
  "segment_id": "A12",
  "camera": {
    "segment_id": "A12",
    "vehicle_count": 27,
    "mean_vehicle_speed_kmh": 18,
    "lane_capacity": 24,
    "stopped_vehicle_count": 4,
    "incident_hint": true
  },
  "gps": {
    "segment_id": "A12",
    "mean_speed_kmh": 22,
    "sample_count": 38,
    "source": "authorized_partner_feed"
  },
  "events": [
    {"segment_id": "A12", "kind": "stalled_vehicle", "severity": 3, "reports": 2}
  ],
  "horizon_minutes": 15
}
```

### Notes and limitations

- The in-memory history resets when the process restarts and is suitable only for this starter/demo. Use a durable event/time-series store for deployment.
- Timestamps should be synchronized and observations should be deduplicated and freshness-checked in production.
- The score is an interpretable heuristic, **not** a statistically validated probability. Confidence is a coverage heuristic; incident probability needs calibration against labeled incidents.
- The demo graph is intentionally tiny and illustrative. Replace it with a licensed, current road graph and include turn restrictions, closures, vehicle constraints, and route safety policy.
- Never route traffic onto restricted/private roads or use sensitive location data without a lawful basis, consent where required, retention controls, and access controls.
- Waze and similar consumer products have terms governing data access and reuse. Integrate only through an authorized feed/API and comply with its contract, privacy, and attribution requirements; this project does not connect to or scrape Waze.

## Project layout

```text
traffic-multimodal-predictor/
  data/sample_gps.csv          # illustrative time series
  traffic_predictor/
    api.py                     # FastAPI service
    demo.py                    # reproducible end-to-end example
    fusion.py                  # fusion + short-horizon sequence forecast
    models.py                  # typed request/response schemas
    routing.py                 # congestion-aware Dijkstra routing
    video_cli.py               # command-line camera/file runner
    vision.py                  # YOLO adapter + centroid tracker
```
