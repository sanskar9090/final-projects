from __future__ import annotations

import argparse
import json

from .vision import analyze_video


def main() -> None:
    parser = argparse.ArgumentParser(description="Detect and track vehicles in a traffic stream.")
    parser.add_argument("source", help="Video file path or camera index such as 0")
    parser.add_argument("--model", default="yolov8n.pt", help="Ultralytics model/weights")
    args = parser.parse_args()
    source: str | int = int(args.source) if args.source.isdigit() else args.source
    print(json.dumps(analyze_video(source, args.model), indent=2))


if __name__ == "__main__":
    main()
