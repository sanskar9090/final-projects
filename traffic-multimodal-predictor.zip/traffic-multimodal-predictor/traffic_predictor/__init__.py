"""Multimodal traffic congestion prediction starter."""

__version__ = "0.1.0"
