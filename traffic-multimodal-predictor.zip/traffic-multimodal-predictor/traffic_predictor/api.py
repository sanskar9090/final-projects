from __future__ import annotations

from fastapi import FastAPI, HTTPException

from .fusion import TrafficFusionEngine, demo_observations
from .models import IngestRequest, PredictRequest, RouteRequest
from .routing import recommend_route

app = FastAPI(
    title="Multimodal Traffic Predictor",
    description="Fuse authorized camera, probe-GPS, and incident signals for local forecasts and routing.",
    version="0.1.0",
)
engine = TrafficFusionEngine()


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/ingest")
def ingest(payload: IngestRequest) -> dict[str, str]:
    try:
        engine.observe(payload.camera, payload.gps, payload.events)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    return {"status": "accepted", "segment_id": payload.camera.segment_id}


@app.post("/predict")
def predict(payload: PredictRequest):
    try:
        return engine.predict(
            payload.segment_id,
            payload.camera,
            payload.gps,
            payload.events,
            payload.horizon_minutes,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


@app.get("/demo")
def demo() -> dict[str, object]:
    camera, gps, events = demo_observations()
    prediction = engine.predict("A12", camera, gps, events, horizon_minutes=15)
    route = recommend_route(
        RouteRequest(
            origin="North",
            destination="Harbor",
            predictions=[prediction],
        )
    )
    return {"prediction": prediction, "route": route}


@app.post("/route")
def route(payload: RouteRequest) -> dict[str, object]:
    try:
        return recommend_route(payload)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


def run() -> None:
    import uvicorn

    uvicorn.run("traffic_predictor.api:app", host="127.0.0.1", port=8000, reload=False)
