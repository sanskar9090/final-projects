from __future__ import annotations

import json

from .fusion import TrafficFusionEngine, demo_observations
from .models import RouteRequest
from .routing import recommend_route


def main() -> None:
    camera, gps, events = demo_observations()
    engine = TrafficFusionEngine()
    prediction = engine.predict("A12", camera, gps, events, horizon_minutes=15)
    route = recommend_route(
        RouteRequest(
            origin="North",
            destination="Harbor",
            predictions=[prediction],
        )
    )
    print(
        json.dumps(
            {
                "operation": "fuse live modalities, forecast 15 minutes, reroute",
                "prediction": prediction.model_dump(mode="json"),
                "recommended_route": route,
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
