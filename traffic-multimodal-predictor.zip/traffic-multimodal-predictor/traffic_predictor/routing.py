from __future__ import annotations

import heapq

from .models import RouteRequest, SegmentPrediction


# Example directed road graph. Replace with a licensed/local road-network provider.
ROAD_GRAPH: dict[str, list[tuple[str, str, float]]] = {
    "North": [("Junction", "A12", 6.0), ("Market", "B08", 7.5)],
    "Junction": [("Central", "A12", 5.0), ("Market", "C03", 4.0)],
    "Market": [("Central", "B08", 6.0), ("Junction", "C03", 4.0)],
    "Central": [("Harbor", "D21", 5.0)],
    "Harbor": [],
}


def recommend_route(
    request: RouteRequest,
    predictions: list[SegmentPrediction] | None = None,
) -> dict[str, object]:
    live_predictions = predictions if predictions is not None else request.predictions
    congestion = {p.segment_id: p.congestion_score for p in live_predictions}
    excluded = set(request.avoid_segments)
    if request.origin not in ROAD_GRAPH or request.destination not in ROAD_GRAPH:
        raise ValueError("Origin or destination is not present in the configured road graph.")

    distances = {node: float("inf") for node in ROAD_GRAPH}
    previous: dict[str, tuple[str, str, float]] = {}
    distances[request.origin] = 0
    queue: list[tuple[float, str]] = [(0, request.origin)]
    while queue:
        cost, node = heapq.heappop(queue)
        if cost > distances[node]:
            continue
        if node == request.destination:
            break
        for neighbor, segment_id, base_minutes in ROAD_GRAPH[node]:
            if segment_id in excluded:
                continue
            # Penalize forecast congestion; score 1 adds up to 3x travel time.
            adjusted = base_minutes * (1 + 2 * congestion.get(segment_id, 0))
            candidate = cost + adjusted
            if candidate < distances[neighbor]:
                distances[neighbor] = candidate
                previous[neighbor] = (node, segment_id, adjusted)
                heapq.heappush(queue, (candidate, neighbor))

    if distances[request.destination] == float("inf"):
        raise ValueError("No route is available with the requested exclusions.")
    nodes = [request.destination]
    segments: list[str] = []
    cursor = request.destination
    while cursor != request.origin:
        parent, segment_id, _ = previous[cursor]
        nodes.append(parent)
        segments.append(segment_id)
        cursor = parent
    nodes.reverse()
    segments.reverse()
    return {
        "nodes": nodes,
        "segments": segments,
        "estimated_minutes": round(distances[request.destination], 1),
        "avoided_congested_segments": [
            segment for segment in segments if congestion.get(segment, 0) >= 0.58
        ],
    }
