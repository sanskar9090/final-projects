from __future__ import annotations

from datetime import datetime, timezone
from typing import Literal

from pydantic import BaseModel, Field


class CameraObservation(BaseModel):
    segment_id: str
    observed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    vehicle_count: int = Field(ge=0)
    mean_vehicle_speed_kmh: float = Field(ge=0, le=200)
    lane_capacity: int = Field(default=24, ge=1)
    stopped_vehicle_count: int = Field(default=0, ge=0)
    incident_hint: bool = False


class GpsObservation(BaseModel):
    segment_id: str
    observed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    mean_speed_kmh: float = Field(ge=0, le=200)
    sample_count: int = Field(default=1, ge=1)
    source: str = "authorized_partner_feed"


class RoadEvent(BaseModel):
    segment_id: str
    kind: Literal["crash", "hazard", "closure", "construction", "stalled_vehicle"]
    severity: int = Field(default=1, ge=1, le=5)
    reports: int = Field(default=1, ge=1)
    observed_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class IngestRequest(BaseModel):
    camera: CameraObservation
    gps: GpsObservation
    events: list[RoadEvent] = Field(default_factory=list)


class PredictRequest(BaseModel):
    segment_id: str
    camera: CameraObservation | None = None
    gps: GpsObservation | None = None
    events: list[RoadEvent] = Field(default_factory=list)
    horizon_minutes: int = Field(default=15, ge=5, le=60)


class SegmentPrediction(BaseModel):
    segment_id: str
    predicted_speed_kmh: float
    congestion_score: float
    congestion_level: Literal["free_flow", "moderate", "heavy", "severe"]
    incident_probability: float
    confidence: float
    horizon_minutes: int
    evidence: list[str]


class RouteRequest(BaseModel):
    origin: str
    destination: str
    avoid_segments: list[str] = Field(default_factory=list)
    predictions: list[SegmentPrediction] = Field(default_factory=list)
