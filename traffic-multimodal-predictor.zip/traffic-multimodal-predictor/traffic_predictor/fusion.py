from __future__ import annotations

from collections import defaultdict, deque
from datetime import datetime, timezone
from math import exp
from threading import RLock

import numpy as np

from .models import CameraObservation, GpsObservation, RoadEvent, SegmentPrediction


class TrafficFusionEngine:
    """Fuses camera, probe-speed, and event signals with a short sequence trend."""

    def __init__(self, history_size: int = 24) -> None:
        self._history: dict[str, deque[tuple[datetime, float]]] = defaultdict(
            lambda: deque(maxlen=history_size)
        )
        self._lock = RLock()

    def observe(
        self,
        camera: CameraObservation | None,
        gps: GpsObservation | None,
        events: list[RoadEvent],
    ) -> None:
        segment_id = camera.segment_id if camera else (gps.segment_id if gps else None)
        if segment_id is None:
            raise ValueError("At least one camera or GPS observation is required.")
        if camera and gps and camera.segment_id != gps.segment_id:
            raise ValueError("Camera and GPS observations must refer to the same segment.")
        if any(event.segment_id != segment_id for event in events):
            raise ValueError("All road events must refer to the observed segment.")
        timestamp = camera.observed_at if camera else gps.observed_at
        speed = self._observed_speed(camera, gps)
        if speed is not None:
            with self._lock:
                self._history[segment_id].append((timestamp, speed))

    def predict(
        self,
        segment_id: str,
        camera: CameraObservation | None,
        gps: GpsObservation | None,
        events: list[RoadEvent],
        horizon_minutes: int = 15,
    ) -> SegmentPrediction:
        if camera is None and gps is None:
            raise ValueError("A prediction requires at least one live observation.")
        if camera and camera.segment_id != segment_id:
            raise ValueError("Camera segment_id does not match the requested segment.")
        if gps and gps.segment_id != segment_id:
            raise ValueError("GPS segment_id does not match the requested segment.")
        if any(event.segment_id != segment_id for event in events):
            raise ValueError("All road events must match the requested segment.")

        speed = self._observed_speed(camera, gps)
        if speed is None:
            raise ValueError("Could not derive an observed speed.")
        self.observe(camera, gps, events)

        with self._lock:
            points = list(self._history[segment_id])
        trend_per_minute = self._linear_trend(points)
        predicted_speed = float(np.clip(speed + trend_per_minute * horizon_minutes, 0, 130))

        camera_pressure = 0.0
        stopped_ratio = 0.0
        incident_hint = False
        if camera:
            occupancy = min(camera.vehicle_count / camera.lane_capacity, 1.5)
            camera_pressure = min(occupancy / 1.2, 1.0)
            stopped_ratio = min(camera.stopped_vehicle_count / max(camera.vehicle_count, 1), 1.0)
            incident_hint = camera.incident_hint

        gps_pressure = float(np.clip(1 - predicted_speed / 90, 0, 1))
        event_pressure = self._event_pressure(events)
        congestion = float(
            np.clip(
                0.32 * camera_pressure
                + 0.43 * gps_pressure
                + 0.18 * event_pressure
                + 0.07 * stopped_ratio,
                0,
                1,
            )
        )
        if incident_hint:
            congestion = max(congestion, 0.72)

        incident_probability = float(
            np.clip(
                0.48 * event_pressure
                + 0.30 * stopped_ratio
                + 0.22 * (1 if incident_hint else 0),
                0,
                1,
            )
        )
        level = (
            "severe" if congestion >= 0.78 else
            "heavy" if congestion >= 0.58 else
            "moderate" if congestion >= 0.34 else
            "free_flow"
        )
        modalities = int(camera is not None) + int(gps is not None) + int(bool(events))
        sample_confidence = min(len(points) / 6, 1.0)
        confidence = float(np.clip(0.42 + 0.14 * modalities + 0.16 * sample_confidence, 0, 0.95))
        evidence: list[str] = []
        if camera:
            evidence.append(
                f"Camera: {camera.vehicle_count} vehicles; "
                f"{camera.stopped_vehicle_count} stopped; occupancy {camera_pressure:.0%}."
            )
        if gps:
            evidence.append(
                f"GPS probes: {gps.sample_count} samples at {gps.mean_speed_kmh:.1f} km/h."
            )
        if events:
            evidence.extend(f"Event: {event.kind} (severity {event.severity}/5)." for event in events)
        evidence.append(f"Recent speed trend: {trend_per_minute:+.2f} km/h per minute.")
        return SegmentPrediction(
            segment_id=segment_id,
            predicted_speed_kmh=round(predicted_speed, 1),
            congestion_score=round(congestion, 3),
            congestion_level=level,
            incident_probability=round(incident_probability, 3),
            confidence=round(confidence, 3),
            horizon_minutes=horizon_minutes,
            evidence=evidence,
        )

    @staticmethod
    def _observed_speed(
        camera: CameraObservation | None, gps: GpsObservation | None
    ) -> float | None:
        if camera and gps:
            # Probe speeds get more weight as probe sample volume increases.
            gps_weight = min(0.7, 0.35 + 0.05 * np.log1p(gps.sample_count))
            return float(
                (1 - gps_weight) * camera.mean_vehicle_speed_kmh
                + gps_weight * gps.mean_speed_kmh
            )
        if gps:
            return gps.mean_speed_kmh
        if camera:
            return camera.mean_vehicle_speed_kmh
        return None

    @staticmethod
    def _event_pressure(events: list[RoadEvent]) -> float:
        if not events:
            return 0.0
        pressure = max(
            min(event.severity / 5, 1) * min(0.65 + 0.1 * (event.reports - 1), 1)
            for event in events
        )
        return float(pressure)

    @staticmethod
    def _linear_trend(points: list[tuple[datetime, float]]) -> float:
        if len(points) < 2:
            return 0.0
        now = points[-1][0]
        x = np.array([(stamp - now).total_seconds() / 60 for stamp, _ in points])
        y = np.array([speed for _, speed in points])
        if len(np.unique(x)) < 2:
            return 0.0
        return float(np.polyfit(x, y, 1)[0])


def demo_observations() -> tuple[CameraObservation, GpsObservation, list[RoadEvent]]:
    now = datetime.now(timezone.utc)
    return (
        CameraObservation(
            segment_id="A12",
            observed_at=now,
            vehicle_count=27,
            mean_vehicle_speed_kmh=18,
            lane_capacity=24,
            stopped_vehicle_count=4,
            incident_hint=True,
        ),
        GpsObservation(
            segment_id="A12",
            observed_at=now,
            mean_speed_kmh=22,
            sample_count=38,
        ),
        [
            RoadEvent(
                segment_id="A12",
                kind="stalled_vehicle",
                severity=3,
                reports=2,
                observed_at=now,
            )
        ],
    )
