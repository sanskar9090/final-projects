from __future__ import annotations

from dataclasses import dataclass
from math import hypot


@dataclass(frozen=True)
class Detection:
    x: float
    y: float
    width: float
    height: float
    label: str
    confidence: float


class CentroidTracker:
    """Minimal IoU-free tracker for associating detections between adjacent frames."""

    def __init__(self, max_distance: float = 80.0, max_missed: int = 5) -> None:
        self.max_distance = max_distance
        self.max_missed = max_missed
        self._tracks: dict[int, tuple[float, float, int]] = {}
        self._next_id = 1

    def update(self, detections: list[Detection]) -> dict[int, Detection]:
        assignments: dict[int, Detection] = {}
        unmatched = set(self._tracks)
        for detection in detections:
            center = (detection.x + detection.width / 2, detection.y + detection.height / 2)
            candidates = [
                (hypot(center[0] - x, center[1] - y), track_id)
                for track_id, (x, y, missed) in self._tracks.items()
                if track_id in unmatched and missed <= self.max_missed
            ]
            distance, track_id = min(candidates, default=(float("inf"), -1))
            if distance > self.max_distance:
                track_id = self._next_id
                self._next_id += 1
            else:
                unmatched.discard(track_id)
            assignments[track_id] = detection
            self._tracks[track_id] = (*center, 0)

        for track_id in unmatched:
            x, y, missed = self._tracks[track_id]
            self._tracks[track_id] = (x, y, missed + 1)
        self._tracks = {
            track_id: state
            for track_id, state in self._tracks.items()
            if state[2] <= self.max_missed
        }
        return assignments


def detect_video_frame(frame, model_name: str = "yolov8n.pt") -> list[Detection]:
    """Run optional Ultralytics YOLO on a BGR frame; weights are downloaded by Ultralytics."""
    model = _load_yolo_model(model_name)
    result = model.predict(frame, verbose=False)[0]
    return _detections_from_result(result)


def _load_yolo_model(model_name: str):
    try:
        from ultralytics import YOLO
    except ImportError as exc:
        raise RuntimeError(
            "Video inference needs the optional vision extra. Install with: "
            "pip install -e \".[vision]\""
        ) from exc
    return YOLO(model_name)


def _detections_from_result(result) -> list[Detection]:
    vehicle_labels = {"car", "motorcycle", "bus", "truck", "bicycle"}
    detections: list[Detection] = []
    names = result.names
    for box in result.boxes:
        label = names[int(box.cls[0])]
        if label not in vehicle_labels:
            continue
        x1, y1, x2, y2 = (float(value) for value in box.xyxy[0])
        detections.append(
            Detection(
                x=x1,
                y=y1,
                width=x2 - x1,
                height=y2 - y1,
                label=label,
                confidence=float(box.conf[0]),
            )
        )
    return detections


def analyze_video(
    source: str | int,
    model_name: str = "yolov8n.pt",
) -> dict[str, float | int]:
    """Read a camera/file stream, detect vehicles, and track IDs in each frame."""
    import cv2

    model = _load_yolo_model(model_name)
    capture = cv2.VideoCapture(source)
    if not capture.isOpened():
        capture.release()
        raise RuntimeError(f"Could not open camera/video source: {source}")
    tracker = CentroidTracker()
    frame_count = 0
    observed_vehicle_frames = 0
    try:
        while True:
            ok, frame = capture.read()
            if not ok:
                break
            detections = _detections_from_result(model.predict(frame, verbose=False)[0])
            tracks = tracker.update(detections)
            frame_count += 1
            observed_vehicle_frames += len(tracks)
    finally:
        capture.release()
    return {
        "frames_processed": frame_count,
        "vehicle_detections": observed_vehicle_frames,
        "mean_vehicle_detections_per_frame": (
            round(observed_vehicle_frames / frame_count, 2) if frame_count else 0.0
        ),
    }
