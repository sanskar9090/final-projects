from traffic_predictor.demo import main as run_demo
from traffic_predictor.fusion import TrafficFusionEngine, demo_observations
from traffic_predictor.models import RouteRequest
from traffic_predictor.routing import recommend_route
from traffic_predictor.vision import CentroidTracker, Detection
from fastapi.testclient import TestClient


def test_demo_fuses_inputs_and_routes_around_congested_segment(capsys):
    run_demo()
    output = capsys.readouterr().out
    assert '"congestion_level": "heavy"' in output
    assert '"A12"' not in output.split('"segments": [', 1)[1].split(']', 1)[0]
    assert '"Market"' in output


def test_prediction_rejects_events_for_another_segment():
    camera, gps, events = demo_observations()
    events[0].segment_id = "B08"
    try:
        TrafficFusionEngine().predict("A12", camera, gps, events)
    except ValueError as error:
        assert "road events" in str(error)
    else:
        raise AssertionError("Mismatched event segment should be rejected.")


def test_route_can_exclude_a_segment():
    route = recommend_route(
        RouteRequest(origin="North", destination="Harbor", avoid_segments=["A12"])
    )
    assert "A12" not in route["segments"]
    assert route["nodes"][0] == "North"
    assert route["nodes"][-1] == "Harbor"


def test_centroid_tracker_preserves_id_for_nearby_vehicle():
    tracker = CentroidTracker(max_distance=50)
    first = tracker.update([Detection(10, 10, 20, 20, "car", 0.9)])
    second = tracker.update([Detection(13, 12, 20, 20, "car", 0.9)])
    assert list(first) == list(second)


def test_api_health_and_demo_endpoints():
    from traffic_predictor.api import app

    client = TestClient(app)
    assert client.get("/health").json() == {"status": "ok"}
    response = client.get("/demo")
    assert response.status_code == 200
    assert response.json()["prediction"]["segment_id"] == "A12"
    assert response.json()["route"]["nodes"][0] == "North"
