from __future__ import annotations

from pathlib import Path

import cv2
import numpy as np


WIDTH, HEIGHT, FPS = 960, 540, 15
BACKGROUND = (18, 25, 39)
PANEL = (29, 41, 61)
CYAN = (90, 220, 245)
WHITE = (240, 245, 250)
MUTED = (166, 184, 204)
GREEN = (104, 224, 153)
AMBER = (72, 170, 255)

SLIDES = [
    ("REAL-TIME TRAFFIC INTELLIGENCE", [
        "Multimodal incident & congestion predictor",
        "From camera + probe speeds + road events",
        "to local forecasts and dynamic alternate routes",
    ]),
    ("THREE INPUT STREAMS", [
        "Traffic cameras  ->  vehicle detections and tracks",
        "Authorized GPS   ->  segment speeds and probe counts",
        "Road events      ->  incident type, severity, reports",
    ]),
    ("COMPUTER VISION", [
        "OpenCV reads a camera or video stream frame by frame.",
        "Optional YOLO detects cars, buses, trucks and bikes.",
        "Centroid tracking links detections across frames.",
        "Output: vehicle count, speeds, stopped vehicles, hint.",
    ]),
    ("SEQUENTIAL TIME-SERIES SIGNAL", [
        "Keep a rolling per-segment history of observed speeds.",
        "Estimate recent speed trend from timestamped samples.",
        "Extrapolate that trend to the requested 5-60 min horizon.",
        "Example A12: 46 -> 39 -> 31 -> 22 km/h.",
    ]),
    ("MULTIMODAL FUSION", [
        "Camera congestion / occupancy       32%",
        "Forecast probe-GPS speed pressure    43%",
        "Reported event severity             18%",
        "Stopped-vehicle evidence             7%",
    ]),
    ("INCIDENT & JAM FORECAST", [
        "Demo A12 camera: 27 vehicles, 4 stopped, 18 km/h.",
        "GPS probes: 38 samples at 22 km/h.",
        "Event: stalled vehicle, severity 3/5, 2 reports.",
        "Output includes score, level, probability, confidence.",
    ]),
    ("DYNAMIC ALTERNATE ROUTING", [
        "Dijkstra search uses congestion-adjusted edge costs.",
        "Travel cost = base minutes x (1 + 2 x jam score).",
        "Forecast-heavy segments get higher route cost.",
        "Tiny sample graph demonstrates the route swap.",
    ]),
    ("ONE END-TO-END OPERATION", [
        "Run:  python -m traffic_predictor.demo",
        "Fuse camera + GPS + stalled-vehicle event for A12.",
        "Forecast 15 minutes, then route North -> Harbor.",
        "Example chooses B08/C03 instead of congested A12.",
    ]),
    ("RUN LOCALLY / EXTEND SAFELY", [
        "Install:  python -m pip install -e .",
        "API:  traffic-api  ->  http://127.0.0.1:8000/docs",
        "Use only authorized camera, GPS and incident feeds.",
        "Demo graph + heuristic scores are not production models.",
    ]),
]


def put_lines(frame: np.ndarray, lines: list[str], start_y: int = 176) -> None:
    for index, line in enumerate(lines):
        y = start_y + index * 54
        cv2.circle(frame, (67, y - 7), 5, CYAN if index == 0 else GREEN, -1)
        cv2.putText(
            frame, line, (88, y), cv2.FONT_HERSHEY_SIMPLEX, 0.63, WHITE,
            1, cv2.LINE_AA,
        )


def make_frame(slide_index: int, frame_index: int) -> np.ndarray:
    frame = np.full((HEIGHT, WIDTH, 3), BACKGROUND, dtype=np.uint8)
    title, lines = SLIDES[slide_index]
    cv2.rectangle(frame, (36, 36), (WIDTH - 36, HEIGHT - 36), PANEL, -1)
    cv2.rectangle(frame, (36, 36), (WIDTH - 36, 46), CYAN, -1)
    cv2.putText(
        frame, f"{slide_index + 1:02d} / {len(SLIDES):02d}", (WIDTH - 170, 84),
        cv2.FONT_HERSHEY_SIMPLEX, 0.52, MUTED, 1, cv2.LINE_AA,
    )
    cv2.putText(
        frame, title, (64, 119), cv2.FONT_HERSHEY_SIMPLEX, 0.88,
        CYAN, 2, cv2.LINE_AA,
    )
    put_lines(frame, lines)

    # Animated road strip makes the route segment visually tangible throughout.
    road_y = HEIGHT - 81
    cv2.rectangle(frame, (62, road_y - 12), (WIDTH - 62, road_y + 19), (43, 54, 69), -1)
    for x in range(74, WIDTH - 80, 54):
        dash_x = 74 + ((x - 74 - frame_index * 5) % (WIDTH - 154))
        cv2.line(frame, (dash_x, road_y + 3), (dash_x + 24, road_y + 3), MUTED, 2)
    car_x = 84 + (frame_index * 6) % (WIDTH - 210)
    cv2.rectangle(frame, (car_x, road_y - 10), (car_x + 54, road_y + 8), GREEN, -1)
    cv2.circle(frame, (car_x + 12, road_y + 10), 5, WHITE, -1)
    cv2.circle(frame, (car_x + 42, road_y + 10), 5, WHITE, -1)

    progress = (slide_index + (frame_index % FPS) / FPS) / len(SLIDES)
    cv2.rectangle(frame, (36, HEIGHT - 29), (WIDTH - 36, HEIGHT - 23), (52, 67, 87), -1)
    cv2.rectangle(
        frame, (36, HEIGHT - 29),
        (36 + int((WIDTH - 72) * progress), HEIGHT - 23), AMBER, -1,
    )
    return frame


def main() -> None:
    output = Path(__file__).resolve().parents[1] / "assets" / "traffic_predictor_walkthrough.mp4"
    output.parent.mkdir(parents=True, exist_ok=True)
    writer = cv2.VideoWriter(
        str(output),
        cv2.VideoWriter_fourcc(*"mp4v"),
        FPS,
        (WIDTH, HEIGHT),
    )
    if not writer.isOpened():
        raise RuntimeError("Could not initialize MP4 writer; check OpenCV codec support.")
    try:
        for slide_index in range(len(SLIDES)):
            for frame_index in range(5 * FPS):
                writer.write(make_frame(slide_index, frame_index))
    finally:
        writer.release()
    print(f"Created {output} ({len(SLIDES) * 5} seconds at {FPS} fps)")


if __name__ == "__main__":
    main()
