import os
import subprocess
from pathlib import Path
from textwrap import wrap

from PIL import Image, ImageDraw, ImageFont

OUTPUT = Path(__file__).resolve().parent
WIDTH, HEIGHT = 1280, 720
BACKGROUND = (11, 18, 32)
WHITE = (238, 244, 252)
MUTED = (157, 177, 202)
CYAN = (63, 211, 220)
GREEN = (101, 220, 156)
FONT_DIR = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"

VIDEOS = [
    (
        "01-project-overview.mp4",
        "PROJECT OVERVIEW",
        [
            ("Transactional Wallet Ledger", ["A backend for auditable digital wallet money movement.", "PostgreSQL is the source of truth."]),
            ("Every transfer balances", ["One wallet is debited; another is credited.", "Both entries commit atomically with the balances."]),
            ("Retries do not charge twice", ["A database-unique idempotency key identifies each request.", "Same request again: return the original transaction."]),
        ],
    ),
    (
        "02-stack-and-operations.mp4",
        "STACK & OPERATIONS",
        [
            ("Node.js + TypeScript", ["Express API validates wallet and transfer requests.", "Amounts use integer minor units—not floating point."]),
            ("PostgreSQL + OCC", ["Unique idempotency key and balanced-entry constraint.", "Compare wallet versions; retry if a concurrent write wins."]),
            ("Kafka + background workers", ["Transactional outbox publishes audit events at least once.", "Scheduled reconciliation checks balances and flags suspicious activity."]),
        ],
    ),
    (
        "03-live-transfer-example.mp4",
        "LIVE-STYLE CODE EXAMPLE",
        [
            ("Send 2,500 minor units", ['POST /transfers', 'Idempotency-Key: order-2026-0001', '{"sourceWalletId":"A","destinationWalletId":"B","amountMinor":2500}']),
            ("The service posts once", ["Wallet A: debit 2,500", "Wallet B: credit 2,500", "Both balance updates + ledger entries + audit outbox commit together."]),
            ("Retry after a timeout", ["Send the same key and same payload again.", "The API returns the original transaction ID.", "No second debit. Reusing the key with different data returns HTTP 409."]),
        ],
    ),
]


def font(name: str, size: int) -> ImageFont.FreeTypeFont:
    path = FONT_DIR / name
    if path.exists():
        return ImageFont.truetype(str(path), size)
    return ImageFont.load_default()


def render_slide(section: str, title: str, lines: list[str], slide_no: int, total: int) -> Image.Image:
    image = Image.new("RGB", (WIDTH, HEIGHT), BACKGROUND)
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((66, 54, 290, 104), radius=20, fill=(20, 54, 72))
    draw.text((86, 66), section, font=font("segoeuib.ttf", 22), fill=CYAN)
    draw.text((68, 155), title, font=font("segoeuib.ttf", 49), fill=WHITE)
    draw.rounded_rectangle((68, 232, 1212, 237), radius=2, fill=(36, 59, 81))
    y = 292
    for index, line in enumerate(lines):
        marker_color = GREEN if index == 0 else CYAN
        draw.ellipse((76, y + 10, 91, y + 25), fill=marker_color)
        font_name = "consola.ttf" if line.startswith(("POST ", "Idempotency", "{")) else "segoeui.ttf"
        selected_font = font(font_name, 28)
        chunks = wrap(line, width=76)
        for chunk in chunks:
            draw.text((116, y), chunk, font=selected_font, fill=WHITE if index == 0 else MUTED)
            y += 44
        y += 22
    draw.text((68, 657), "TRANSACTIONAL WALLET  |  DOUBLE-ENTRY  |  STRICT IDEMPOTENCY", font=font("segoeuib.ttf", 18), fill=MUTED)
    draw.text((1162, 654), f"{slide_no}/{total}", font=font("segoeuib.ttf", 20), fill=CYAN)
    return image


def main() -> None:
    ffmpeg = os.environ.get("FFMPEG", "ffmpeg")
    codec = os.environ.get("FFMPEG_CODEC", "libopenh264")
    for filename, section, slides in VIDEOS:
        output_path = OUTPUT / filename
        command = [
            ffmpeg, "-y", "-loglevel", "error",
            "-f", "rawvideo", "-pixel_format", "rgb24", "-video_size", "640x360",
            "-framerate", "12", "-i", "-", "-c:v", codec,
            "-pix_fmt", "yuv420p", "-r", "24", "-movflags", "+faststart",
            str(output_path),
        ]
        process = subprocess.Popen(command, stdin=subprocess.PIPE)
        if process.stdin is None:
            raise RuntimeError("Could not open FFmpeg input stream")
        try:
            for index, (title, lines) in enumerate(slides):
                slide = render_slide(section, title, lines, index + 1, len(slides))
                frame = slide.resize((640, 360), Image.Resampling.LANCZOS).tobytes()
                for _ in range(48):
                    process.stdin.write(frame)
        finally:
            process.stdin.close()
        if process.wait() != 0:
            raise RuntimeError(f"FFmpeg failed to create {output_path}")
        print(f"Created {output_path}")


if __name__ == "__main__":
    main()
