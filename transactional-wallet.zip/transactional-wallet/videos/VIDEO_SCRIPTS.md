# Short video scripts

The accompanying MP4s are brief animated slides. The code/example clip is a live-style walkthrough, not a recording of a running database session. Each slide's narration is included below for use in a narrated recording.

1. **01-project-overview.mp4** — “This project is a transactional digital wallet and financial ledger backend. Its core goal is to make each money movement auditable and safe to retry: a transfer is recorded as a matching debit and credit, while an idempotency key prevents a network retry from charging twice.”
2. **02-stack-and-operations.mp4** — “The API is written in TypeScript on Node.js. PostgreSQL stores wallet balances, the immutable ledger, unique idempotency keys, and a transactional outbox. Optimistic concurrency control compares the balance version before update. A background worker publishes audit events to Kafka and periodically reconciles the ledger.”
3. **03-live-transfer-example.mp4** — “Here is a live transfer example. Wallet A sends 2,500 minor units to Wallet B with an Idempotency-Key. The database commits a debit and equal credit, updates both balances, and writes an audit event together. If the client retries the same request after a timeout, the unique key returns the original transaction instead of moving money twice.”

These generated clips are text-led project explainers and do not claim to show an actual terminal session or recorded execution.
