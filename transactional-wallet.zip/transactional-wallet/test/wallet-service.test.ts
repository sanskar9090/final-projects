import assert from "node:assert/strict";
import test from "node:test";
import { hashTransferRequest } from "../src/transfer-fingerprint";

test("idempotency request hash is stable for identical transfer fields", () => {
  const input = { sourceWalletId: "wallet-a", destinationWalletId: "wallet-b", amountMinor: 1250 };
  assert.equal(hashTransferRequest(input), hashTransferRequest(input));
  assert.notEqual(hashTransferRequest(input), hashTransferRequest({ ...input, amountMinor: 1251 }));
});

test("ledger entries balance for a transfer", () => {
  const amountMinor = 2999;
  const entries = [
    { direction: "debit", amountMinor },
    { direction: "credit", amountMinor }
  ];
  const debits = entries.filter((entry) => entry.direction === "debit")
    .reduce((total, entry) => total + entry.amountMinor, 0);
  const credits = entries.filter((entry) => entry.direction === "credit")
    .reduce((total, entry) => total + entry.amountMinor, 0);
  assert.equal(debits, credits);
});
