# Transactional Wallet Ledger

A Node.js/TypeScript wallet API using PostgreSQL for the authoritative ledger and Kafka for asynchronous audit events. Money is represented as integer minor units (for example, 1250 = $12.50). This is a runnable reference implementation, not a bank-ready or regulatory-certified payment processor.

## Guarantees and design

- **Idempotent transfers:** `ledger_transactions.idempotency_key` is unique in PostgreSQL. The key, request fingerprint, ledger entries, balance updates, and outbox event commit in one database transaction. Repeating the same request returns the original transaction; reusing the key for a different payload returns HTTP 409.
- **Double-entry:** Each successful transfer records one debit and one credit. A deferred PostgreSQL constraint trigger checks at commit that a transaction has exactly two entries, equal totals, and one currency.
- **Concurrent wallet updates:** Balance updates compare the previously read wallet version and mutate it with a conditional `UPDATE`; a lost compare-and-swap rolls back and retries. Wallet rows are updated in deterministic ID order to avoid transfer deadlocks; writes don't lock an entire table.
- **Durable asynchronous audit:** An outbox row is stored in the same transaction as the transfer. A worker publishes pending events to Kafka; consumers should deduplicate by event key because delivery is at least once.
- **Reconciliation:** A periodic worker compares wallet balances to signed ledger-entry totals and checks entry balance/count, recording each run and logging anomalies.
- **Operational caveat:** This sample omits authentication/authorization, card network integrations, KYC/AML, currency conversion, settlement, rate limiting, PII controls, and production Kafka/PostgreSQL security. Do not expose it to real customer funds without a formal security, resilience, compliance, and accounting review.

## Run locally

Requirements: Node.js 20+, Docker Compose.

```sh
copy .env.example .env
docker compose up --build
```

Postgres schema is applied at first volume initialization, and the API also applies migrations on startup. API: `http://localhost:3000`.

## API

Create a wallet (the response includes its UUID):

```sh
curl -X POST http://localhost:3000/wallets ^
  -H "Content-Type: application/json" ^
  -d "{\"ownerId\":\"customer-1\",\"currency\":\"USD\"}"
```

Read wallet balance and OCC version:

```sh
curl http://localhost:3000/wallets/WALLET_UUID
```

Transfers require a globally unique idempotency key:

```sh
curl -X POST http://localhost:3000/transfers ^
  -H "Content-Type: application/json" ^
  -H "Idempotency-Key: order-2026-0001" ^
  -d "{\"sourceWalletId\":\"SOURCE_UUID\",\"destinationWalletId\":\"DEST_UUID\",\"amountMinor\":2500}"
```

The source wallet must be funded first. There is intentionally no unsafe "set balance" endpoint; production funding should be represented as a separately authorized balanced journal operation.

## Development and tests

```sh
npm install
npm test
npm run build
```

The test suite currently contains fast deterministic unit tests. Database contention, trigger enforcement, and Kafka delivery should also be exercised in an integration/staging environment before production.

## Video deliverables

See `videos/` for three short MP4 explainers: a project overview, a technology walkthrough, and a live-style code/transfer example. They are generated educational animations, not captured terminal recordings or actual executions against a running database.
