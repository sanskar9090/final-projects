import { migrate, pool } from "./db";

migrate()
  .then(() => console.log("Database schema is up to date"))
  .catch((error: unknown) => {
    console.error("Database migration failed", error);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
