import { Kafka } from "kafkajs";
import { config } from "./config";
import { pool } from "./db";

const kafka = new Kafka({ clientId: "ledger-wallet", brokers: config.KAFKA_BROKERS });
const producer = kafka.producer();
let stopped = false;

async function publishOutboxBatch(): Promise<void> {
  const result = await pool.query(
    `SELECT id, event_key, event_type, payload
       FROM audit_outbox WHERE published_at IS NULL
      ORDER BY id LIMIT 100`
  );
  for (const row of result.rows as Array<{
    id: string;
    event_key: string;
    event_type: string;
    payload: unknown;
  }>) {
    await producer.send({
      topic: "ledger.audit",
      messages: [{
        key: row.event_key,
        value: JSON.stringify({ type: row.event_type, ...row.payload as object })
      }]
    });
    await pool.query("UPDATE audit_outbox SET published_at = now() WHERE id = $1", [row.id]);
  }
}

async function reconcile(): Promise<void> {
  const mismatches = await pool.query(
    `SELECT w.id AS wallet_id, w.balance_minor AS wallet_balance,
            COALESCE(sum(CASE WHEN e.direction = 'credit' THEN e.amount_minor
                              ELSE -e.amount_minor END), 0)::bigint AS ledger_balance
       FROM wallets w
       LEFT JOIN ledger_entries e ON e.wallet_id = w.id
      GROUP BY w.id, w.balance_minor
     HAVING w.balance_minor <> COALESCE(sum(CASE WHEN e.direction = 'credit' THEN e.amount_minor
                                                  ELSE -e.amount_minor END), 0)`
  );
  const malformed = await pool.query(
    `SELECT transaction_id
       FROM ledger_entries GROUP BY transaction_id
      HAVING count(*) <> 2
          OR sum(CASE WHEN direction = 'debit' THEN amount_minor ELSE 0 END)
             <> sum(CASE WHEN direction = 'credit' THEN amount_minor ELSE 0 END)
          OR count(DISTINCT currency) <> 1`
  );
  const suspiciousActivity = await pool.query(
    `SELECT id, source_wallet_id, amount_minor, created_at
       FROM ledger_transactions
      WHERE amount_minor >= 1000000
        AND created_at >= now() - interval '5 minutes'
     UNION ALL
     SELECT NULL::uuid, source_wallet_id, count(*)::bigint, max(created_at)
       FROM ledger_transactions
      WHERE created_at >= now() - interval '5 minutes'
      GROUP BY source_wallet_id
     HAVING count(*) >= 10`
  );
  const anomalies = [
    ...mismatches.rows.map((row) => ({ type: "wallet_balance_mismatch", ...row })),
    ...malformed.rows.map((row) => ({ type: "unbalanced_transaction", ...row })),
    ...suspiciousActivity.rows.map((row) => ({
      type: row.id === null ? "high_transfer_velocity" : "large_transfer",
      ...row
    }))
  ];
  await pool.query(
    `INSERT INTO reconciliation_runs (transactions_checked, anomalies)
     SELECT count(DISTINCT transaction_id), $1::jsonb FROM ledger_entries`,
    [JSON.stringify(anomalies)]
  );
  if (anomalies.length > 0) {
    console.error("Ledger reconciliation detected anomalies", anomalies);
  }
}

export async function startWorkers(): Promise<void> {
  await producer.connect();
  const outboxTimer = setInterval(() => {
    if (!stopped) {
      void publishOutboxBatch().catch((error: unknown) => console.error("Outbox publish failed", error));
    }
  }, config.OUTBOX_POLL_INTERVAL_MS);
  const reconcileTimer = setInterval(() => {
    if (!stopped) {
      void reconcile().catch((error: unknown) => console.error("Reconciliation failed", error));
    }
  }, config.RECONCILIATION_INTERVAL_MS);
  outboxTimer.unref();
  reconcileTimer.unref();
}

export async function stopWorkers(): Promise<void> {
  stopped = true;
  await producer.disconnect();
}
