import { createHash } from "node:crypto";

export interface TransferFingerprintInput {
  sourceWalletId: string;
  destinationWalletId: string;
  amountMinor: number;
}

export function hashTransferRequest(input: TransferFingerprintInput): string {
  return createHash("sha256")
    .update(JSON.stringify([
      input.sourceWalletId,
      input.destinationWalletId,
      input.amountMinor
    ]))
    .digest("hex");
}
