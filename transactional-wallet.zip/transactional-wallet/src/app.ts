import express, { type NextFunction, type Request, type Response } from "express";
import { z } from "zod";
import { DomainError, createWallet, getWallet, transfer } from "./wallet-service";

export const app = express();
app.use(express.json({ limit: "32kb" }));

const createWalletSchema = z.object({
  ownerId: z.string().min(1).max(200),
  currency: z.string().regex(/^[A-Z]{3}$/)
});

const transferSchema = z.object({
  sourceWalletId: z.string().uuid(),
  destinationWalletId: z.string().uuid(),
  amountMinor: z.number().int().positive().safe()
}).refine((body) => body.sourceWalletId !== body.destinationWalletId, {
  message: "Source and destination wallets must differ"
});

app.get("/health", (_request, response) => response.json({ status: "ok" }));

app.post("/wallets", async (request, response, next) => {
  try {
    const body = createWalletSchema.parse(request.body);
    response.status(201).json(await createWallet(body.ownerId, body.currency));
  } catch (error) {
    next(error);
  }
});

app.get("/wallets/:walletId", async (request, response, next) => {
  try {
    const walletId = z.string().uuid().parse(request.params.walletId);
    response.json(await getWallet(walletId));
  } catch (error) {
    next(error);
  }
});

app.post("/transfers", async (request, response, next) => {
  try {
    const idempotencyKey = request.header("Idempotency-Key");
    if (!idempotencyKey || idempotencyKey.length > 200) {
      throw new DomainError("A valid Idempotency-Key header is required", 400);
    }
    const body = transferSchema.parse(request.body);
    response.status(201).json(await transfer({ ...body, idempotencyKey }));
  } catch (error) {
    next(error);
  }
});

app.use((error: unknown, _request: Request, response: Response, _next: NextFunction) => {
  if (error instanceof z.ZodError) {
    response.status(400).json({ error: "Invalid request", details: error.issues });
    return;
  }
  if (error instanceof DomainError) {
    response.status(error.statusCode).json({ error: error.message });
    return;
  }
  console.error("Unhandled request error", error);
  response.status(500).json({ error: "Internal server error" });
});
