import { app } from "./app";
import { config } from "./config";
import { migrate, pool } from "./db";
import { startWorkers, stopWorkers } from "./workers";

async function main(): Promise<void> {
  await migrate();
  await startWorkers();
  const server = app.listen(config.PORT, () => {
    console.log(`Wallet API listening on port ${config.PORT}`);
  });

  const shutdown = async (): Promise<void> => {
    server.close();
    await stopWorkers();
    await pool.end();
  };
  process.once("SIGINT", () => void shutdown());
  process.once("SIGTERM", () => void shutdown());
}

main().catch((error: unknown) => {
  console.error("Server startup failed", error);
  process.exitCode = 1;
});
