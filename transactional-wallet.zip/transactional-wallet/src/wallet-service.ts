import type { PoolClient } from "pg";
import { config } from "./config";
import { inTransaction, pool } from "./db";
import { hashTransferRequest } from "./transfer-fingerprint";

export class DomainError extends Error {
  constructor(
    message: string,
    public readonly statusCode: number
  ) {
    super(message);
    this.name = "DomainError";
  }
}

export interface TransferInput {
  idempotencyKey: string;
  sourceWalletId: string;
  destinationWalletId: string;
  amountMinor: number;
}

export interface TransferResult {
  transactionId: string;
  status: "posted";
  amountMinor: number;
  currency: string;
}

interface WalletRow {
  id: string;
  currency: string;
  balance_minor: string;
  version: string;
}

export async function createWallet(ownerId: string, currency: string): Promise<{
  id: string;
  ownerId: string;
  currency: string;
  balanceMinor: string;
}> {
  const result = await pool.query(
    "INSERT INTO wallets (owner_id, currency) VALUES ($1, $2) RETURNING id, owner_id, currency, balance_minor",
    [ownerId, currency]
  );
  const row = result.rows[0] as { id: string; owner_id: string; currency: string; balance_minor: string };
  return {
    id: row.id,
    ownerId: row.owner_id,
    currency: row.currency,
    balanceMinor: row.balance_minor
  };
}

export async function getWallet(walletId: string): Promise<{
  id: string;
  ownerId: string;
  currency: string;
  balanceMinor: string;
  version: string;
}> {
  const result = await pool.query(
    `SELECT id, owner_id, currency, balance_minor, version
       FROM wallets WHERE id = $1`,
    [walletId]
  );
  const row = result.rows[0] as {
    id: string;
    owner_id: string;
    currency: string;
    balance_minor: string;
    version: string;
  } | undefined;
  if (!row) {
    throw new DomainError("Wallet was not found", 404);
  }
  return {
    id: row.id,
    ownerId: row.owner_id,
    currency: row.currency,
    balanceMinor: row.balance_minor,
    version: row.version
  };
}

async function transferOnce(input: TransferInput, requestHash: string): Promise<TransferResult> {
  return inTransaction(async (client: PoolClient) => {
    const wallets = await client.query(
      `SELECT id, currency, balance_minor, version
         FROM wallets
        WHERE id = ANY($1::uuid[])
        ORDER BY id`,
      [[input.sourceWalletId, input.destinationWalletId]]
    );
    if (wallets.rowCount !== 2) {
      throw new DomainError("Source or destination wallet was not found", 404);
    }

    const source = wallets.rows.find((wallet: WalletRow) => wallet.id === input.sourceWalletId) as WalletRow;
    const destination = wallets.rows.find((wallet: WalletRow) => wallet.id === input.destinationWalletId) as WalletRow;
    if (source.currency !== destination.currency) {
      throw new DomainError("Wallet currencies must match", 422);
    }

    const inserted = await client.query(
      `INSERT INTO ledger_transactions
         (idempotency_key, request_hash, source_wallet_id, destination_wallet_id, amount_minor, currency)
       VALUES ($1, $2, $3, $4, $5, $6)
       ON CONFLICT (idempotency_key) DO NOTHING
       RETURNING id`,
      [
        input.idempotencyKey,
        requestHash,
        input.sourceWalletId,
        input.destinationWalletId,
        input.amountMinor,
        source.currency
      ]
    );

    if (inserted.rowCount === 0) {
      const existing = await client.query(
        `SELECT id, request_hash, amount_minor, currency
           FROM ledger_transactions WHERE idempotency_key = $1`,
        [input.idempotencyKey]
      );
      const row = existing.rows[0] as {
        id: string;
        request_hash: string;
        amount_minor: string;
        currency: string;
      } | undefined;
      if (!row) {
        throw new Error("Idempotency conflict row was not visible after conflict");
      }
      if (row.request_hash !== requestHash) {
        throw new DomainError("Idempotency key was already used for a different request", 409);
      }
      return {
        transactionId: row.id,
        status: "posted",
        amountMinor: Number(row.amount_minor),
        currency: row.currency
      };
    }

    const transactionId = (inserted.rows[0] as { id: string }).id;
    for (const wallet of wallets.rows as WalletRow[]) {
      const isSource = wallet.id === input.sourceWalletId;
      const updated = await client.query(
        `UPDATE wallets
            SET balance_minor = balance_minor ${isSource ? "-" : "+"} $1,
                version = version + 1
          WHERE id = $2 AND version = $3::bigint${isSource ? " AND balance_minor >= $1" : ""}`,
        [input.amountMinor, wallet.id, wallet.version]
      );
      if (updated.rowCount !== 1) {
        if (isSource) {
          const current = await client.query(
            "SELECT version, balance_minor FROM wallets WHERE id = $1",
            [wallet.id]
          );
          const row = current.rows[0] as { version: string; balance_minor: string } | undefined;
          if (row?.version === wallet.version && BigInt(row.balance_minor) < BigInt(input.amountMinor)) {
            throw new DomainError("Insufficient wallet funds", 422);
          }
        }
        throw new Error("OCC_CONFLICT");
      }
    }

    await client.query(
      `INSERT INTO ledger_entries (transaction_id, wallet_id, direction, amount_minor, currency)
       VALUES ($1, $2, 'debit', $3, $4), ($1, $5, 'credit', $3, $4)`,
      [
        transactionId,
        input.sourceWalletId,
        input.amountMinor,
        source.currency,
        input.destinationWalletId
      ]
    );

    await client.query(
      `INSERT INTO audit_outbox (event_key, event_type, payload)
       VALUES ($1, 'wallet.transfer.posted', $2::jsonb)`,
      [
        `transfer:${transactionId}`,
        JSON.stringify({
          transactionId,
          sourceWalletId: input.sourceWalletId,
          destinationWalletId: input.destinationWalletId,
          amountMinor: input.amountMinor,
          currency: source.currency
        })
      ]
    );

    return {
      transactionId,
      status: "posted",
      amountMinor: input.amountMinor,
      currency: source.currency
    };
  });
}

export async function transfer(input: TransferInput): Promise<TransferResult> {
  const requestHash = hashTransferRequest(input);
  for (let attempt = 0; attempt < config.OCC_MAX_RETRIES; attempt += 1) {
    try {
      return await transferOnce(input, requestHash);
    } catch (error) {
      if (!(error instanceof Error) || error.message !== "OCC_CONFLICT") {
        throw error;
      }
      if (attempt === config.OCC_MAX_RETRIES - 1) {
        throw new DomainError("Wallet is busy; retry using the same idempotency key", 409);
      }
    }
  }
  throw new Error("Unreachable OCC retry state");
}
