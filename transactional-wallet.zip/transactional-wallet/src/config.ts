import "dotenv/config";
import { z } from "zod";

const configSchema = z.object({
  PORT: z.coerce.number().int().positive().default(3000),
  DATABASE_URL: z.string().min(1),
  KAFKA_BROKERS: z.string().default("localhost:9092"),
  RECONCILIATION_INTERVAL_MS: z.coerce.number().int().positive().default(30_000),
  OUTBOX_POLL_INTERVAL_MS: z.coerce.number().int().positive().default(1_000),
  OCC_MAX_RETRIES: z.coerce.number().int().positive().max(20).default(5)
});

const parsed = configSchema.safeParse(process.env);
if (!parsed.success) {
  throw new Error(`Invalid configuration: ${parsed.error.message}`);
}

export const config = {
  ...parsed.data,
  KAFKA_BROKERS: parsed.data.KAFKA_BROKERS.split(",").map((broker) => broker.trim())
};
