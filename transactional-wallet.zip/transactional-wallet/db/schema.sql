CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS wallets (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id TEXT NOT NULL,
  currency CHAR(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  balance_minor BIGINT NOT NULL DEFAULT 0 CHECK (balance_minor >= 0),
  version BIGINT NOT NULL DEFAULT 0 CHECK (version >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS wallets_owner_idx ON wallets (owner_id);

CREATE TABLE IF NOT EXISTS ledger_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  idempotency_key TEXT NOT NULL UNIQUE CHECK (length(idempotency_key) BETWEEN 1 AND 200),
  request_hash CHAR(64) NOT NULL,
  source_wallet_id UUID NOT NULL REFERENCES wallets(id),
  destination_wallet_id UUID NOT NULL REFERENCES wallets(id),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  status TEXT NOT NULL DEFAULT 'posted' CHECK (status IN ('posted')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK (source_wallet_id <> destination_wallet_id)
);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id BIGSERIAL PRIMARY KEY,
  transaction_id UUID NOT NULL REFERENCES ledger_transactions(id),
  wallet_id UUID NOT NULL REFERENCES wallets(id),
  direction TEXT NOT NULL CHECK (direction IN ('debit', 'credit')),
  amount_minor BIGINT NOT NULL CHECK (amount_minor > 0),
  currency CHAR(3) NOT NULL CHECK (currency ~ '^[A-Z]{3}$'),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ledger_entries_wallet_idx ON ledger_entries (wallet_id, created_at);
CREATE INDEX IF NOT EXISTS ledger_entries_transaction_idx ON ledger_entries (transaction_id);

CREATE TABLE IF NOT EXISTS audit_outbox (
  id BIGSERIAL PRIMARY KEY,
  event_key TEXT NOT NULL UNIQUE,
  event_type TEXT NOT NULL,
  payload JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  published_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS audit_outbox_pending_idx ON audit_outbox (id) WHERE published_at IS NULL;

CREATE TABLE IF NOT EXISTS reconciliation_runs (
  id BIGSERIAL PRIMARY KEY,
  checked_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  transactions_checked BIGINT NOT NULL,
  anomalies JSONB NOT NULL
);

CREATE OR REPLACE FUNCTION assert_ledger_transaction_balanced()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  entry_count BIGINT;
  debit_total NUMERIC;
  credit_total NUMERIC;
  currency_count BIGINT;
BEGIN
  SELECT count(*),
         COALESCE(sum(amount_minor) FILTER (WHERE direction = 'debit'), 0),
         COALESCE(sum(amount_minor) FILTER (WHERE direction = 'credit'), 0),
         count(DISTINCT currency)
    INTO entry_count, debit_total, credit_total, currency_count
    FROM ledger_entries
   WHERE transaction_id = NEW.id;

  IF entry_count <> 2 OR debit_total <> credit_total OR currency_count <> 1 THEN
    RAISE EXCEPTION 'ledger transaction % is unbalanced', NEW.id
      USING ERRCODE = '23514';
  END IF;
  RETURN NULL;
END;
$$;

CREATE OR REPLACE FUNCTION reject_ledger_mutation()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
  RAISE EXCEPTION 'ledger records are immutable'
    USING ERRCODE = '23514';
END;
$$;

CREATE OR REPLACE FUNCTION assert_ledger_entries_balanced()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
  entry_count BIGINT;
  debit_total NUMERIC;
  credit_total NUMERIC;
  currency_count BIGINT;
BEGIN
  SELECT count(*),
         COALESCE(sum(amount_minor) FILTER (WHERE direction = 'debit'), 0),
         COALESCE(sum(amount_minor) FILTER (WHERE direction = 'credit'), 0),
         count(DISTINCT currency)
    INTO entry_count, debit_total, credit_total, currency_count
    FROM ledger_entries
   WHERE transaction_id = NEW.transaction_id;

  IF entry_count <> 2 OR debit_total <> credit_total OR currency_count <> 1 THEN
    RAISE EXCEPTION 'ledger transaction % is unbalanced', NEW.transaction_id
      USING ERRCODE = '23514';
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS ledger_transaction_balance_trigger ON ledger_transactions;
CREATE CONSTRAINT TRIGGER ledger_transaction_balance_trigger
AFTER INSERT ON ledger_transactions
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION assert_ledger_transaction_balanced();

DROP TRIGGER IF EXISTS ledger_entries_balance_trigger ON ledger_entries;
CREATE CONSTRAINT TRIGGER ledger_entries_balance_trigger
AFTER INSERT ON ledger_entries
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION assert_ledger_entries_balanced();

DROP TRIGGER IF EXISTS ledger_transactions_immutable_trigger ON ledger_transactions;
CREATE TRIGGER ledger_transactions_immutable_trigger
BEFORE UPDATE OR DELETE ON ledger_transactions
FOR EACH ROW EXECUTE FUNCTION reject_ledger_mutation();

DROP TRIGGER IF EXISTS ledger_entries_immutable_trigger ON ledger_entries;
CREATE TRIGGER ledger_entries_immutable_trigger
BEFORE UPDATE OR DELETE ON ledger_entries
FOR EACH ROW EXECUTE FUNCTION reject_ledger_mutation();
