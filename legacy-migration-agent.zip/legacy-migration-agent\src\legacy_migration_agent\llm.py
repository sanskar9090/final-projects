import json
import os
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


class OpenAICompatibleClient:
    """Small, dependency-free adapter for chat-completions-compatible APIs."""

    def __init__(self):
        self.api_key = os.getenv("MIGRATOR_API_KEY")
        self.base_url = os.getenv("MIGRATOR_BASE_URL", "https://api.openai.com/v1").rstrip("/")
        self.model = os.getenv("MIGRATOR_MODEL", "gpt-4o-mini")

    @property
    def enabled(self) -> bool:
        return bool(self.api_key)

    def propose(
        self,
        source: str,
        target: str,
        feedback: str = "",
        context: str = "",
    ) -> str:
        if not self.api_key:
            raise RuntimeError("MIGRATOR_API_KEY is required to use the LLM provider")
        prompt = (
            f"Migrate this source to {target}. Return only the complete migrated "
            "source file, with no Markdown fences. Preserve behavior and imports. "
            "Do not claim tests passed."
        )
        if feedback:
            prompt += f"\n\nThe previous proposal failed validation:\n{feedback}"
        if context:
            prompt += (
                "\n\nRelated repository context retrieved from the configured "
                f"vector database:\n{context}"
            )
        payload = json.dumps({
            "model": self.model,
            "temperature": 0,
            "messages": [
                {"role": "system", "content": "You are a careful code migration developer."},
                {"role": "user", "content": f"{prompt}\n\nSource:\n{source}"},
            ],
        }).encode("utf-8")
        request = Request(
            f"{self.base_url}/chat/completions",
            data=payload,
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urlopen(request, timeout=90) as response:
                data = json.loads(response.read().decode("utf-8"))
        except (HTTPError, URLError, TimeoutError) as exc:
            raise RuntimeError(f"LLM request failed: {exc}") from exc
        try:
            content = data["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError) as exc:
            raise RuntimeError("LLM response did not contain a chat completion") from exc
        if not isinstance(content, str) or not content.strip():
            raise RuntimeError("LLM returned an empty migration proposal")
        return _strip_fence(content.strip())


def _strip_fence(content: str) -> str:
    if not content.startswith("```"):
        return content
    lines = content.splitlines()
    if len(lines) < 3 or not lines[-1].startswith("```"):
        return content
    return "\n".join(lines[1:-1]).lstrip()
