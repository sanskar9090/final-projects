from pathlib import Path

import pytest

from legacy_migration_agent.codemods import (
    migrate_python,
    migrate_react_class,
    verify_change,
)
from legacy_migration_agent.models import ProposedChange
from legacy_migration_agent.parsers import StructuralValidationError, javascript_structure


REACT_CLASS = '''import React from "react";

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = { count: 0, label: "Clicks" };
  }
  render() {
    return <main><h1>{this.state.label}</h1><p>{this.state.count}</p></main>;
  }
}
'''


def test_python2_subset_converts_and_preserves_unicode_offsets():
    source = 'print "café"\nvalues = list(xrange(3))\n'
    result = migrate_python(source)
    assert 'print("café")' in result
    assert "range(3)" in result


def test_python2_redirected_print_is_rejected():
    with pytest.raises(StructuralValidationError, match="Redirected"):
        migrate_python('print >>sys.stderr, "no"\n')


def test_react_ast_codmod_creates_hooks_and_parses():
    migrated = migrate_react_class(REACT_CLASS)
    structure = javascript_structure(migrated)
    assert structure.classes == 0
    assert structure.hooks == 2
    verify_change(ProposedChange(Path("App.jsx"), REACT_CLASS, migrated), "react-hooks")


def test_react_lifecycle_is_rejected():
    source = REACT_CLASS.replace(
        "  render() {",
        "  componentDidMount() { console.log('mounted'); }\n  render() {",
    )
    with pytest.raises(StructuralValidationError, match="Lifecycle"):
        migrate_react_class(source)


def test_repository_context_chunks_overlap_without_losing_lines():
    from legacy_migration_agent.vector_context import chunk_source

    chunks = chunk_source("\n".join(f"line-{number}" for number in range(100)))
    assert len(chunks) == 2
    assert chunks[0].splitlines()[-10:] == chunks[1].splitlines()[:10]
    assert chunks[1].splitlines()[-1] == "line-99"
