import ast
import re

from .models import MigrationTask, ProposedChange
from .parsers import (
    StructuralValidationError,
    javascript_structure,
    parse_javascript,
    parse_python,
    python_structure,
)


def migrate_python(source: str) -> str:
    """Convert a safe subset of common Python 2 syntax using AST locations."""
    for line_number, line in enumerate(source.splitlines(), start=1):
        if re.match(r"^\s*print\s*>>", line):
            raise StructuralValidationError(
                f"Redirected Python 2 print at line {line_number} needs manual migration"
            )
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        if "Missing parentheses in call to 'print'" in str(exc):
            source = _convert_python2_print(source)
            tree = parse_python(source)
        else:
            raise StructuralValidationError(
                f"Cannot safely parse legacy Python source: {exc}"
            ) from exc

    lines = source.splitlines(keepends=True)
    by_line: dict[int, list[tuple[int, int, str]]] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
            if node.func.id in {"xrange", "raw_input"} and node.lineno == node.end_lineno:
                line = lines[node.lineno - 1]
                start = _byte_column_to_character(line, node.func.col_offset)
                end = _byte_column_to_character(line, node.func.end_col_offset)
                by_line.setdefault(node.lineno - 1, []).append(
                    (start, end,
                     {"xrange": "range", "raw_input": "input"}[node.func.id])
                )
    for index, edits in by_line.items():
        line = lines[index]
        for start, end, replacement in sorted(edits, reverse=True):
            lines[index] = lines[index][:start] + replacement + lines[index][end:]
    migrated = "".join(lines)
    parse_python(migrated)
    return migrated


def _byte_column_to_character(line: str, byte_column: int) -> int:
    return len(line.encode("utf-8")[:byte_column].decode("utf-8"))


def _convert_python2_print(source: str) -> str:
    output = []
    for line_number, line in enumerate(source.splitlines(keepends=True), start=1):
        match = re.match(r"^(\s*)print\s+(.+?)(\r?\n)?$", line)
        if not match:
            output.append(line)
            continue
        indent, expression, ending = match.groups()
        if expression.startswith(">>"):
            raise StructuralValidationError(
                f"Redirected Python 2 print at line {line_number} needs manual migration"
            )
        suffix = ending or ""
        output.append(f"{indent}print({expression}){suffix}")
    return "".join(output)


def migrate_react_class(source: str) -> str:
    """Migrate a single simple React class component to a function + useState."""
    tree = parse_javascript(source)
    root = tree.root_node
    class_node = _first_named(root, "class_declaration")
    if class_node is None:
        raise StructuralValidationError("No React class declaration was found")
    class_text = source[class_node.start_byte:class_node.end_byte]
    if not re.search(r"extends\s+(?:React\.)?Component\b", class_text):
        raise StructuralValidationError("Only React.Component classes are supported")
    if _first_named(class_node, "method_definition", text_source=source,
                    predicate=lambda text: bool(re.search(r"\bcomponent[A-Z]\w*\s*\(", text))):
        raise StructuralValidationError("Lifecycle methods require manual migration")
    if _first_named(class_node, "method_definition", text_source=source,
                    predicate=lambda text: bool(re.search(r"\b(?:handle\w+|on\w+)\s*\(", text))):
        raise StructuralValidationError("Class methods/handlers require manual migration")

    class_body = next((child for child in class_node.named_children
                       if child.type == "class_body"), None)
    if class_body is None:
        raise StructuralValidationError("Class body could not be parsed")
    methods = [child for child in class_body.named_children
               if child.type == "method_definition"]
    render = next((method for method in methods
                   if source[method.start_byte:method.end_byte].lstrip().startswith("render(")
                   or source[method.start_byte:method.end_byte].lstrip().startswith("render (")), None)
    if render is None:
        raise StructuralValidationError("Expected a render() method")
    constructor = next((method for method in methods
                        if source[method.start_byte:method.end_byte].lstrip().startswith("constructor(")), None)
    if len(methods) != (2 if constructor else 1):
        raise StructuralValidationError("Only constructor() and render() methods are supported")

    name_node = class_node.child_by_field_name("name")
    if name_node is None:
        raise StructuralValidationError("Class name could not be determined")
    name = source[name_node.start_byte:name_node.end_byte]
    replace_node = class_node
    if class_node.parent and class_node.parent.type == "export_statement":
        export_text = source[class_node.parent.start_byte:class_node.parent.end_byte]
        if not export_text.lstrip().startswith("export default"):
            raise StructuralValidationError("Only default-exported or local components are supported")
        replace_node = class_node.parent
    state = _literal_state(source, constructor) if constructor else {}
    render_text = source[render.start_byte:render.end_byte]
    body_match = re.search(r"\breturn\s+([\s\S]*?);?\s*}\s*$", render_text)
    if not body_match:
        raise StructuralValidationError("render() must return one JSX expression")
    jsx = body_match.group(1).strip()
    if jsx.startswith("(") and jsx.endswith(")"):
        jsx = jsx[1:-1].strip()
    if not jsx.startswith("<"):
        raise StructuralValidationError("render() return must be a JSX expression")
    if "this.setState" in render_text:
        raise StructuralValidationError("Complex instance behavior requires manual migration")

    hook_names = []
    for key, value in state.items():
        if not re.fullmatch(r"[A-Za-z_$][\w$]*", key):
            raise StructuralValidationError(f"Unsupported state key: {key}")
        hook_names.append(f"  const [{key}, set{key[0].upper()}{key[1:]}] = useState({value});")
        jsx = re.sub(rf"\bthis\.state\.{re.escape(key)}\b", key, jsx)
    jsx = jsx.replace("this.props", "props")
    if "this." in jsx:
        raise StructuralValidationError("Complex instance behavior requires manual migration")

    imports = source[:replace_node.start_byte]
    imports = re.sub(
        r"import\s+React\s+from\s+(['\"])react\1;?\s*",
        "import React, { useState } from 'react';\n",
        imports,
        count=1,
    )
    if "useState" not in imports:
        imports = "import { useState } from 'react';\n" + imports
    replacement = (
        f"function {name}(props) {{\n"
        + ("\n".join(hook_names) + "\n" if hook_names else "")
        + f"  return (\n    {jsx}\n  );\n}}\n\nexport default {name};\n"
    )
    suffix = source[replace_node.end_byte:]
    result = imports.rstrip() + "\n\n" + replacement + suffix
    if not re.search(rf"\b{re.escape(name)}\b", result):
        raise StructuralValidationError("Generated component lost its declaration")
    return result


def _literal_state(source: str, constructor) -> dict[str, str]:
    if constructor is None:
        return {}
    text = source[constructor.start_byte:constructor.end_byte]
    match = re.search(r"this\.state\s*=\s*\{([\s\S]*?)\}\s*;?", text)
    if not match:
        return {}
    fields = {}
    for field in re.finditer(
        r"([A-Za-z_$][\w$]*)\s*:\s*(\"(?:[^\"\\]|\\.)*\"|'(?:[^'\\]|\\.)*'|"
        r"-?\d+(?:\.\d+)?|true|false|null)\s*,?",
        match.group(1),
    ):
        fields[field.group(1)] = field.group(2)
    if not fields:
        raise StructuralValidationError("State must contain supported literal values")
    return fields


def _first_named(node, node_type, text_source=None, predicate=None):
    stack = [node]
    while stack:
        current = stack.pop()
        if current.type == node_type:
            text = (
                text_source[current.start_byte:current.end_byte]
                if text_source is not None else ""
            )
            if predicate is None or predicate(text):
                return current
        stack.extend(reversed(current.named_children))
    return None


def migrate_task(task: MigrationTask) -> ProposedChange:
    if task.target == "python3":
        after = migrate_python(task.source)
    elif task.target == "react-hooks":
        after = migrate_react_class(task.source)
    else:
        raise ValueError(f"Unsupported target: {task.target}")
    return ProposedChange(task.path, task.source, after)


def verify_change(change: ProposedChange, target: str) -> None:
    if target == "python3":
        before = python_structure(migrate_python(change.before))
        after = python_structure(change.after)
        if after.syntax_errors:
            raise StructuralValidationError("Migrated Python has syntax errors")
        if _contains_python2_syntax(change.after):
            raise StructuralValidationError("Python 2 syntax remains after migration")
        if after.classes != before.classes:
            raise StructuralValidationError("Python class count changed unexpectedly")
    else:
        before = javascript_structure(change.before)
        after = javascript_structure(change.after)
        if after.classes >= before.classes:
            raise StructuralValidationError("React class count did not decrease")
        if after.functions <= before.functions:
            raise StructuralValidationError("Function component was not created")
        expected_hooks = _state_field_count(change.before)
        if after.hooks != expected_hooks:
            raise StructuralValidationError(
                f"Expected {expected_hooks} useState hook(s), found {after.hooks}"
            )


def _contains_python2_syntax(source: str) -> bool:
    return bool(re.search(r"\b(?:xrange|raw_input)\s*\(", source)) or any(
        re.match(r"^\s*print\s+[^(\s]", line)
        for line in source.splitlines()
    )


def _state_field_count(source: str) -> int:
    tree = parse_javascript(source)
    class_node = _first_named(tree.root_node, "class_declaration")
    if class_node is None:
        return 0
    class_body = next(
        (child for child in class_node.named_children if child.type == "class_body"),
        None,
    )
    if class_body is None:
        return 0
    constructor = next(
        (
            method for method in class_body.named_children
            if method.type == "method_definition"
            and source[method.start_byte:method.end_byte].lstrip().startswith("constructor(")
        ),
        None,
    )
    return len(_literal_state(source, constructor)) if constructor else 0
