from dataclasses import dataclass, field
from pathlib import Path


@dataclass(frozen=True)
class MigrationTask:
    path: Path
    source: str
    target: str
    context: str = ""


@dataclass
class MigrationPlan:
    target: str
    tasks: list[MigrationTask] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class ProposedChange:
    path: Path
    before: str
    after: str


@dataclass
class AttemptResult:
    accepted: bool
    changes: list[ProposedChange]
    messages: list[str]
    attempts: int
