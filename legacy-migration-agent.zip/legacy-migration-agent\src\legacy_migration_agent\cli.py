import argparse
import os
import sys
from pathlib import Path

from .workflow import MigrationWorkflow


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="legacy-migrate",
        description="Plan, migrate, AST-verify, and test a legacy repository.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)
    migrate = subparsers.add_parser("migrate", help="migrate a repository")
    migrate.add_argument("path", type=Path)
    migrate.add_argument("--target", choices=("python3", "react-hooks"), required=True)
    migrate.add_argument("--dry-run", action="store_true")
    migrate.add_argument("--use-llm", action="store_true")
    migrate.add_argument(
        "--pgvector-dsn",
        help="opt in to indexing repository context in PostgreSQL/pgvector",
    )
    migrate.add_argument("--max-attempts", type=int, default=2)
    migrate.add_argument(
        "--test-command",
        nargs="+",
        default=[sys.executable, "-m", "pytest", "-q"],
        metavar="ARG",
        help="test command and arguments (default: python -m pytest -q)",
    )
    return parser


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    if args.use_llm and not os.getenv("MIGRATOR_API_KEY"):
        print("--use-llm requires MIGRATOR_API_KEY", file=sys.stderr)
        return 2
    if args.pgvector_dsn and not args.use_llm:
        print("--pgvector-dsn requires --use-llm", file=sys.stderr)
        return 2
    try:
        result = MigrationWorkflow(
            use_llm=args.use_llm,
            max_attempts=args.max_attempts,
            pgvector_dsn=args.pgvector_dsn,
        ).migrate(args.path, args.target, args.test_command, args.dry_run)
    except (OSError, ValueError, RuntimeError) as exc:
        print(f"Migration failed: {exc}", file=sys.stderr)
        return 2

    for message in result.messages:
        print(message)
    for change in result.changes:
        print(f"\n--- {change.path} ---")
        if change.before != change.after:
            print(_unified_diff(change.path, change.before, change.after))
        else:
            print("(no textual change)")
    return 0 if result.accepted else 1


def _unified_diff(path: Path, before: str, after: str) -> str:
    import difflib

    return "".join(
        difflib.unified_diff(
            before.splitlines(keepends=True),
            after.splitlines(keepends=True),
            fromfile=str(path),
            tofile=f"{path} (migrated)",
        )
    ).rstrip()


if __name__ == "__main__":
    raise SystemExit(main())
