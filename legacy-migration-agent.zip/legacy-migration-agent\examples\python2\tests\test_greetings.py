import greetings


def test_greetings_and_range_migration():
    assert greetings.greet("Ada") == "Ada"
    assert greetings.numbers(4) == [0, 1, 2, 3]

