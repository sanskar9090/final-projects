import ast
from dataclasses import dataclass

from tree_sitter import Language, Parser
import tree_sitter_javascript


class StructuralValidationError(ValueError):
    pass


@dataclass(frozen=True)
class Structure:
    classes: int
    functions: int
    hooks: int
    syntax_errors: int


def parse_python(source: str) -> ast.Module:
    try:
        return ast.parse(source)
    except SyntaxError as exc:
        raise StructuralValidationError(f"Python syntax error: {exc}") from exc


def python_structure(source: str) -> Structure:
    tree = parse_python(source)
    classes = sum(isinstance(node, ast.ClassDef) for node in ast.walk(tree))
    functions = sum(
        isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))
        for node in ast.walk(tree)
    )
    return Structure(classes, functions, 0, 0)


def parse_javascript(source: str):
    language = Language(tree_sitter_javascript.language())
    parser = Parser(language)
    tree = parser.parse(source.encode("utf-8"))
    if tree.root_node.has_error:
        raise StructuralValidationError("JavaScript/JSX AST contains parse errors")
    return tree


def javascript_structure(source: str) -> Structure:
    tree = parse_javascript(source)
    classes = 0
    functions = 0
    hooks = 0
    stack = [tree.root_node]
    while stack:
        node = stack.pop()
        if node.type in {"class_declaration", "class"}:
            classes += 1
        if node.type in {"function_declaration", "function_expression", "arrow_function"}:
            functions += 1
        if node.type == "call_expression":
            function = node.child_by_field_name("function")
            if function and function.type == "identifier":
                name = source[function.start_byte:function.end_byte]
                if name in {"useState", "useEffect", "useMemo", "useCallback"}:
                    hooks += 1
        stack.extend(reversed(node.named_children))
    return Structure(classes, functions, hooks, 0)

