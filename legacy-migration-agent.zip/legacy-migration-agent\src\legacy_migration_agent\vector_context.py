import hashlib
import json
import os
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

from .planner import IGNORED_DIRS

TEXT_EXTENSIONS = {".py", ".js", ".jsx", ".ts", ".tsx", ".json", ".md", ".toml"}
MAX_FILE_BYTES = 256_000
CHUNK_LINES = 80
OVERLAP_LINES = 10
VECTOR_DIMENSIONS = 1536


def chunk_source(source: str) -> list[str]:
    lines = source.splitlines()
    if not lines:
        return []
    stride = CHUNK_LINES - OVERLAP_LINES
    return [
        "\n".join(lines[start:start + CHUNK_LINES])
        for start in range(0, len(lines), stride)
        if lines[start:start + CHUNK_LINES]
    ]


class PgVectorContext:
    """Opt-in repository context index using PostgreSQL's pgvector extension."""

    def __init__(self, dsn: str):
        api_key = os.getenv("MIGRATOR_API_KEY")
        if not api_key:
            raise RuntimeError("MIGRATOR_API_KEY is required for repository embeddings")
        try:
            import psycopg
            from pgvector.psycopg import register_vector
        except ImportError as exc:
            raise RuntimeError(
                "Install the optional vector dependencies with: "
                "python -m pip install -e '.[vector]'"
            ) from exc
        self._psycopg = psycopg
        self._register_vector = register_vector
        self._dsn = dsn
        self._api_key = api_key
        self._base_url = os.getenv(
            "MIGRATOR_BASE_URL", "https://api.openai.com/v1"
        ).rstrip("/")
        self._embedding_model = os.getenv(
            "MIGRATOR_EMBEDDING_MODEL", "text-embedding-3-small"
        )

    def index_repository(self, root: Path) -> None:
        root = root.resolve()
        repo_id = hashlib.sha256(str(root).encode("utf-8")).hexdigest()
        with self._psycopg.connect(self._dsn) as connection:
            self._register_vector(connection)
            connection.execute("CREATE EXTENSION IF NOT EXISTS vector")
            connection.execute(
                """
                CREATE TABLE IF NOT EXISTS migration_code_chunks (
                    repo_id text NOT NULL,
                    path text NOT NULL,
                    chunk_no integer NOT NULL,
                    content text NOT NULL,
                    embedding vector(1536) NOT NULL,
                    PRIMARY KEY (repo_id, path, chunk_no)
                )
                """
            )
            connection.commit()
            self._ingest(connection, root, repo_id)

    def retrieve_context(self, root: Path, query: str) -> str:
        root = root.resolve()
        repo_id = hashlib.sha256(str(root).encode("utf-8")).hexdigest()
        with self._psycopg.connect(self._dsn) as connection:
            self._register_vector(connection)
            query_vector = self._embed([query])[0]
            rows = connection.execute(
                """
                SELECT path, content
                FROM migration_code_chunks
                WHERE repo_id = %s
                ORDER BY embedding <=> %s
                LIMIT 4
                """,
                (repo_id, query_vector),
            ).fetchall()
        return "\n\n".join(
            f"--- {path} ---\n{content}" for path, content in rows
        )

    def _ingest(self, connection, root: Path, repo_id: str) -> None:
        records = []
        for path in sorted(root.rglob("*")):
            if (
                not path.is_file()
                or path.suffix.lower() not in TEXT_EXTENSIONS
                or any(part in IGNORED_DIRS for part in path.relative_to(root).parts)
                or path.stat().st_size > MAX_FILE_BYTES
            ):
                continue
            try:
                source = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            for chunk_no, content in enumerate(chunk_source(source)):
                records.append((path.relative_to(root).as_posix(), chunk_no, content))

        connection.execute(
            "DELETE FROM migration_code_chunks WHERE repo_id = %s", (repo_id,)
        )
        for offset in range(0, len(records), 16):
            batch = records[offset:offset + 16]
            vectors = self._embed([record[2] for record in batch])
            connection.executemany(
                """
                INSERT INTO migration_code_chunks
                    (repo_id, path, chunk_no, content, embedding)
                VALUES (%s, %s, %s, %s, %s)
                ON CONFLICT (repo_id, path, chunk_no)
                DO UPDATE SET content = EXCLUDED.content, embedding = EXCLUDED.embedding
                """,
                [
                    (repo_id, path, chunk_no, content, vector)
                    for (path, chunk_no, content), vector in zip(batch, vectors)
                ],
            )
        connection.commit()

    def _embed(self, inputs: list[str]) -> list[list[float]]:
        payload = json.dumps({
            "model": self._embedding_model,
            "input": inputs,
        }).encode("utf-8")
        request = Request(
            f"{self._base_url}/embeddings",
            data=payload,
            headers={
                "Authorization": f"Bearer {self._api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urlopen(request, timeout=90) as response:
                data = json.loads(response.read().decode("utf-8"))
        except (HTTPError, URLError, TimeoutError) as exc:
            raise RuntimeError(f"Embedding request failed: {exc}") from exc
        try:
            vectors = [
                entry["embedding"] for entry in sorted(
                    data["data"], key=lambda entry: entry["index"]
                )
            ]
        except (KeyError, TypeError) as exc:
            raise RuntimeError("Embedding response was malformed") from exc
        if len(vectors) != len(inputs) or any(
            len(vector) != VECTOR_DIMENSIONS for vector in vectors
        ):
            raise RuntimeError(
                f"Embedding model must return {VECTOR_DIMENSIONS}-dimension vectors"
            )
        return vectors
