"""Enterprise-oriented legacy migration agent starter."""

__version__ = "0.1.0"

