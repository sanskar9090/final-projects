import shutil
import subprocess
import tempfile
from pathlib import Path

from .models import ProposedChange


class TestingAgent:
    """Test staged output in a disposable copy; never mutates the input tree."""

    def __init__(self, timeout_seconds: int = 120):
        self.timeout_seconds = timeout_seconds

    def evaluate(
        self,
        root: Path,
        changes: list[ProposedChange],
        test_command: list[str],
    ) -> tuple[bool, str]:
        with tempfile.TemporaryDirectory(prefix="legacy-migration-check-") as tmp:
            test_root = Path(tmp) / "repository"
            shutil.copytree(
                root,
                test_root,
                ignore=shutil.ignore_patterns(
                    ".git", ".venv", "node_modules", "__pycache__", ".pytest_cache"
                ),
            )
            for change in changes:
                relative = change.path.resolve().relative_to(root.resolve())
                staged = test_root / relative
                staged.parent.mkdir(parents=True, exist_ok=True)
                staged.write_text(change.after, encoding="utf-8")
            try:
                result = subprocess.run(
                    test_command,
                    cwd=test_root,
                    capture_output=True,
                    text=True,
                    timeout=self.timeout_seconds,
                    check=False,
                    shell=False,
                )
            except subprocess.TimeoutExpired:
                return False, f"Test command exceeded {self.timeout_seconds}s timeout"
            except OSError as exc:
                return False, f"Could not start test command: {exc}"
            output = (result.stdout + "\n" + result.stderr).strip()
            if result.returncode:
                return False, (
                    f"Test command failed (exit {result.returncode}):\n"
                    f"{output[-6000:]}"
                )
            return True, output[-6000:] or "Test command passed with no output"

