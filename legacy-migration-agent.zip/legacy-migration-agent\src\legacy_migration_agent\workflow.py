from pathlib import Path
from typing import TypedDict

from langgraph.graph import END, START, StateGraph
from .agents import DeveloperAgent
from .codemods import verify_change
from .evaluator import TestingAgent
from .models import AttemptResult, MigrationPlan, ProposedChange
from .planner import PlannerAgent


class WorkflowState(TypedDict, total=False):
    root: Path
    target: str
    test_command: list[str]
    dry_run: bool
    pgvector_dsn: str
    plan: MigrationPlan
    changes: list[ProposedChange]
    attempts: int
    feedback: str
    accepted: bool
    messages: list[str]
    stop: bool
    test_output: str


class MigrationWorkflow:
    """Plan -> develop -> AST verify -> test -> apply, with bounded retries."""

    def __init__(
        self,
        use_llm: bool = False,
        max_attempts: int = 2,
        pgvector_dsn: str | None = None,
    ):
        if max_attempts < 1:
            raise ValueError("max_attempts must be at least 1")
        self.planner = PlannerAgent()
        self.developer = DeveloperAgent(use_llm=use_llm)
        self.tester = TestingAgent()
        self.max_attempts = max_attempts
        self.pgvector_dsn = pgvector_dsn
        self.graph = self._build_graph()

    def migrate(
        self,
        root: Path,
        target: str,
        test_command: list[str],
        dry_run: bool = False,
    ) -> AttemptResult:
        state = self.graph.invoke({
            "root": root.resolve(),
            "target": target,
            "test_command": test_command,
            "dry_run": dry_run,
            "pgvector_dsn": self.pgvector_dsn or "",
            "attempts": 0,
            "feedback": "",
            "accepted": False,
            "messages": [],
            "stop": False,
        })
        return AttemptResult(
            accepted=state.get("accepted", False),
            changes=state.get("changes", []),
            messages=state.get("messages", []),
            attempts=state.get("attempts", 0),
        )

    def _build_graph(self):
        graph = StateGraph(WorkflowState)
        graph.add_node("planner", self._plan)
        graph.add_node("developer", self._develop)
        graph.add_node("ast_verifier", self._verify)
        graph.add_node("testing_agent", self._test)
        graph.add_node("apply", self._apply_node)
        graph.add_node("rollback", self._rollback)
        graph.add_node("finish", lambda state: state)
        graph.add_edge(START, "planner")
        graph.add_conditional_edges(
            "planner",
            lambda state: "finish" if state.get("stop") else "developer",
            {"finish": "finish", "developer": "developer"},
        )
        graph.add_edge("developer", "ast_verifier")
        graph.add_conditional_edges(
            "ast_verifier",
            self._after_verification,
            {"retry": "developer", "test": "testing_agent", "rollback": "rollback", "finish": "finish"},
        )
        graph.add_conditional_edges(
            "testing_agent",
            self._after_tests,
            {"retry": "developer", "apply": "apply", "rollback": "rollback"},
        )
        graph.add_edge("apply", "finish")
        graph.add_edge("rollback", "finish")
        graph.add_edge("finish", END)
        return graph.compile()

    def _plan(self, state: WorkflowState) -> WorkflowState:
        plan = self.planner.plan(state["root"], state["target"])
        messages = list(state.get("messages", []))
        if not plan.tasks:
            messages.append("No matching migration files found.")
            return {"plan": plan, "messages": messages, "stop": True}
        if state.get("pgvector_dsn"):
            from dataclasses import replace

            from .vector_context import PgVectorContext

            index = PgVectorContext(state["pgvector_dsn"])
            index.index_repository(state["root"])
            plan.tasks = [
                replace(
                    task,
                    context=index.retrieve_context(
                        state["root"],
                        f"Migration target {task.target}; source file {task.path.name}:\n"
                        f"{task.source[:12000]}",
                    ),
                )
                for task in plan.tasks
            ]
            messages.append("Repository context indexed and retrieved with pgvector.")
        messages.append(f"Planner found {len(plan.tasks)} candidate file(s).")
        return {"plan": plan, "messages": messages}

    def _develop(self, state: WorkflowState) -> WorkflowState:
        attempt = state.get("attempts", 0) + 1
        changes = [
            self.developer.develop(task, state.get("feedback", ""))
            for task in state["plan"].tasks
        ]
        return {"changes": changes, "attempts": attempt, "feedback": ""}

    def _verify(self, state: WorkflowState) -> WorkflowState:
        try:
            for change in state["changes"]:
                verify_change(change, state["target"])
        except ValueError as exc:
            message = f"Attempt {state['attempts']}: AST/structural verification failed: {exc}"
            return {"feedback": message, "messages": state["messages"] + [message]}
        if state.get("dry_run"):
            message = "Dry run: AST checks passed; no files were written."
            return {
                "accepted": True,
                "messages": state["messages"] + [message],
                "stop": True,
            }
        return {"feedback": "", "stop": False}

    def _after_verification(self, state: WorkflowState) -> str:
        if state.get("accepted") or state.get("dry_run") and state.get("stop"):
            return "finish"
        if state.get("feedback"):
            return self._retry_or_rollback(state)
        return "test"

    def _test(self, state: WorkflowState) -> WorkflowState:
        passed, output = self.tester.evaluate(
            state["root"], state["changes"], state["test_command"]
        )
        if passed:
            return {"feedback": "", "test_output": output}
        message = f"Attempt {state['attempts']}: tests failed; staged changes discarded."
        return {
            "feedback": output,
            "messages": state["messages"] + [message],
        }

    def _after_tests(self, state: WorkflowState) -> str:
        return "apply" if not state.get("feedback") else self._retry_or_rollback(state)

    def _retry_or_rollback(self, state: WorkflowState) -> str:
        if self.developer.use_llm and state["attempts"] < self.max_attempts:
            return "retry"
        return "rollback"

    def _apply_node(self, state: WorkflowState) -> WorkflowState:
        self._apply(state["root"], state["changes"])
        messages = state["messages"] + [
            f"Attempt {state['attempts']}: tests passed. Changes applied.",
            state.get("test_output", "Test command passed."),
        ]
        return {"accepted": True, "messages": messages}

    @staticmethod
    def _rollback(state: WorkflowState) -> WorkflowState:
        messages = state["messages"] + [
            "Rollback complete: original repository files remain unchanged."
        ]
        return {"accepted": False, "messages": messages}

    @staticmethod
    def _apply(root: Path, changes: list[ProposedChange]) -> None:
        # All candidates have passed AST checks and tests before this commit phase.
        for change in changes:
            relative = change.path.resolve().relative_to(root.resolve())
            destination = root / relative
            if destination.read_text(encoding="utf-8") != change.before:
                raise RuntimeError(
                    f"Source changed during migration; refusing to overwrite: {destination}"
                )
        for change in changes:
            relative = change.path.resolve().relative_to(root.resolve())
            (root / relative).write_text(change.after, encoding="utf-8")
