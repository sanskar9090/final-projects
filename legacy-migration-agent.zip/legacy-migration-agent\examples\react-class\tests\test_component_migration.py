from pathlib import Path


def test_app_is_migrated_to_hooks():
    source = (Path(__file__).parents[1] / "src" / "App.jsx").read_text(encoding="utf-8")
    assert "function App(props)" in source
    assert "useState(0)" in source
    assert "useState(\"Clicks\")" in source
    assert "extends React.Component" not in source

