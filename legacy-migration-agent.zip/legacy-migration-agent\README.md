# Legacy Migration Agent

An offline-first, multi-agent code migration starter that plans a repository
migration, applies a conservative codemod or an optional LLM proposal, checks
structural invariants, and runs tests before applying changes to the working
tree.

The included examples cover Python 2 `print`/`xrange`/`raw_input` migrations
and a deliberately small React class-component-to-Hooks subset. Unsupported
patterns fail closed rather than being silently rewritten.

## Agents and safety loop

1. **Planner** inventories supported source files and selects a migration task.
2. **Developer** applies a deterministic codemod, or asks an optional
   OpenAI-compatible endpoint to propose a change.
3. **AST verifier** parses Python with `ast` and JavaScript/JSX with
   tree-sitter, and checks migration-specific structural invariants before
   writing anything.
4. **Testing agent** compiles Python and runs the configured test command in a
   temporary repository copy. A failed attempt is discarded; the loop retries
   and ultimately leaves the original tree unchanged if verification/tests do
   not pass.

The test runner executes code from the target repository. Use this tool only
with code you trust; a temporary directory is not a security sandbox.

## Quick start

Requires Python 3.10+. From this directory:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -e ".[dev]"
python -m legacy_migration_agent.cli migrate .\examples\python2 --target python3
```

React example:

```powershell
python -m legacy_migration_agent.cli migrate .\examples\react-class --target react-hooks
```

Preview without changing files:

```powershell
python -m legacy_migration_agent.cli migrate .\examples\python2 --target python3 --dry-run
```

## LLM option

The default provider is deterministic and works without credentials. To let the
developer agent propose edits through an OpenAI-compatible chat-completions
endpoint, set `MIGRATOR_API_KEY` and optionally `MIGRATOR_BASE_URL` and
`MIGRATOR_MODEL`. LLM output is never trusted on its own: AST checks and tests
must pass before changes are applied.

For optional repository-wide retrieval context, install the vector extra:

```powershell
python -m pip install -e ".[vector]"
```

Provide PostgreSQL with the pgvector extension, and pass
`--use-llm --pgvector-dsn "postgresql://..."`. The agent chunks supported
source/documentation files, creates embeddings through the configured
OpenAI-compatible endpoint, stores them in `migration_code_chunks`, and adds
the nearest snippets to the developer prompt. Source is sent to the configured
embedding/chat endpoint only when these options are explicitly enabled.
Pinecone can be implemented behind the same retrieval boundary.

## CLI

```text
python -m legacy_migration_agent.cli migrate PATH --target {python3,react-hooks}
    [--dry-run] [--max-attempts N] [--test-command ARG ...]
    [--use-llm] [--pgvector-dsn DSN]
```

The default test command is `python -m pytest -q`. A supplied test command is
an argument vector (no shell expansion). The agent copies the repository to a
temporary directory, runs the test command there, and only then applies the
verified patch to the original source files.

## Video walkthroughs

Three short MP4 walkthroughs are in `videos/`:

1. `01-project-overview.mp4` — project purpose, modules, and agent flow.
2. `02-technology-and-operations.mp4` — Python, AST tooling, optional LLM, and
   migration/testing operations.
3. `03-live-run-demo.mp4` — a Python 2 migration run and its verified output.

Regenerate the videos with:

```powershell
python scripts\generate_videos.py
```

## Limitations

- Python support is a focused modernization subset, not a complete Python 2
  compatibility port.
- React support intentionally handles simple function-free class components
  with literal constructor state and a JSX `render`. Lifecycle methods,
  handlers, refs, complex state updates, decorators, and TypeScript are rejected
  for manual/LLM-assisted migration.
- The optional LLM API must be configured by the operator. No source code is
  sent anywhere when it is unset.
- Multi-file atomicity is approximated by validating all output first and then
  applying the staged files. Keep a version-control backup for production use.

## Development

```powershell
python -m pytest
```
