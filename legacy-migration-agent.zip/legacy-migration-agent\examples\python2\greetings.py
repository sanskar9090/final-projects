def greet(name):
    print "Hello,", name
    return name


def numbers(stop):
    return list(xrange(stop))

