import React from "react";

export default class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      count: 0,
      label: "Clicks",
    };
  }

  render() {
    return (
      <main>
        <h1>{this.state.label}</h1>
        <p>{this.state.count}</p>
      </main>
    );
  }
}

