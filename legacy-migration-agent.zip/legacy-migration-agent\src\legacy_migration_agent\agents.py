from .codemods import migrate_task
from .llm import OpenAICompatibleClient
from .models import MigrationTask, ProposedChange


class DeveloperAgent:
    def __init__(self, use_llm: bool = False):
        self.client = OpenAICompatibleClient()
        self.use_llm = use_llm

    def develop(self, task: MigrationTask, feedback: str = "") -> ProposedChange:
        if self.use_llm:
            after = self.client.propose(
                task.source, task.target, feedback, task.context
            )
        else:
            after = migrate_task(task).after
        return ProposedChange(task.path, task.source, after)
