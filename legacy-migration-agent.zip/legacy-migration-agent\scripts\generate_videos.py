from pathlib import Path

import cv2
import numpy as np
from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / "videos"
WIDTH, HEIGHT, FPS = 1280, 720, 24

WALKTHROUGHS = {
    "01-project-overview.mp4": [
        ("LEGACY MIGRATION AGENT", "Enterprise-scale code modernization"),
        ("THE PROBLEM", "Move beyond one-file chatbots: understand and migrate a repository."),
        ("THREE SPECIALISTS", "Planner inventories  |  Developer migrates  |  Tester validates"),
        ("SAFE CHANGE LOOP", "AST proof + tests pass before edits are applied to the source tree."),
    ],
    "02-technology-and-operations.mp4": [
        ("TECHNOLOGY STACK", "Python + LangGraph  |  Python AST  |  tree-sitter JavaScript/JSX"),
        ("OPTIONAL RETRIEVAL", "PostgreSQL pgvector + embeddings; opt in with a DSN and API key."),
        ("MIGRATION TARGETS", "Python 2 print/xrange  ->  Python 3\nReact class  ->  Hooks"),
        ("QUALITY GATES", "Parse structure  ->  stage in temp copy  ->  run tests  ->  apply or rollback"),
    ],
    "03-live-run-demo.mp4": [
        ("LIVE RUN: PYTHON 2", "> legacy-migrate examples/python2 --target python3"),
        ("AGENT OUTPUT", "Planner found 2 candidate file(s).\nAttempt 1: tests passed. Changes applied.\n1 passed in 0.05s"),
        ("VERIFIED DIFF", "- print \"Hello,\", name\n+ print(\"Hello,\", name)\n- xrange(stop)\n+ range(stop)"),
        ("RESULT", "AST checks passed; tests ran in a temp copy; updated source is applied."),
    ],
}


def load_font(size: int):
    candidates = [
        Path("C:/Windows/Fonts/consola.ttf"),
        Path("C:/Windows/Fonts/arial.ttf"),
        Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size)
    return ImageFont.load_default()


def render_slide(title: str, subtitle: str, progress: float) -> np.ndarray:
    image = Image.new("RGB", (WIDTH, HEIGHT), "#0b1220")
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((48, 48, WIDTH - 48, HEIGHT - 48), radius=24, fill="#101c2e")
    draw.rectangle((48, 48, WIDTH - 48, 62), fill="#32d7a0")
    draw.text((96, 112), "APPLIED AI  /  CODE MODERNIZATION", font=load_font(23), fill="#8da6c5")
    draw.text((96, 254), title, font=load_font(46), fill="#f0f6ff")
    draw.multiline_text(
        (96, 342), "\n".join(_wrap(subtitle, 54)),
        font=load_font(30), fill="#b5c7dd", spacing=12,
    )
    draw.text((96, 570), "Planner  >  Developer  >  AST verifier  >  Test agent",
              font=load_font(22), fill="#32d7a0")
    draw.rectangle((96, 628, WIDTH - 96, 638), fill="#26374d")
    draw.rectangle((96, 628, 96 + int((WIDTH - 192) * progress), 638), fill="#32d7a0")
    return cv2.cvtColor(np.array(image), cv2.COLOR_RGB2BGR)


def _wrap(text: str, width: int) -> list[str]:
    lines = []
    for paragraph in text.splitlines() or [""]:
        words = paragraph.split()
        current = ""
        for word in words:
            candidate = f"{current} {word}".strip()
            if len(candidate) > width and current:
                lines.append(current)
                current = word
            else:
                current = candidate
        lines.append(current)
    return lines


def create_video(path: Path, slides: list[tuple[str, str]]) -> None:
    writer = cv2.VideoWriter(
        str(path), cv2.VideoWriter_fourcc(*"mp4v"), FPS, (WIDTH, HEIGHT)
    )
    if not writer.isOpened():
        raise RuntimeError(f"Could not initialize MP4 encoder for {path}")
    frames_per_slide = FPS * 3
    try:
        for index, (title, subtitle) in enumerate(slides):
            frame = render_slide(title, subtitle, (index + 1) / len(slides))
            for _ in range(frames_per_slide):
                writer.write(frame)
    finally:
        writer.release()


def main() -> None:
    OUTPUT.mkdir(exist_ok=True)
    for filename, slides in WALKTHROUGHS.items():
        destination = OUTPUT / filename
        create_video(destination, slides)
        print(f"Created {destination.name} ({destination.stat().st_size:,} bytes)")


if __name__ == "__main__":
    main()
