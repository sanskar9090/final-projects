from pathlib import Path

from legacy_migration_agent.workflow import MigrationWorkflow


def test_dry_run_does_not_write_source(tmp_path):
    source = tmp_path / "legacy.py"
    original = 'print "hello"\n'
    source.write_text(original, encoding="utf-8")
    result = MigrationWorkflow(max_attempts=1).migrate(
        tmp_path, "python3", ["python", "-c", "raise SystemExit(99)"], dry_run=True
    )
    assert result.accepted
    assert source.read_text(encoding="utf-8") == original


def test_failed_tests_leave_source_unchanged(tmp_path):
    source = tmp_path / "legacy.py"
    original = 'print "hello"\n'
    source.write_text(original, encoding="utf-8")
    result = MigrationWorkflow(max_attempts=1).migrate(
        tmp_path,
        "python3",
        ["python", "-c", "raise SystemExit(7)"],
    )
    assert not result.accepted
    assert source.read_text(encoding="utf-8") == original
    assert any("Rollback complete" in message for message in result.messages)

