from pathlib import Path

from .models import MigrationPlan, MigrationTask

PYTHON_EXTENSIONS = {".py"}
JS_EXTENSIONS = {".js", ".jsx"}
IGNORED_DIRS = {".git", ".venv", "node_modules", "__pycache__", "dist", "build"}


class PlannerAgent:
    """Build a bounded migration inventory without modifying the repository."""

    def plan(self, root: Path, target: str) -> MigrationPlan:
        if not root.is_dir():
            raise NotADirectoryError(f"Repository path is not a directory: {root}")
        if target not in {"python3", "react-hooks"}:
            raise ValueError(f"Unsupported migration target: {target}")

        extensions = PYTHON_EXTENSIONS if target == "python3" else JS_EXTENSIONS
        tasks: list[MigrationTask] = []
        for path in sorted(root.rglob("*")):
            if any(part in IGNORED_DIRS for part in path.parts):
                continue
            if path.is_file() and path.suffix.lower() in extensions:
                source = path.read_text(encoding="utf-8")
                if target == "python3" or _looks_like_react_class(source):
                    tasks.append(MigrationTask(path, source, target))
        return MigrationPlan(target=target, tasks=tasks)


def _looks_like_react_class(source: str) -> bool:
    return "extends React.Component" in source or "extends Component" in source

