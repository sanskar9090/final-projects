from __future__ import annotations

from pathlib import Path

import cv2
import imageio_ffmpeg
import numpy as np


WIDTH, HEIGHT, FPS, SECONDS = 1280, 720, 12, 20
BG = (24, 28, 38)
WHITE = (240, 244, 250)
TEAL = (90, 220, 200)
AMBER = (70, 170, 255)


def centered_text(frame, text, y, scale, color=WHITE, thickness=2):
    size, _ = cv2.getTextSize(text, cv2.FONT_HERSHEY_DUPLEX, scale, thickness)
    x = (WIDTH - size[0]) // 2
    cv2.putText(frame, text, (x, y), cv2.FONT_HERSHEY_DUPLEX, scale, color, thickness, cv2.LINE_AA)


def draw_card(frame, x, y, width, height, title, detail):
    cv2.rectangle(frame, (x, y), (x + width, y + height), (45, 54, 70), -1, cv2.LINE_AA)
    cv2.rectangle(frame, (x, y), (x + width, y + height), TEAL, 2, cv2.LINE_AA)
    cv2.putText(frame, title, (x + 24, y + 52), cv2.FONT_HERSHEY_DUPLEX, 0.8, TEAL, 2, cv2.LINE_AA)
    cv2.putText(frame, detail, (x + 24, y + 96), cv2.FONT_HERSHEY_SIMPLEX, 0.58, WHITE, 1, cv2.LINE_AA)


def synthetic_xray(frame, phase):
    """Draw a conspicuously synthetic schematic; no clinical images are used."""
    cx, cy = WIDTH // 2, HEIGHT // 2 + 25
    cv2.ellipse(frame, (cx, cy), (180, 230), 0, 0, 360, (76, 83, 96), 2, cv2.LINE_AA)
    for side in (-1, 1):
        cv2.ellipse(frame, (cx + side * 73, cy), (63, 142), 0, 0, 360, (109, 119, 134), 2, cv2.LINE_AA)
        for rib in range(5):
            y = cy - 88 + rib * 37
            cv2.ellipse(frame, (cx + side * 68, y), (94, 28), 0, 195, 345, (73, 84, 101), 1, cv2.LINE_AA)
    cv2.line(frame, (cx, cy - 168), (cx, cy + 146), (125, 139, 155), 3, cv2.LINE_AA)

    # Abstract warm glow illustrates where a heatmap may be drawn; it is fabricated.
    overlay = frame.copy()
    center = (cx + 47, cy + 62)
    radius = 22 + int(phase * 24)
    cv2.circle(overlay, center, radius, (45, 30, 210), -1, cv2.LINE_AA)
    cv2.circle(overlay, center, max(8, radius // 2), (20, 120, 255), -1, cv2.LINE_AA)
    cv2.addWeighted(overlay, 0.28, frame, 0.72, 0, frame)
    centered_text(frame, "SYNTHETIC ILLUSTRATION - NOT A MEDICAL IMAGE", 680, 0.55, AMBER, 1)


def main():
    output = Path(__file__).resolve().parents[1] / "assets" / "demo_walkthrough.mp4"
    output.parent.mkdir(parents=True, exist_ok=True)
    writer = imageio_ffmpeg.write_frames(
        str(output),
        (WIDTH, HEIGHT),
        fps=FPS,
        codec="libx264",
        pix_fmt_in="rgb24",
        pix_fmt_out="yuv420p",
        output_params=["-movflags", "+faststart", "-crf", "23", "-preset", "medium"],
    )
    writer.send(None)
    total_frames = FPS * SECONDS
    try:
        for frame_number in range(total_frames):
            time_s = frame_number / FPS
            frame = np.full((HEIGHT, WIDTH, 3), BG, dtype=np.uint8)
            centered_text(frame, "MEDICAL IMAGING XAI ASSISTANT", 84, 1.0, TEAL, 2)
            centered_text(frame, "Research starter | PyTorch + FastAPI + Streamlit", 126, 0.66)

            if time_s < 4:
                draw_card(frame, 180, 220, 920, 240, "1. TRAIN", "Custom CNN learns from your licensed, labeled dataset")
                centered_text(frame, "Separate chest X-ray and skin image workflows", 545, 0.62)
            elif time_s < 8:
                draw_card(frame, 180, 220, 920, 240, "2. UPLOAD", "Streamlit sends an image to the local FastAPI service")
                centered_text(frame, "Inference is disabled until you add trained weights", 545, 0.62, AMBER)
            elif time_s < 14:
                synthetic_xray(frame, (time_s - 8) / 6)
                centered_text(frame, "3. EXPLAIN", 190, 0.8, TEAL)
            elif time_s < 18:
                draw_card(frame, 130, 225, 490, 240, "4. EVALUATE", "Sensitivity | Specificity | Macro-F1")
                draw_card(frame, 660, 225, 490, 240, "CALIBRATION", "Expected calibration error (ECE)")
                centered_text(frame, "Validation metrics depend on dataset quality and representativeness", 555, 0.52)
            else:
                centered_text(frame, "NOT FOR CLINICAL USE", 300, 1.2, AMBER, 3)
                centered_text(frame, "No trained weights or patient data are included.", 366, 0.68)
                centered_text(frame, "Synthetic visuals only - predictions require independent validation.", 412, 0.58)
            writer.send(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB).tobytes())
    finally:
        writer.close()
    print(f"Created {SECONDS}-second synthetic walkthrough: {output}")


if __name__ == "__main__":
    main()
