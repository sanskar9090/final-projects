import unittest

import numpy as np

from medical_xai.metrics import classification_metrics


class ClassificationMetricsTests(unittest.TestCase):
    def test_perfect_binary_predictions(self):
        metrics = classification_metrics(
            [0, 1, 0, 1],
            np.asarray([[0.9, 0.1], [0.1, 0.9], [0.8, 0.2], [0.2, 0.8]]),
            positive_index=1,
        )
        self.assertEqual(metrics["accuracy"], 1.0)
        self.assertEqual(metrics["macro_f1"], 1.0)
        self.assertEqual(metrics["sensitivity_positive_class"], 1.0)
        self.assertEqual(metrics["specificity_positive_class"], 1.0)
        self.assertAlmostEqual(metrics["expected_calibration_error_15_bins"], 0.15)

    def test_multiclass_macro_metrics(self):
        metrics = classification_metrics(
            [0, 1, 2],
            np.asarray([[0.7, 0.2, 0.1], [0.1, 0.8, 0.1], [0.2, 0.1, 0.7]]),
            positive_index=1,
        )
        self.assertEqual(metrics["accuracy"], 1.0)
        self.assertEqual(metrics["macro_sensitivity_ovr"], 1.0)
        self.assertEqual(metrics["macro_specificity_ovr"], 1.0)


if __name__ == "__main__":
    unittest.main()
