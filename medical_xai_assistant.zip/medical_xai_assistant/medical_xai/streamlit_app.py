from __future__ import annotations

import base64
import json
import os
from pathlib import Path

import requests
import streamlit as st
from PIL import Image

st.set_page_config(page_title="Medical XAI Assistant", page_icon="🩺", layout="wide")
st.title("Medical Imaging XAI Assistant")
st.warning(
    "Research/education demo only — not for diagnosis or treatment decisions. "
    "The project ships without trained medical weights."
)
api_url = os.getenv("MEDICAL_XAI_API_URL", "http://127.0.0.1:8000").rstrip("/")
left, right = st.columns([1, 1])

with left:
    modality = st.selectbox("Image workflow", ["chest", "skin"])
    uploaded = st.file_uploader("Upload an image", type=["png", "jpg", "jpeg", "webp"])
    if uploaded:
        image = Image.open(uploaded).convert("RGB")
        st.image(image, caption="Uploaded image", use_container_width=True)
        if st.button("Analyze image", type="primary"):
            try:
                response = requests.post(
                    f"{api_url}/predict",
                    data={"modality": modality},
                    files={"file": (uploaded.name, uploaded.getvalue(), uploaded.type)},
                    timeout=90,
                )
                if response.status_code == 503:
                    st.error(response.json().get("detail", "Model weights are not available."))
                else:
                    response.raise_for_status()
                    st.session_state["result"] = response.json()
            except requests.RequestException as exc:
                st.error(f"Could not reach the inference API at {api_url}: {exc}")

with right:
    result = st.session_state.get("result")
    if result and result["modality"] == modality:
        st.subheader("Model output (not a diagnosis)")
        st.metric("Predicted class", result["prediction"], f"{result['confidence']:.1%} confidence")
        st.image(
            base64.b64decode(result["gradcam_base64"]),
            caption="Grad-CAM overlay — model attention visualization",
            use_container_width=True,
        )
        st.json(result["probabilities"])
        st.caption(result["warning"])
    else:
        st.info("Train a model and start the FastAPI service to enable inference.")

st.divider()
st.subheader("Validation metrics")
metrics_path = Path("models") / f"{modality}_metrics.json"
if metrics_path.is_file():
    st.json(json.loads(metrics_path.read_text(encoding="utf-8")))
else:
    st.caption("No training metrics yet. Metrics appear after training a model.")

video_path = Path("assets/demo_walkthrough.mp4")
if video_path.is_file():
    st.divider()
    st.subheader("Synthetic project walkthrough")
    st.caption("Illustrative generated animation only; it uses no patient or medical images.")
    st.video(str(video_path))
    st.download_button(
        "Download walkthrough video",
        data=video_path.read_bytes(),
        file_name="medical_xai_synthetic_walkthrough.mp4",
        mime="video/mp4",
    )
