from __future__ import annotations

import cv2
import numpy as np
import torch
from PIL import Image


def preprocess(image: Image.Image, image_size: int) -> torch.Tensor:
    image = image.convert("RGB").resize((image_size, image_size), Image.Resampling.BILINEAR)
    array = np.asarray(image, dtype=np.float32) / 255.0
    tensor = torch.from_numpy(array.transpose(2, 0, 1))
    mean = torch.tensor([0.485, 0.456, 0.406]).view(3, 1, 1)
    std = torch.tensor([0.229, 0.224, 0.225]).view(3, 1, 1)
    return ((tensor - mean) / std).unsqueeze(0)


def predict_with_gradcam(
    model: torch.nn.Module,
    image_tensor: torch.Tensor,
    original_image: Image.Image,
    class_names: list[str],
    device: torch.device,
) -> dict:
    activation: torch.Tensor | None = None
    gradient: torch.Tensor | None = None
    target_layer = model.features[-1]

    def capture_activation(_module, _inputs, output):
        nonlocal activation
        activation = output
        output.register_hook(capture_gradient)

    def capture_gradient(grad):
        nonlocal gradient
        gradient = grad

    handle = target_layer.register_forward_hook(capture_activation)
    try:
        model.zero_grad(set_to_none=True)
        logits = model(image_tensor.to(device))
        probabilities = torch.softmax(logits, dim=1)[0]
        class_index = int(probabilities.argmax().item())
        logits[0, class_index].backward()
    finally:
        handle.remove()

    if activation is None or gradient is None:
        raise RuntimeError("Grad-CAM could not capture model activations and gradients.")

    weights = gradient.mean(dim=(2, 3), keepdim=True)
    cam = torch.relu((weights * activation).sum(dim=1, keepdim=True))
    cam = torch.nn.functional.interpolate(
        cam, size=(original_image.height, original_image.width),
        mode="bilinear", align_corners=False,
    )[0, 0]
    cam = cam.detach().cpu().numpy()
    maximum = float(cam.max())
    if maximum > 0:
        cam /= maximum

    rgb = np.asarray(original_image.convert("RGB"))
    heatmap = cv2.applyColorMap(np.uint8(np.clip(cam, 0, 1) * 255), cv2.COLORMAP_JET)
    heatmap = cv2.cvtColor(heatmap, cv2.COLOR_BGR2RGB)
    overlay = cv2.addWeighted(rgb, 0.58, heatmap, 0.42, 0)

    return {
        "prediction": class_names[class_index],
        "confidence": float(probabilities[class_index].item()),
        "probabilities": {
            name: float(probabilities[index].item())
            for index, name in enumerate(class_names)
        },
        "heatmap": overlay,
    }
