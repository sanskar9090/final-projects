from __future__ import annotations

import base64
import io
import os
from functools import lru_cache
from pathlib import Path

import cv2
import numpy as np
import torch
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from PIL import Image, UnidentifiedImageError

from medical_xai.explain import predict_with_gradcam, preprocess
from medical_xai.model import load_model

app = FastAPI(
    title="Medical Imaging XAI Assistant",
    description="Research/education inference API. Not for clinical use.",
    version="1.0.0",
)
MODEL_DIR = Path(os.getenv("MEDICAL_XAI_MODEL_DIR", "models"))
MAX_UPLOAD_BYTES = 10 * 1024 * 1024
DEVICE = torch.device("cuda" if torch.cuda.is_available() else "cpu")


@lru_cache(maxsize=2)
def get_model(modality: str):
    checkpoint_path = MODEL_DIR / f"{modality}.pt"
    if not checkpoint_path.is_file():
        raise FileNotFoundError(
            f"Trained weights are missing: {checkpoint_path}. Train the {modality} model first."
        )
    return load_model(str(checkpoint_path), DEVICE)


@app.get("/health")
def health():
    return {
        "status": "ok",
        "device": str(DEVICE),
        "available_models": {
            name: (MODEL_DIR / f"{name}.pt").is_file()
            for name in ("chest", "skin")
        },
        "clinical_use": False,
    }


@app.post("/predict")
async def predict(modality: str = Form(...), file: UploadFile = File(...)):
    if modality not in {"chest", "skin"}:
        raise HTTPException(status_code=400, detail="modality must be 'chest' or 'skin'.")
    contents = await file.read(MAX_UPLOAD_BYTES + 1)
    if len(contents) > MAX_UPLOAD_BYTES:
        raise HTTPException(status_code=413, detail="Image exceeds the 10 MB upload limit.")
    try:
        image = Image.open(io.BytesIO(contents))
    except (UnidentifiedImageError, OSError) as exc:
        raise HTTPException(status_code=400, detail="Upload must be a valid image.") from exc
    if image.width < 32 or image.height < 32:
        raise HTTPException(status_code=400, detail="Image dimensions must be at least 32x32.")
    if image.width > 4096 or image.height > 4096:
        raise HTTPException(status_code=413, detail="Image dimensions must not exceed 4096x4096.")
    image = image.convert("RGB")

    try:
        model, checkpoint = get_model(modality)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc
    image_size = int(checkpoint.get("image_size", 224))
    result = predict_with_gradcam(
        model, preprocess(image, image_size), image,
        checkpoint["class_names"], DEVICE,
    )
    ok, encoded = cv2.imencode(
        ".png", cv2.cvtColor(result.pop("heatmap"), cv2.COLOR_RGB2BGR)
    )
    if not ok:
        raise HTTPException(status_code=500, detail="Could not encode the Grad-CAM image.")
    result["gradcam_base64"] = base64.b64encode(encoded.tobytes()).decode("ascii")
    result["modality"] = modality
    result["model_version"] = f"epoch-{checkpoint.get('epoch', 'unknown')}"
    result["warning"] = (
        "Research output only; not a diagnosis. Grad-CAM is not proof of causality "
        "or clinical localization."
    )
    return result
