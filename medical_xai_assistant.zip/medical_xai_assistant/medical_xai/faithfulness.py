from __future__ import annotations

import torch
import torch.nn.functional as F

from medical_xai.explain import preprocess, predict_with_gradcam
from PIL import Image


def salient_region_confidence_drop(model, image: Image.Image, class_names, device, image_size=224):
    """Return predicted-class confidence drop after masking the top 20% CAM area."""
    tensor = preprocess(image, image_size).to(device)
    result = predict_with_gradcam(model, tensor.cpu(), image, class_names, device)
    baseline = result["confidence"]
    class_index = class_names.index(result["prediction"])
    normalized_cam = _gradcam_mask(model, tensor, class_index)
    flat = normalized_cam.flatten()
    selected_count = max(1, flat.numel() // 5)
    selected = torch.topk(flat, selected_count, sorted=False).indices
    mask = torch.zeros_like(flat, dtype=torch.bool)
    mask[selected] = True
    mask = mask.view_as(normalized_cam)
    masked = tensor.clone()
    for channel in range(3):
        channel_mean = tensor[:, channel].mean()
        masked[0, channel][mask] = channel_mean
    with torch.no_grad():
        logits = model(masked)
        index = class_names.index(result["prediction"])
        masked_confidence = float(F.softmax(logits, dim=1)[0, index].item())
    return {
        "baseline_confidence": baseline,
        "masked_confidence": masked_confidence,
        "salient_region_confidence_drop": baseline - masked_confidence,
        "masked_area_fraction": float(mask.float().mean().item()),
    }


def _gradcam_mask(model, tensor, class_index):
    activation = None
    gradient = None

    def save_gradient(value):
        nonlocal gradient
        gradient = value

    def capture(_module, _inputs, output):
        nonlocal activation
        activation = output
        output.register_hook(save_gradient)

    handle = model.features[-1].register_forward_hook(capture)
    try:
        model.zero_grad(set_to_none=True)
        logits = model(tensor)
        logits[0, class_index].backward()
    finally:
        handle.remove()
    if activation is None or gradient is None:
        raise RuntimeError("Unable to compute Grad-CAM for faithfulness measurement.")
    weights = gradient.mean(dim=(2, 3), keepdim=True)
    cam = torch.relu((weights * activation).sum(dim=1, keepdim=True))
    cam = F.interpolate(cam, size=tensor.shape[-2:], mode="bilinear", align_corners=False)[0, 0]
    maximum = cam.max()
    return cam / maximum if maximum > 0 else cam
