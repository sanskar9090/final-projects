"""Research starter for explainable medical-image classification."""
