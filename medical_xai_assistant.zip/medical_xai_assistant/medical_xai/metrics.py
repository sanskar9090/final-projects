from __future__ import annotations

import numpy as np


def classification_metrics(y_true: list[int], probabilities: np.ndarray, positive_index: int) -> dict:
    y_true_array = np.asarray(y_true, dtype=np.int64)
    predicted = probabilities.argmax(axis=1)
    class_count = probabilities.shape[1]
    per_class_f1 = []
    sensitivities = []
    specificities = []

    for class_index in range(class_count):
        tp = int(np.sum((y_true_array == class_index) & (predicted == class_index)))
        fn = int(np.sum((y_true_array == class_index) & (predicted != class_index)))
        fp = int(np.sum((y_true_array != class_index) & (predicted == class_index)))
        tn = int(np.sum((y_true_array != class_index) & (predicted != class_index)))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        per_class_f1.append(
            2 * precision * recall / (precision + recall) if precision + recall else 0.0
        )
        sensitivities.append(recall)
        specificities.append(tn / (tn + fp) if tn + fp else 0.0)

    confidence = probabilities.max(axis=1)
    correct = (predicted == y_true_array).astype(np.float64)
    ece = 0.0
    for bin_index in range(15):
        lower = bin_index / 15
        upper = (bin_index + 1) / 15
        in_bin = (confidence >= lower) & (
            confidence <= upper if bin_index == 14 else confidence < upper
        )
        if in_bin.any():
            ece += float(in_bin.mean() * abs(correct[in_bin].mean() - confidence[in_bin].mean()))

    sensitivity = sensitivities[positive_index]
    specificity = specificities[positive_index]
    return {
        "accuracy": float(np.mean(predicted == y_true_array)),
        "macro_f1": float(np.mean(per_class_f1)),
        "sensitivity_positive_class": float(sensitivity),
        "specificity_positive_class": float(specificity),
        "macro_sensitivity_ovr": float(np.mean(sensitivities)),
        "macro_specificity_ovr": float(np.mean(specificities)),
        "balanced_accuracy_positive_class": float((sensitivity + specificity) / 2),
        "expected_calibration_error_15_bins": float(ece),
        "positive_class_index": int(positive_index),
    }
