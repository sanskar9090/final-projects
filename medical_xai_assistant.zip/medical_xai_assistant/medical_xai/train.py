from __future__ import annotations

import argparse
import json
import random
from pathlib import Path

import numpy as np
import torch
from torch import nn
from torch.utils.data import DataLoader
from torchvision import datasets, transforms

from medical_xai.metrics import classification_metrics
from medical_xai.model import MedicalImageCNN


def evaluate(model, loader, device, positive_index):
    model.eval()
    truth: list[int] = []
    scores: list[np.ndarray] = []
    loss_sum = 0.0
    count = 0
    criterion = nn.CrossEntropyLoss()
    with torch.no_grad():
        for images, labels in loader:
            images, labels = images.to(device), labels.to(device)
            logits = model(images)
            loss_sum += criterion(logits, labels).item() * labels.size(0)
            count += labels.size(0)
            truth.extend(labels.cpu().tolist())
            scores.append(torch.softmax(logits, dim=1).cpu().numpy())
    if not truth:
        raise ValueError("Validation dataset is empty.")
    return loss_sum / count, classification_metrics(truth, np.concatenate(scores), positive_index)


def main():
    parser = argparse.ArgumentParser(description="Train a custom medical-image CNN.")
    parser.add_argument("--modality", choices=("chest", "skin"), required=True)
    parser.add_argument("--data-dir", type=Path, required=True)
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--image-size", type=int, default=224)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output-dir", type=Path, default=Path("models"))
    args = parser.parse_args()
    if args.epochs < 1 or args.batch_size < 1 or args.image_size < 32:
        parser.error("epochs/batch-size must be positive and image-size must be >= 32")

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    normalize = transforms.Normalize(
        mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)
    )
    train_transform = transforms.Compose([
        transforms.Resize((args.image_size, args.image_size)),
        transforms.ToTensor(),
        normalize,
    ])
    val_transform = transforms.Compose([
        transforms.Resize((args.image_size, args.image_size)),
        transforms.ToTensor(),
        normalize,
    ])
    train_data = datasets.ImageFolder(args.data_dir / "train", transform=train_transform)
    val_data = datasets.ImageFolder(args.data_dir / "val", transform=val_transform)
    if not train_data or not val_data:
        raise ValueError("Both train and validation datasets must contain images.")
    if train_data.classes != val_data.classes:
        raise ValueError(
            f"Train/validation class folders differ: {train_data.classes} vs {val_data.classes}"
        )
    if len(train_data.classes) < 2:
        raise ValueError("At least two class folders are required.")
    train_loader = DataLoader(
        train_data, batch_size=args.batch_size, shuffle=True,
        num_workers=0, pin_memory=device.type == "cuda",
    )
    val_loader = DataLoader(
        val_data, batch_size=args.batch_size, shuffle=False,
        num_workers=0, pin_memory=device.type == "cuda",
    )
    model = MedicalImageCNN(len(train_data.classes)).to(device)
    optimizer = torch.optim.AdamW(model.parameters(), lr=args.learning_rate)
    criterion = nn.CrossEntropyLoss()
    positive_index = (
        train_data.class_to_idx.get("PNEUMONIA", 1)
        if args.modality == "chest" else 1
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    checkpoint_path = args.output_dir / f"{args.modality}.pt"
    best_accuracy = -1.0

    for epoch in range(1, args.epochs + 1):
        model.train()
        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad(set_to_none=True)
            loss = criterion(model(images), labels)
            loss.backward()
            optimizer.step()

        val_loss, metrics = evaluate(model, val_loader, device, positive_index)
        print(
            f"epoch={epoch}/{args.epochs} val_loss={val_loss:.4f} "
            f"accuracy={metrics['accuracy']:.4f} macro_f1={metrics['macro_f1']:.4f} "
            f"sensitivity={metrics['sensitivity_positive_class']:.4f} "
            f"specificity={metrics['specificity_positive_class']:.4f} "
            f"ece={metrics['expected_calibration_error_15_bins']:.4f}"
        )
        if metrics["accuracy"] > best_accuracy:
            best_accuracy = metrics["accuracy"]
            torch.save({
                "model_state_dict": model.state_dict(),
                "class_names": train_data.classes,
                "modality": args.modality,
                "image_size": args.image_size,
                "metrics": metrics,
                "epoch": epoch,
                "seed": args.seed,
            }, checkpoint_path)
            (args.output_dir / f"{args.modality}_metrics.json").write_text(
                json.dumps(metrics, indent=2), encoding="utf-8"
            )
    print(f"Best checkpoint saved to {checkpoint_path}")


if __name__ == "__main__":
    main()
