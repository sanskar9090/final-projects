# Medical Imaging XAI Assistant (research starter)

A research/education starter for **two independent image-classification workflows**:
chest X-rays (`NORMAL` / `PNEUMONIA`) and skin lesion images (dataset-defined
classes). It combines a custom PyTorch CNN, FastAPI inference, a Streamlit
interface, OpenCV preprocessing/video generation, and Grad-CAM visualizations.

> **Not for clinical use.** This repository does not include trained medical
> weights, patient data, or a validated diagnostic model. Predictions are only
> available after you train and install your own weights. The bundled demo
> video is generated from synthetic artwork and is not a medical image or a
> performance claim. Use appropriately licensed datasets, follow their terms,
> and obtain clinical, privacy, and regulatory review before any real-world use.

## Included

- Custom CNN with a selectable class list, image size, and reproducible training.
- Separate dataset-driven training for chest and skin workflows.
- FastAPI `/predict` endpoint returning class probabilities and a Grad-CAM overlay.
- Streamlit UI for image upload, model selection, explanations, and metrics.
- Evaluation metrics: accuracy, macro-F1, sensitivity, specificity, balanced
  accuracy, and expected calibration error (ECE).
- Optional Grad-CAM perturbation faithfulness score (confidence drop after
  masking the most salient region).
- Synthetic 20-second walkthrough video and a download button in the UI.

## Setup

Python 3.10+ is recommended. From this directory:

```bash
python -m venv .venv
# Windows PowerShell:
.venv\Scripts\Activate.ps1
# macOS/Linux:
# source .venv/bin/activate
pip install -r requirements.txt
```

## Prepare data and train

Use ImageFolder-style directories. Keep train and validation data separate:

```text
data/
  chest/
    train/
      NORMAL/
      PNEUMONIA/
    val/
      NORMAL/
      PNEUMONIA/
  skin/
    train/
      class_a/
      class_b/
      class_c/
    val/
      class_a/
      class_b/
      class_c/
```

Chest X-ray class names should be exactly `NORMAL` and `PNEUMONIA` if you want
the built-in sensitivity/specificity convention (positive class is PNEUMONIA).
Skin classes are read from the folder names; there is no assumed clinical
meaning or universal skin-lesion label set.

```bash
python -m medical_xai.train --modality chest --data-dir data/chest --epochs 15
python -m medical_xai.train --modality skin --data-dir data/skin --epochs 20
```

The checkpoints are written to `models/chest.pt` and `models/skin.pt`. Training
prints validation metrics each epoch and saves the best validation-accuracy
checkpoint. Do not use the validation set for model selection repeatedly;
maintain a separate held-out test set for final reporting.

## Start the service and UI

Run these in separate terminals:

```bash
uvicorn medical_xai.api:app --host 127.0.0.1 --port 8000
streamlit run medical_xai/streamlit_app.py
```

The UI connects to `http://127.0.0.1:8000` by default. Set
`MEDICAL_XAI_API_URL` to change it. The API refuses inference if weights are
missing; it never silently substitutes random weights.

API docs: <http://127.0.0.1:8000/docs>

Example:

```bash
curl -X POST "http://127.0.0.1:8000/predict" \
  -F "modality=chest" \
  -F "file=@xray.png"
```

Response fields include `prediction`, `probabilities`, `gradcam_base64`,
`warning`, and `model_version`. Grad-CAM is a model explanation, not evidence
that a highlighted region is causal or clinically meaningful. Validate
localization separately using expert-annotated regions where available.

## Metrics and interpretation

The trainer reports classification metrics at the default argmax threshold.
For chest data, PNEUMONIA is treated as the positive class. For multiple skin
classes, `macro_sensitivity_ovr` and `macro_specificity_ovr` are macro
one-vs-rest averages; the single-class sensitivity/specificity values use
class index 1 for skin (not a clinically defined positive class). ECE is
reported with 15 equal-width confidence bins. The optional `faithfulness.py`
utility computes the drop in predicted-class confidence after replacing the
most salient 20% of an image with its mean color. These measures are
dataset-dependent and are not substitutes for external validation, subgroup
analysis, calibration review, or clinical assessment.

## Walkthrough video

`assets/demo_walkthrough.mp4` is a short, locally generated synthetic UI-style
walkthrough encoded as H.264 MP4 (`yuv420p`) for broad browser/player
compatibility. Regenerate it with:

```bash
python scripts/make_demo_video.py
```

It contains a synthetic chest-like illustration and a fabricated heatmap to
demonstrate the interface only. It does not call the model or depict real
patient data.
