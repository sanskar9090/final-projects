param(
    [string]$Key = "customer-42",
    [int]$Calls = 220,
    [string]$Address = "localhost:50051"
)

$allowed = 0
$limited = 0
$degraded = 0

for ($i = 1; $i -le $Calls; $i++) {
    $json = @{ key = $Key } | ConvertTo-Json -Compress
    $output = & grpcurl -plaintext -d $json $Address ratelimit.v1.RateLimiter/Check
    if ($LASTEXITCODE -ne 0) {
        throw "grpcurl failed on call $i with exit code $LASTEXITCODE"
    }
    $response = $output | ConvertFrom-Json
    if ($response.allowed) {
        $allowed++
    }
    switch ($response.status) {
        "DECISION_STATUS_LIMITED" { $limited++ }
        "DECISION_STATUS_DEGRADED" { $degraded++ }
    }
}

[pscustomobject]@{
    key = $Key
    calls = $Calls
    allowed = $allowed
    limited = $limited
    degraded = $degraded
} | ConvertTo-Json
