use axum::{http::StatusCode, response::IntoResponse};
use once_cell::sync::Lazy;
use prometheus::{
    Encoder, Histogram, HistogramOpts, IntCounterVec, IntGauge, TextEncoder,
};

pub static CHECKS: Lazy<IntCounterVec> = Lazy::new(|| {
    prometheus::register_int_counter_vec!(
        "rate_limiter_checks_total",
        "Rate-limit decisions by outcome.",
        &["outcome"]
    )
    .expect("register rate_limiter_checks_total")
});

pub static REDIS_ERRORS: Lazy<IntCounterVec> = Lazy::new(|| {
    prometheus::register_int_counter_vec!(
        "rate_limiter_redis_errors_total",
        "Redis Cluster reservation failures.",
        &["operation"]
    )
    .expect("register rate_limiter_redis_errors_total")
});

pub static REDIS_RESERVATIONS: Lazy<IntCounterVec> = Lazy::new(|| {
    prometheus::register_int_counter_vec!(
        "rate_limiter_redis_reservations_total",
        "Successful Redis token-batch reservations.",
        &["result"]
    )
    .expect("register rate_limiter_redis_reservations_total")
});

pub static REQUEST_LATENCY: Lazy<Histogram> = Lazy::new(|| {
    prometheus::register_histogram!(HistogramOpts::new(
        "rate_limiter_check_duration_seconds",
        "End-to-end Check RPC decision latency."
    ))
    .expect("register rate_limiter_check_duration_seconds")
});

pub static REDIS_LATENCY: Lazy<Histogram> = Lazy::new(|| {
    prometheus::register_histogram!(HistogramOpts::new(
        "rate_limiter_redis_reservation_duration_seconds",
        "Redis token reservation latency."
    ))
    .expect("register rate_limiter_redis_reservation_duration_seconds")
});

pub static LOCAL_LEASE_TOKENS: Lazy<IntGauge> = Lazy::new(|| {
    prometheus::register_int_gauge!(
        "rate_limiter_local_lease_tokens",
        "Current unspent locally leased permits across this process."
    )
    .expect("register rate_limiter_local_lease_tokens")
});

pub async fn metrics_handler() -> Result<String, StatusCode> {
    let mut output = Vec::new();
    TextEncoder::new()
        .encode(&prometheus::gather(), &mut output)
        .map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)?;
    String::from_utf8(output).map_err(|_| StatusCode::INTERNAL_SERVER_ERROR)
}

pub async fn health_handler() -> impl IntoResponse {
    (StatusCode::OK, "ok\n")
}
