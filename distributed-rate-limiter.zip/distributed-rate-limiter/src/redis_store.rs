use anyhow::{Context, Result};
use redis::{
    cluster::ClusterClient, cluster_async::ClusterConnection, Script,
};
use std::{
    sync::atomic::{AtomicUsize, Ordering},
    time::{Duration, Instant},
};
use tokio::sync::Mutex;

const CONNECTION_POOL_SIZE: usize = 8;
const REDIS_OPERATION_TIMEOUT: Duration = Duration::from_millis(500);

const RESERVE_SCRIPT: &str = r#"
local now = redis.call('TIME')
local now_ms = now[1] * 1000 + math.floor(now[2] / 1000)
local capacity = tonumber(ARGV[1])
local rate_per_second = tonumber(ARGV[2])
local requested = tonumber(ARGV[3])
local tokens = tonumber(redis.call('HGET', KEYS[1], 'tokens'))
local last_ms = tonumber(redis.call('HGET', KEYS[1], 'updated_ms'))
if tokens == nil then tokens = capacity end
if last_ms == nil then last_ms = now_ms end
tokens = math.min(capacity, tokens + math.max(0, now_ms - last_ms) * rate_per_second / 1000)
local granted = math.min(requested, math.floor(tokens))
tokens = tokens - granted
redis.call('HSET', KEYS[1], 'tokens', tokens, 'updated_ms', now_ms)
redis.call('PEXPIRE', KEYS[1], math.max(60000, math.ceil(capacity * 1000 / rate_per_second * 2)))
local retry_ms = 0
if granted == 0 and tokens < 1 then
  retry_ms = math.ceil((1 - tokens) * 1000 / rate_per_second)
end
return {granted, retry_ms}
"#;

pub struct RedisClusterStore {
    client: ClusterClient,
    connections: Vec<Mutex<Option<ClusterConnection>>>,
    next_connection: AtomicUsize,
}

impl RedisClusterStore {
    pub fn new(nodes: Vec<String>) -> Result<Self> {
        let client = ClusterClient::new(nodes).context("creating Redis Cluster client")?;
        Ok(Self {
            client,
            connections: (0..CONNECTION_POOL_SIZE)
                .map(|_| Mutex::new(None))
                .collect(),
            next_connection: AtomicUsize::new(0),
        })
    }

    pub async fn reserve(
        &self,
        key: &str,
        capacity: u32,
        rate_per_second: u32,
        requested: u32,
    ) -> Result<Reservation> {
        let started = Instant::now();
        let slot = self.next_connection.fetch_add(1, Ordering::Relaxed) % self.connections.len();
        let mut connection = self.connections[slot].lock().await;
        if connection.is_none() {
            let connected = tokio::time::timeout(
                REDIS_OPERATION_TIMEOUT,
                self.client.get_async_connection(),
            )
            .await
            .context("timed out connecting to Redis Cluster")?
            .context("connecting to Redis Cluster")?;
            *connection = Some(connected);
        }
        let redis_key = format!("rl:{{{key}}}:bucket");
        let script = Script::new(RESERVE_SCRIPT);
        let mut invocation = script.key(redis_key);
        invocation.arg(capacity).arg(rate_per_second).arg(requested);
        let result = tokio::time::timeout(
            REDIS_OPERATION_TIMEOUT,
            invocation.invoke_async::<Vec<u64>>(
                connection.as_mut().expect("connection initialized"),
            ),
        )
        .await;
        let result = match result {
            Ok(Ok(result)) => result,
            Ok(Err(err)) => {
                *connection = None;
                return Err(err).context("running atomic token reservation script");
            }
            Err(_) => {
                *connection = None;
                anyhow::bail!("timed out running atomic token reservation script");
            }
        };
        if result.len() != 2 {
            anyhow::bail!("Redis reservation script returned {} fields, expected 2", result.len());
        }
        Ok(Reservation {
            granted: u32::try_from(result[0]).context("reservation grant exceeds u32")?,
            retry_after_ms: result[1],
            elapsed: started.elapsed(),
        })
    }
}

#[derive(Debug)]
pub struct Reservation {
    pub granted: u32,
    pub retry_after_ms: u64,
    pub elapsed: std::time::Duration,
}
