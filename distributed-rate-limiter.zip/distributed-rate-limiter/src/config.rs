use anyhow::{bail, Context};
use std::{env, time::Duration};

#[derive(Clone, Debug)]
pub struct Config {
    pub redis_nodes: Vec<String>,
    pub requests_per_second: u32,
    pub burst_capacity: u32,
    pub lease_size: u32,
    pub lease_ttl: Duration,
    pub failure_mode: FailureMode,
    pub grpc_addr: String,
    pub metrics_addr: String,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum FailureMode {
    Open,
    Closed,
}

impl Config {
    pub fn from_env() -> anyhow::Result<Self> {
        let redis_nodes = env::var("REDIS_NODES")
            .unwrap_or_else(|_| "redis://localhost:7001,redis://localhost:7002,redis://localhost:7003".to_owned())
            .split(',')
            .map(str::trim)
            .filter(|node| !node.is_empty())
            .map(str::to_owned)
            .collect::<Vec<_>>();
        if redis_nodes.is_empty() {
            bail!("REDIS_NODES must contain at least one Redis Cluster node URL");
        }

        let requests_per_second = number("RATE_LIMIT_RPS", 100)?;
        let burst_capacity = number("BURST_CAPACITY", 200)?;
        let lease_size = number("LEASE_SIZE", 16)?;
        let lease_ttl_ms: u64 = number("LEASE_TTL_MS", 250)?;
        if requests_per_second == 0 || burst_capacity == 0 || lease_size == 0 || lease_ttl_ms == 0 {
            bail!("RATE_LIMIT_RPS, BURST_CAPACITY, LEASE_SIZE, and LEASE_TTL_MS must be positive");
        }
        if lease_size > burst_capacity {
            bail!("LEASE_SIZE must not exceed BURST_CAPACITY");
        }
        let failure_mode = match env::var("FAILURE_MODE")
            .unwrap_or_else(|_| "closed".to_owned())
            .to_ascii_lowercase()
            .as_str()
        {
            "open" => FailureMode::Open,
            "closed" => FailureMode::Closed,
            value => bail!("FAILURE_MODE must be 'open' or 'closed', got {value:?}"),
        };

        Ok(Self {
            redis_nodes,
            requests_per_second,
            burst_capacity,
            lease_size,
            lease_ttl: Duration::from_millis(lease_ttl_ms),
            failure_mode,
            grpc_addr: env::var("GRPC_ADDR").unwrap_or_else(|_| "0.0.0.0:50051".to_owned()),
            metrics_addr: env::var("METRICS_ADDR").unwrap_or_else(|_| "0.0.0.0:9090".to_owned()),
        })
    }
}

fn number<T>(name: &str, default: T) -> anyhow::Result<T>
where
    T: std::str::FromStr,
    T::Err: std::fmt::Display,
{
    match env::var(name) {
        Ok(value) => value
            .parse()
            .map_err(|err| anyhow::anyhow!("invalid {name}={value:?}: {err}")),
        Err(env::VarError::NotPresent) => Ok(default),
        Err(err) => Err(err).with_context(|| format!("reading {name}")),
    }
}
