mod config;
mod limiter;
mod metrics;
mod redis_store;

use anyhow::Context;
use axum::{routing::get, Router};
use config::Config;
use limiter::DistributedLimiter;
use redis_store::RedisClusterStore;
use std::{net::SocketAddr, sync::Arc};
use tonic::transport::Server;
use tracing::{error, info};
use tracing_subscriber::EnvFilter;

pub mod rate_limiter {
    tonic::include_proto!("ratelimit.v1");
}

use rate_limiter::rate_limiter_server::RateLimiterServer;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info")))
        .init();

    let config = Config::from_env()?;
    let grpc_addr: SocketAddr = config.grpc_addr.parse().context("invalid GRPC_ADDR")?;
    let metrics_addr: SocketAddr = config.metrics_addr.parse().context("invalid METRICS_ADDR")?;
    let store = Arc::new(RedisClusterStore::new(config.redis_nodes.clone())?);
    let limiter = DistributedLimiter::new(store, config.clone());
    let http = Router::new()
        .route("/metrics", get(metrics::metrics_handler))
        .route("/healthz", get(metrics::health_handler));
    let grpc = Server::builder()
        .add_service(RateLimiterServer::new(limiter))
        .serve_with_shutdown(grpc_addr, shutdown_signal());

    info!(%grpc_addr, %metrics_addr, "rate limiter starting");
    let metrics_server = async move {
        axum::serve(
            tokio::net::TcpListener::bind(metrics_addr).await?,
            http,
        )
        .with_graceful_shutdown(shutdown_signal())
        .await
        .context("metrics HTTP server failed")
    };

    tokio::select! {
        result = grpc => result.context("gRPC server failed")?,
        result = metrics_server => result?,
    }
    Ok(())
}

async fn shutdown_signal() {
    if let Err(err) = tokio::signal::ctrl_c().await {
        error!(%err, "failed to listen for shutdown signal");
    }
}
