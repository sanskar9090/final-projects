use crate::{
    config::{Config, FailureMode},
    metrics,
    rate_limiter::{
        rate_limiter_server::RateLimiter, CheckRequest, CheckResponse, DecisionStatus,
    },
    redis_store::RedisClusterStore,
};
use dashmap::DashMap;
use std::{
    sync::{
        atomic::{AtomicU64, Ordering},
        Arc,
    },
    time::{Duration, Instant},
};
use tokio::sync::Mutex;
use tonic::{Request, Response, Status};
use tracing::{error, warn};

#[derive(Default)]
struct LocalLease {
    remaining: u32,
    expires_at: Option<Instant>,
    last_used: Instant,
}

impl Default for LocalLease {
    fn default() -> Self {
        Self {
            remaining: 0,
            expires_at: None,
            last_used: Instant::now(),
        }
    }
}

pub struct DistributedLimiter {
    store: Arc<RedisClusterStore>,
    config: Config,
    leases: DashMap<String, Arc<Mutex<LocalLease>>>,
    checks: AtomicU64,
}

impl DistributedLimiter {
    pub fn new(store: Arc<RedisClusterStore>, config: Config) -> Self {
        Self {
            store,
            config,
            leases: DashMap::new(),
            checks: AtomicU64::new(0),
        }
    }

    async fn decide(&self, key: &str) -> CheckResponse {
        if self.checks.fetch_add(1, Ordering::Relaxed) % 256 == 0 {
            self.leases.retain(|_, lease| {
                if Arc::strong_count(lease) != 1 {
                    return true;
                }
                let now = Instant::now();
                lease.try_lock().map(|state| {
                    let expired = state
                        .expires_at
                        .map(|expires| expires <= now)
                        .unwrap_or(true);
                    if state.last_used.elapsed() < Duration::from_secs(60) || !expired {
                        true
                    } else {
                        metrics::LOCAL_LEASE_TOKENS.sub(state.remaining as i64);
                        false
                    }
                }).unwrap_or(true)
            });
        }
        let digest = hex_key(key);
        let lease = self
            .leases
            .entry(digest.clone())
            .or_insert_with(|| Arc::new(Mutex::new(LocalLease::default())))
            .clone();
        let mut lease = lease.lock().await;
        lease.last_used = Instant::now();
        if lease.expires_at.is_some_and(|expires| expires <= Instant::now()) {
            metrics::LOCAL_LEASE_TOKENS.sub(lease.remaining as i64);
            lease.remaining = 0;
            lease.expires_at = None;
        }

        if lease.remaining > 0 {
            return consume_local(&mut lease);
        }

        let requested = self.config.lease_size.min(self.config.burst_capacity);
        match self
            .store
            .reserve(
                &digest,
                self.config.burst_capacity,
                self.config.requests_per_second,
                requested,
            )
            .await
        {
            Ok(reservation) => {
                metrics::REDIS_LATENCY.observe(reservation.elapsed.as_secs_f64());
                if reservation.granted == 0 {
                    metrics::REDIS_RESERVATIONS
                        .with_label_values(&["empty"])
                        .inc();
                    CheckResponse {
                        allowed: false,
                        retry_after_ms: reservation.retry_after_ms,
                        local_tokens_remaining: 0,
                        reason: "rate limit exceeded".to_owned(),
                        status: DecisionStatus::Limited as i32,
                    }
                } else {
                    metrics::REDIS_RESERVATIONS
                        .with_label_values(&["granted"])
                        .inc();
                    lease.remaining = reservation.granted;
                    lease.expires_at = Some(Instant::now() + self.config.lease_ttl);
                    metrics::LOCAL_LEASE_TOKENS.add(reservation.granted as i64);
                    consume_local(&mut lease)
                }
            }
            Err(err) => {
                metrics::REDIS_ERRORS
                    .with_label_values(&["reserve"])
                    .inc();
                error!(%err, "Redis token reservation failed");
                match self.config.failure_mode {
                    FailureMode::Open => {
                        warn!("allowing request because FAILURE_MODE=open");
                        CheckResponse {
                            allowed: true,
                            retry_after_ms: 0,
                            local_tokens_remaining: 0,
                            reason: "allowed in fail-open mode; shared quota could not be checked"
                                .to_owned(),
                            status: DecisionStatus::Degraded as i32,
                        }
                    }
                    FailureMode::Closed => CheckResponse {
                        allowed: false,
                        retry_after_ms: 100,
                        local_tokens_remaining: 0,
                        reason: "shared quota unavailable; denied in fail-closed mode".to_owned(),
                        status: DecisionStatus::Degraded as i32,
                    },
                }
            }
        }
    }
}

fn consume_local(lease: &mut LocalLease) -> CheckResponse {
    lease.remaining -= 1;
    metrics::LOCAL_LEASE_TOKENS.dec();
    CheckResponse {
        allowed: true,
        retry_after_ms: 0,
        local_tokens_remaining: lease.remaining,
        reason: "allowed".to_owned(),
        status: DecisionStatus::Allowed as i32,
    }
}

fn hex_key(key: &str) -> String {
    use sha2::{Digest, Sha256};
    let digest = Sha256::digest(key.as_bytes());
    digest.iter().map(|byte| format!("{byte:02x}")).collect()
}

#[tonic::async_trait]
impl RateLimiter for DistributedLimiter {
    async fn check(
        &self,
        request: Request<CheckRequest>,
    ) -> Result<Response<CheckResponse>, Status> {
        let started = Instant::now();
        let key = request.into_inner().key;
        if key.trim().is_empty() {
            return Err(Status::invalid_argument("key must not be empty"));
        }
        if key.len() > 256 {
            return Err(Status::invalid_argument(
                "key must not exceed 256 UTF-8 bytes",
            ));
        }
        let mut decision = self.decide(&key).await;
        metrics::REQUEST_LATENCY.observe(started.elapsed().as_secs_f64());
        let outcome = match decision.status {
            x if x == DecisionStatus::Allowed as i32 => "allowed",
            x if x == DecisionStatus::Limited as i32 => "limited",
            _ => "degraded",
        };
        metrics::CHECKS.with_label_values(&[outcome]).inc();
        if !decision.allowed && decision.retry_after_ms == 0 {
            decision.retry_after_ms = 1;
        }
        Ok(Response::new(decision))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn key_digest_is_fixed_width_and_does_not_expose_input() {
        let digest = hex_key("tenant-secret");
        assert_eq!(digest.len(), 64);
        assert!(!digest.contains("tenant-secret"));
    }

    #[test]
    fn consume_reduces_lease_and_returns_remaining_count() {
        let mut lease = LocalLease {
            remaining: 3,
            expires_at: Some(Instant::now() + std::time::Duration::from_secs(1)),
            last_used: Instant::now(),
        };
        let response = consume_local(&mut lease);
        assert!(response.allowed);
        assert_eq!(response.local_tokens_remaining, 2);
        assert_eq!(lease.remaining, 2);
    }
}
