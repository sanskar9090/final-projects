# Distributed Rate Limiter

A Rust/Tonic reference service for distributed per-key token-bucket decisions. Redis Cluster atomically allocates short-lived batches of permits; each service replica consumes those permits from a mutex-protected local cache. Prometheus and Grafana expose request outcomes, latency, Redis reservations, and cached permits.

## Start the demo

Requirements: Docker Compose v2. Build and start the six-node Redis Cluster, gRPC service, Prometheus, and Grafana:

```powershell
docker compose up --build
```

The cluster bootstrap job assigns all 16,384 slots across three Redis primaries and three replicas. The service listens on `localhost:50051`; Prometheus is at `http://localhost:9091`; Grafana is at `http://localhost:3000` (default local demo login: `admin` / `admin`).

To exercise cross-replica permit reservations, start three service instances. Published port ranges assign host ports `50051`-`50053` to gRPC and `9090`-`9092` to each replica's metrics endpoint:

```powershell
docker compose up --build --scale limiter=3
```

Use a gRPC load balancer to distribute traffic across all three ports; the example call below targets one instance. The demo Prometheus target is intended for a single instance; configure per-replica service discovery in a real deployment.

Send a request using `grpcurl`:

```powershell
grpcurl -plaintext -d '{"key":"customer-42"}' localhost:50051 ratelimit.v1.RateLimiter/Check
```

Repeat the call rapidly. With defaults, the example key is limited to 100 newly replenished tokens/second, with a burst capacity of 200. Responses distinguish `ALLOWED`, `LIMITED`, and `DEGRADED`.

Check observability:

```powershell
Invoke-WebRequest http://localhost:9090/metrics
```

Open Grafana and select the provisioned **Distributed Rate Limiter** dashboard. Stop the demo with `Ctrl+C` in the Compose terminal; use `docker compose down` to remove its containers.

## Configuration

| Variable | Default | Meaning |
| --- | ---: | --- |
| `REDIS_NODES` | local ports 7001-7003 | Comma-separated Redis Cluster seed URLs |
| `RATE_LIMIT_RPS` | `100` | Refill tokens per second, per key |
| `BURST_CAPACITY` | `200` | Maximum token bucket balance |
| `LEASE_SIZE` | `16` | Maximum permit batch reserved by one replica |
| `LEASE_TTL_MS` | `250` | Cache lifetime before unused permits are discarded |
| `FAILURE_MODE` | `closed` | `closed` denies when Redis is unavailable; `open` allows with a degraded response |
| `GRPC_ADDR` | `0.0.0.0:50051` | gRPC listen address |
| `METRICS_ADDR` | `0.0.0.0:9090` | HTTP metrics and health listen address |

`compose.yaml` supplies its own internal six-node cluster and defaults, so these settings are optional for the included demo.

## Design and guarantees

- Redis Lua uses Redis server time and performs refill plus batch reservation atomically for one SHA-256-derived key. Concurrent replicas cannot reserve the same stored tokens.
- The local DashMap selects a per-key async mutex; the mutex serializes lease expiry, permit consumption, and refill attempts within a process without blocking unrelated keys.
- Keys are hashed before being used in Redis key names. Prometheus labels do not include tenant or request keys.
- The cache reduces shared-store calls: a batch of up to 16 requests normally consumes one Redis reservation rather than one Redis round trip per request.
- This is a **leased token-bucket approximation**, not a strict globally synchronized sliding window. Up to `LEASE_SIZE` reserved permits per active replica may be consumed after their reservation time, and unused permits are intentionally discarded at lease expiry. This limits Redis calls at the cost of bounded burst drift and possible under-utilization. For strict per-request enforcement, reserve exactly one permit per RPC (`LEASE_SIZE=1`).
- Redis Cluster provides data availability through primary/replica failover, but writes acknowledged by a primary immediately before failover may be lost depending on Redis replication and persistence settings. This demo does not claim linearizable durability.
- Fail-open mode deliberately favors availability and can exceed quota while Redis is unreachable. Fail-closed mode favors enforcement and denies new requests without a local permit. Both modes emit degraded responses and metrics.

The supplied Compose setup is a local demonstration, not a production cluster. Production deployment should use authenticated TLS, secret management, hardened network policies, persistent volumes, replica-aware placement, resource limits, and tested failover procedures.

## Source map

- `src/limiter.rs`: per-key synchronization, local permit consumption, and gRPC decisions.
- `src/redis_store.rs`: Redis Cluster client and atomic Lua token-bucket reservation.
- `src/config.rs`: validated environment-based configuration.
- `proto/limiter.proto`: public gRPC API.
- `observability/`: Prometheus scrape configuration and provisioned Grafana dashboard.
- `docs/`: design, operations, demo narration, and file-extension reference.
- `presentation/`: project slide deck.
- `videos/`: four standalone 31-second MP4 explainers.
- `demo/`: a parameterized PowerShell load example and representative JSON responses.
- `tools/generate_media.py`: reproducible slide/video generator (install `tools/requirements-media.txt` first).

Run the repeat-call example after starting the stack:

```powershell
.\demo\Invoke-LimiterDemo.ps1 -Key "customer-42" -Calls 220
```

It prints JSON containing the selected key, call count, allowed, limited, and degraded totals. Results depend on request timing and cluster traffic; `demo/sample-output.json` shows example RPC responses, not a guaranteed count.

## Build from source

Requires Rust/Cargo and `protoc`:

```powershell
cargo test
cargo run
```

When running outside Compose, set `REDIS_NODES` to reachable Redis Cluster seed addresses first. The application starts the gRPC and metrics listeners; Redis should already be initialized as a cluster.
