# Operations and failure testing

## Local services

`docker compose up --build` starts a three-primary/three-replica Redis Cluster, the Rust gRPC service, Prometheus, and Grafana. Add `--scale limiter=3` to exercise cross-replica quota reservations; distribute clients across host ports 50051-50053. Check service readiness:

```powershell
Invoke-WebRequest http://localhost:9090/healthz
Invoke-WebRequest http://localhost:9090/metrics
```

`/healthz` reports process liveness only; it does not assert Redis readiness. This avoids turning a shared-store outage into orchestrated restart loops. Observe `rate_limiter_redis_errors_total` and degraded decisions for store health.

## Failure modes

- **Redis unavailable, closed mode:** requests with an unexpired local permit can still proceed; requests needing a new lease are denied with `DEGRADED`.
- **Redis unavailable, open mode:** requests needing a lease are allowed with `DEGRADED`; quotas are not enforced during the outage.
- **Primary failover:** the Redis Cluster client follows MOVED/ASK responses and reconnects. A failover can lose recently acknowledged reservations if they were not replicated. Validate actual behavior with the exact Redis version and persistence/replication configuration used in production.
- **Local process restart:** its leases disappear. Already-reserved tokens are not refunded, which can temporarily reduce throughput but cannot duplicate those reservations.

## Example load and smoke tests

Use `grpcurl` or a generated client to issue repeated calls:

```powershell
1..220 | ForEach-Object {
  grpcurl -plaintext -d '{"key":"customer-42"}' localhost:50051 ratelimit.v1.RateLimiter/Check
}
```

At startup, up to `BURST_CAPACITY` tokens may be granted across the fleet. Use a fresh test key for an independent bucket. Check the Grafana dashboard for decision rates and p99 latency. This simple loop validates behavior, not a 10k-RPS capacity target.

For a throughput test, run a controlled multi-client load generator against all intended service replicas and Redis primaries, use realistic key cardinality and request distributions, and record p50/p95/p99, decision correctness, Redis QPS, CPU, and failover behavior. The requested 10,000 RPS is a design target, not a benchmark result established by this package.

## Security and production checklist

- Put gRPC behind authenticated TLS and an authorization layer that binds caller identity to `key`.
- Use TLS/authenticated Redis, private networking, network policies, and managed secrets; never put credentials in `REDIS_NODES` logs or source control.
- Set connection/request deadlines, CPU/memory limits, and bounded concurrent RPCs at the ingress.
- Size Redis Cluster and service replicas using load tests; provision replicas across failure zones and test failover under traffic.
- Alert on Redis reservation errors, elevated degraded/limited decisions, and p99 latency.
- Avoid high-cardinality labels and do not expose the metrics endpoint publicly.
