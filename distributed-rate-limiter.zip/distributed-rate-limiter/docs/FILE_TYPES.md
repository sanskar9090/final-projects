# Project file and extension reference

This is the requested extension/file-type reference for the project.

| Extension | Used for |
| --- | --- |
| `.rs` | Rust service implementation |
| `.proto` | gRPC service and message definitions |
| `.toml` | Rust package manifest |
| `.yaml` / `.yml` | Docker Compose, Prometheus, and Grafana provisioning |
| `.json` | Grafana dashboard definition |
| `.md` | Project, architecture, operations, and demo documentation |
| `.pptx` | PowerPoint-compatible project presentation |
| `.mp4` | Standalone short explainer videos |
| `.example` | Copyable sample environment settings |
| `Dockerfile` | Multi-stage container build instructions |
