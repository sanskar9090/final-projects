# Video narration and timing

The four rendered MP4s are silent, captioned 31-second explainers. Narration scripts are included below for recording or re-voicing.

## 1. `01-topic-overview.mp4`

**0-6s:** “This project is a distributed rate limiter built for regional microservices.”

**6-13s:** “It protects APIs by deciding whether each tenant or resource may continue.”

**13-21s:** “A token bucket gives smooth refill with a configurable burst allowance.”

**21-31s:** “The design combines Rust, gRPC, Redis Cluster, local permit leases, and observable failure behavior.”

## 2. `02-stack-and-flow.mp4`

**0-7s:** “The service is implemented in Rust and exposes a Protocol Buffers gRPC API.”

**7-15s:** “Each replica has a mutex-protected in-memory permit cache, keyed by a digest.”

**15-23s:** “When the cache empties, an atomic Redis Lua script reserves a batch from the shared bucket.”

**23-31s:** “Prometheus scrapes metrics, and Grafana visualizes request decisions and latency.”

## 3. `03-output-and-observability.mp4`

**0-8s:** “A Check response says allowed or limited, includes a retry hint, and reports local permits remaining.”

**8-16s:** “If Redis fails, the service marks the response degraded and follows the configured open or closed policy.”

**16-24s:** “Prometheus metrics show decision totals, Redis errors, reservation counts, and latency histograms.”

**24-31s:** “The dashboard helps operators see load and failures without exposing tenant identifiers.”

## 4. `04-live-demo-example.mp4`

**0-6s:** “Start the local stack with Docker Compose.”

**6-13s:** “Call the gRPC Check method with the key customer dash forty-two.”

**13-21s:** “Repeated calls consume permits; after the burst, the response is limited and gives a retry delay.”

**21-31s:** “Change the key to create an independent bucket, then inspect metrics and the Grafana dashboard.”
