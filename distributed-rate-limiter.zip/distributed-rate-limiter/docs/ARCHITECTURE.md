# Architecture and protocol

## Request path

1. A client calls `ratelimit.v1.RateLimiter/Check` with a stable tenant/resource key.
2. The service rejects an empty key, hashes it, and obtains its local per-key async mutex.
3. If an unexpired local lease has a permit, the service decrements it and responds without contacting Redis.
4. Otherwise, the service runs one Lua script on a Redis Cluster primary. The script reads Redis server time, refills the token bucket, reserves up to `LEASE_SIZE` permits, persists the new balance, and returns the reservation and retry delay atomically.
5. The local replica caches the reserved permits until `LEASE_TTL_MS`; concurrent calls for that same key cannot race the local count or issue duplicate reservations.
6. If Redis cannot be reached, the configured failure mode decides whether to return an allowed-but-degraded or denied-and-degraded response.

The Redis key uses a digest in a Redis Cluster hash tag (`rl:{digest}:bucket`), ensuring the Lua script operates on a single key and is routable to one hash slot.

## Token bucket

For a bucket capacity `B`, refill rate `r` tokens/s, previous balance `T`, and elapsed Redis server time `dt`, the script computes:

`T' = min(B, T + r * dt)`

It reserves `min(requested_batch, floor(T'))` and stores the remaining balance. A zero reservation returns `ceil((1 - T') / r)` milliseconds as the retry hint. Expiration is at least 60 seconds and otherwise twice the full refill duration.

## Synchronization and tradeoffs

The Redis script is the cross-replica synchronization boundary. Redis serializes scripts on the key's primary, so two replicas cannot both reserve the same token balance. The per-key Tokio mutex is the local synchronization boundary: only one request in a process can consume or replenish that key's cached lease at a time. Different keys are not serialized together.

The tradeoff is intentional: batching reduces Redis QPS but leased tokens are accounted for when reserved, not when consumed. A busy key can have at most one current lease per replica. With `N` active replicas and lease size `L`, up to approximately `N × L` permits can be outstanding across local caches; those permits may shift burst timing. Reduce `L` to tighten the bound or set `L=1` for a Redis check on every exhausted local permit. Expired local permits are not returned because refunding from multiple replicas requires another synchronization protocol and can introduce duplicate refunds.

All replicas sharing a Redis Cluster must use the same `RATE_LIMIT_RPS`, `BURST_CAPACITY`, and compatible lease settings. Different refill/capacity values for one hashed key would make the shared bucket policy inconsistent.

## API

`CheckRequest.key` is a stable, non-empty tenant/resource identifier. `CheckResponse.status` is one of `ALLOWED`, `LIMITED`, or `DEGRADED`; `allowed` is the direct decision, `retry_after_ms` is a retry hint, and `local_tokens_remaining` reports only this process's remaining lease. It is not the globally available token count.
