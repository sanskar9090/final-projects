fn main() -> Result<(), Box<dyn std::error::Error>> {
    tonic_build::configure()
        .build_server(true)
        .compile(&["proto/limiter.proto"], &["proto"])?;
    println!("cargo:rerun-if-changed=proto/limiter.proto");
    Ok(())
}
