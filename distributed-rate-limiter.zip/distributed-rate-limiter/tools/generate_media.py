from pathlib import Path
import html
import xml.etree.ElementTree as ET
import zipfile

from PIL import Image, ImageDraw, ImageFont
import imageio.v2 as imageio
import numpy as np


ROOT = Path(__file__).resolve().parents[1]
VIDEO_DIR = ROOT / "videos"
PRESENTATION_DIR = ROOT / "presentation"
WIDTH, HEIGHT = 1280, 720
FPS = 10
DURATION_SECONDS = 31

P = "http://schemas.openxmlformats.org/presentationml/2006/main"
A = "http://schemas.openxmlformats.org/drawingml/2006/main"
R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
REL = "http://schemas.openxmlformats.org/package/2006/relationships"
CT = "http://schemas.openxmlformats.org/package/2006/content-types"

ET.register_namespace("p", P)
ET.register_namespace("a", A)
ET.register_namespace("r", R)
ET.register_namespace("rel", REL)
ET.register_namespace("ct", CT)

SLIDES = [
    {
        "title": "Distributed Rate Limiter",
        "subtitle": "Low-latency token bucket for regional microservices",
        "bullets": ["Rust + gRPC", "Redis Cluster token reservations", "Local permit leases", "Prometheus + Grafana"],
        "tag": "REFERENCE PROJECT",
    },
    {
        "title": "The problem",
        "subtitle": "Protect shared services without making every request wait on a central store.",
        "bullets": ["Coordinate limits across replicas", "Keep the hot path fast", "Control burst traffic", "Make store failures explicit"],
        "tag": "GOAL: 10,000 REQUESTS / SECOND",
    },
    {
        "title": "Request path",
        "subtitle": "A short local path; an atomic shared reservation when local permits run out.",
        "bullets": ["Client calls the Check gRPC method", "Per-key mutex serializes local lease access", "Lua atomically reserves a batch in Redis", "Local permit is consumed and returned"],
        "tag": "ONE KEY • ONE REDIS HASH SLOT",
    },
    {
        "title": "Synchronization",
        "subtitle": "Redis prevents cross-replica double reservation; the local mutex prevents local races.",
        "bullets": ["Redis server time refills the token bucket", "Batch reservations reduce Redis QPS", "Expired unused permits are discarded", "Set lease size to 1 for tighter enforcement"],
        "tag": "BOUNDED BURST DRIFT IS DOCUMENTED",
    },
    {
        "title": "Failure and observability",
        "subtitle": "Choose enforcement or availability deliberately when the shared store is down.",
        "bullets": ["Fail closed: deny without a cached permit", "Fail open: allow and mark degraded", "Prometheus records decisions and latency", "Grafana ships with a provisioned dashboard"],
        "tag": "NO TENANT IDS IN METRIC LABELS",
    },
    {
        "title": "Run the demo",
        "subtitle": "Start Redis Cluster, the Rust service, Prometheus, and Grafana together.",
        "bullets": ["docker compose up --build", "grpcurl -plaintext -d '{\"key\":\"customer-42\"}' localhost:50051 ratelimit.v1.RateLimiter/Check", "Metrics: localhost:9090/metrics", "Dashboard: localhost:3000"],
        "tag": "10K RPS IS A TARGET — LOAD TEST YOUR DEPLOYMENT",
    },
]

VIDEO_SETS = [
    [
        ("DISTRIBUTED RATE LIMITER", "A low-latency control for regional microservices."),
        ("THE CHALLENGE", "Share quota across replicas without a Redis round trip for every request."),
        ("TOKEN BUCKET", "Refill at a configured rate; allow a bounded burst."),
        ("RUST + gRPC", "A compact, typed API serves limiter decisions."),
        ("SHARED COORDINATION", "Redis Cluster atomically reserves permits for each key."),
        ("THE DESIGN", "Local leases reduce store traffic; tradeoffs are made visible."),
    ],
    [
        ("RUST SERVICE", "Handles the request path with a small runtime and typed messages."),
        ("gRPC + PROTOBUF", "The Check RPC accepts a tenant or resource key."),
        ("LOCAL CACHE", "DashMap locates a key; a Tokio mutex protects permit consumption."),
        ("REDIS LUA", "One atomic script refills and reserves shared bucket tokens."),
        ("PROMETHEUS", "Scrapes outcomes, errors, cached permits, and latency."),
        ("GRAFANA", "Shows decisions and p99 latency in the included dashboard."),
    ],
    [
        ("DECISION OUTPUT", "Each response reports allowed, limited, or degraded."),
        ("RETRY HINT", "Limited replies include a retry-after duration."),
        ("LOCAL BALANCE", "The remaining-permits field belongs to this service replica."),
        ("FAILOVER", "When Redis fails, open or closed policy is explicit."),
        ("METRICS", "Observe decisions, Redis reservations, and latency."),
        ("SAFE LABELS", "Tenant keys are hashed for Redis and omitted from metric labels."),
    ],
    [
        ("LIVE DEMO", "Start the stack with Docker Compose."),
        ("INPUT KEY", "Choose a stable identifier, for example customer-42."),
        ("SEND CHECK", "grpcurl -plaintext -d '{\"key\":\"customer-42\"}' localhost:50051 ratelimit.v1.RateLimiter/Check"),
        ("CONSUME PERMITS", "Repeat quickly to spend the initial token-bucket burst."),
        ("LIVE RESPONSE", "{\"allowed\":true,\"status\":\"DECISION_STATUS_ALLOWED\",\"localTokensRemaining\":15}"),
        ("OBSERVE", "Change the key for a new bucket; inspect /metrics and Grafana."),
    ],
]

SCRIPTS = [
    "01-topic-overview.mp4",
    "02-stack-and-flow.mp4",
    "03-output-and-observability.mp4",
    "04-live-demo-example.mp4",
]


def font(size, bold=False):
    candidates = [
        Path(r"C:\Windows\Fonts\segoeui.ttf"),
        Path(r"C:\Windows\Fonts\segoeuib.ttf") if bold else Path(r"C:\Windows\Fonts\segoeui.ttf"),
    ]
    for candidate in candidates:
        if candidate.exists():
            return ImageFont.truetype(str(candidate), size)
    return ImageFont.load_default()


def wrap_lines(draw, text, face, width):
    words = text.split()
    lines = []
    current = ""
    for word in words:
        candidate = f"{current} {word}".strip()
        if current and draw.textbbox((0, 0), candidate, font=face)[2] > width:
            lines.append(current)
            current = word
        else:
            current = candidate
    if current:
        lines.append(current)
    return lines


def draw_card(video_index, slide_index, heading, caption):
    image = Image.new("RGB", (WIDTH, HEIGHT), "#07111f")
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle((70, 58, WIDTH - 70, HEIGHT - 58), radius=28, fill="#101f33", outline="#1b3958", width=2)
    draw.rectangle((70, 58, 84, HEIGHT - 58), fill="#35d0ba")
    draw.text((120, 105), f"RATE LIMITER  /  VIDEO {video_index + 1}", font=font(23, True), fill="#35d0ba")
    draw.text((120, 182), heading, font=font(45, True), fill="#f2f6fc")
    lines = wrap_lines(draw, caption, font(31), 990)
    y = 285
    for line in lines:
        draw.text((122, y), line, font=font(31), fill="#c7d5e6")
        y += 48
    draw.rounded_rectangle((120, 515, 1155, 602), radius=16, fill="#173450")
    draw.text((148, 541), f"SEGMENT {slide_index + 1} / 6    •    RUST  •  gRPC  •  REDIS CLUSTER", font=font(20, True), fill="#7ce5d6")
    draw.text((120, 635), "Distributed permits • bounded local cache • observable failover", font=font(18), fill="#8ea4bd")
    return image


def render_videos():
    VIDEO_DIR.mkdir(parents=True, exist_ok=True)
    total_frames = FPS * DURATION_SECONDS
    for video_index, segments in enumerate(VIDEO_SETS):
        path = VIDEO_DIR / SCRIPTS[video_index]
        writer = imageio.get_writer(
            str(path),
            fps=FPS,
            codec="libx264",
            pixelformat="yuv420p",
            quality=7,
            macro_block_size=1,
        )
        try:
            rendered = {}
            for frame_index in range(total_frames):
                segment_index = frame_index * len(segments) // total_frames
                if segment_index not in rendered:
                    heading, caption = segments[segment_index]
                    rendered[segment_index] = draw_card(video_index, segment_index, heading, caption)
                writer.append_data(np.asarray(rendered[segment_index]))
        finally:
            writer.close()


def qname(namespace, name):
    return f"{{{namespace}}}{name}"


def add_text_shape(tree, shape_id, name, text, x, y, width, height, size=2400, color="EAF2FA", bold=False):
    sp = ET.SubElement(tree, qname(P, "sp"))
    nv = ET.SubElement(sp, qname(P, "nvSpPr"))
    ET.SubElement(nv, qname(P, "cNvPr"), {"id": str(shape_id), "name": name})
    ET.SubElement(nv, qname(P, "cNvSpPr"), {"txBox": "1"})
    ET.SubElement(nv, qname(P, "nvPr"))
    sppr = ET.SubElement(sp, qname(P, "spPr"))
    xfrm = ET.SubElement(sppr, qname(A, "xfrm"))
    ET.SubElement(xfrm, qname(A, "off"), {"x": str(x), "y": str(y)})
    ET.SubElement(xfrm, qname(A, "ext"), {"cx": str(width), "cy": str(height)})
    geometry = ET.SubElement(sppr, qname(A, "prstGeom"), {"prst": "rect"})
    ET.SubElement(geometry, qname(A, "avLst"))
    ET.SubElement(sppr, qname(A, "noFill"))
    tx = ET.SubElement(sp, qname(P, "txBody"))
    ET.SubElement(tx, qname(A, "bodyPr"), {"wrap": "square", "anchor": "ctr"})
    ET.SubElement(tx, qname(A, "lstStyle"))
    paragraph = ET.SubElement(tx, qname(A, "p"))
    ET.SubElement(paragraph, qname(A, "pPr"), {"algn": "l"})
    run = ET.SubElement(paragraph, qname(A, "r"))
    props = {"lang": "en-US", "sz": str(size)}
    if bold:
        props["b"] = "1"
    rpr = ET.SubElement(run, qname(A, "rPr"), props)
    fill = ET.SubElement(rpr, qname(A, "solidFill"))
    ET.SubElement(fill, qname(A, "srgbClr"), {"val": color})
    ET.SubElement(rpr, qname(A, "latin"), {"typeface": "Aptos"})
    ET.SubElement(run, qname(A, "t")).text = text
    ET.SubElement(paragraph, qname(A, "endParaRPr"), {"lang": "en-US"})


def slide_xml(slide):
    root = ET.Element(qname(P, "sld"))
    c_sld = ET.SubElement(root, qname(P, "cSld"))
    bg = ET.SubElement(c_sld, qname(P, "bg"))
    bgpr = ET.SubElement(bg, qname(P, "bgPr"))
    solid = ET.SubElement(bgpr, qname(A, "solidFill"))
    ET.SubElement(solid, qname(A, "srgbClr"), {"val": "07111F"})
    tree = ET.SubElement(c_sld, qname(P, "spTree"))
    nv = ET.SubElement(tree, qname(P, "nvGrpSpPr"))
    ET.SubElement(nv, qname(P, "cNvPr"), {"id": "1", "name": ""})
    ET.SubElement(nv, qname(P, "cNvGrpSpPr"))
    ET.SubElement(nv, qname(P, "nvPr"))
    grp = ET.SubElement(tree, qname(P, "grpSpPr"))
    xfrm = ET.SubElement(grp, qname(A, "xfrm"))
    ET.SubElement(xfrm, qname(A, "off"), {"x": "0", "y": "0"})
    ET.SubElement(xfrm, qname(A, "ext"), {"cx": "0", "cy": "0"})
    ET.SubElement(xfrm, qname(A, "chOff"), {"x": "0", "y": "0"})
    ET.SubElement(xfrm, qname(A, "chExt"), {"cx": "0", "cy": "0"})
    add_text_shape(tree, 2, "Accent", "DISTRIBUTED SYSTEMS / RUST", 720000, 500000, 10800000, 480000, 1800, "35D0BA", True)
    add_text_shape(tree, 3, "Title", slide["title"], 720000, 1350000, 10800000, 1050000, 3600, "F2F6FC", True)
    add_text_shape(tree, 4, "Subtitle", slide["subtitle"], 720000, 2500000, 10800000, 1200000, 2300, "C7D5E6")
    y = 3900000
    for index, bullet in enumerate(slide["bullets"]):
        add_text_shape(tree, 5 + index, f"Point {index + 1}", f"•  {bullet}", 900000, y, 10400000, 500000, 1900, "C7D5E6")
        y += 550000
    add_text_shape(tree, 12, "Footer", slide["tag"], 720000, 6350000, 10800000, 350000, 1500, "7CE5D6", True)
    color_map = ET.SubElement(root, qname(P, "clrMapOvr"))
    ET.SubElement(color_map, qname(A, "masterClrMapping"))
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def relationship_xml(items):
    root = ET.Element(qname(REL, "Relationships"))
    for rel_id, rel_type, target in items:
        ET.SubElement(root, qname(REL, "Relationship"), {"Id": rel_id, "Type": rel_type, "Target": target})
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def content_types_xml():
    root = ET.Element(qname(CT, "Types"))
    ET.SubElement(root, qname(CT, "Default"), {"Extension": "rels", "ContentType": "application/vnd.openxmlformats-package.relationships+xml"})
    ET.SubElement(root, qname(CT, "Default"), {"Extension": "xml", "ContentType": "application/xml"})
    overrides = [
        ("/ppt/presentation.xml", "application/vnd.openxmlformats-officedocument.presentationml.presentation.main+xml"),
        ("/ppt/slideMasters/slideMaster1.xml", "application/vnd.openxmlformats-officedocument.presentationml.slideMaster+xml"),
        ("/ppt/slideLayouts/slideLayout1.xml", "application/vnd.openxmlformats-officedocument.presentationml.slideLayout+xml"),
        ("/ppt/theme/theme1.xml", "application/vnd.openxmlformats-officedocument.theme+xml"),
    ]
    overrides.extend((f"/ppt/slides/slide{i}.xml", "application/vnd.openxmlformats-officedocument.presentationml.slide+xml") for i in range(1, len(SLIDES) + 1))
    for part, content_type in overrides:
        ET.SubElement(root, qname(CT, "Override"), {"PartName": part, "ContentType": content_type})
    return ET.tostring(root, encoding="utf-8", xml_declaration=True)


def build_presentation():
    PRESENTATION_DIR.mkdir(parents=True, exist_ok=True)
    path = PRESENTATION_DIR / "distributed-rate-limiter.pptx"
    pres = ET.Element(qname(P, "presentation"))
    master_ids = ET.SubElement(pres, qname(P, "sldMasterIdLst"))
    ET.SubElement(master_ids, qname(P, "sldMasterId"), {"id": "2147483648", qname(R, "id"): "rId1"})
    slide_ids = ET.SubElement(pres, qname(P, "sldIdLst"))
    for index in range(len(SLIDES)):
        ET.SubElement(slide_ids, qname(P, "sldId"), {"id": str(256 + index), qname(R, "id"): f"rId{index + 2}"})
    ET.SubElement(pres, qname(P, "sldSz"), {"cx": "12192000", "cy": "6858000", "type": "wide"})
    ET.SubElement(pres, qname(P, "notesSz"), {"cx": "6858000", "cy": "9144000"})

    master = ET.Element(qname(P, "sldMaster"))
    master_csld = ET.SubElement(master, qname(P, "cSld"))
    master_tree = ET.SubElement(master_csld, qname(P, "spTree"))
    master_nv = ET.SubElement(master_tree, qname(P, "nvGrpSpPr"))
    ET.SubElement(master_nv, qname(P, "cNvPr"), {"id": "1", "name": ""})
    ET.SubElement(master_nv, qname(P, "cNvGrpSpPr"))
    ET.SubElement(master_nv, qname(P, "nvPr"))
    master_grp = ET.SubElement(master_tree, qname(P, "grpSpPr"))
    master_xfrm = ET.SubElement(master_grp, qname(A, "xfrm"))
    for tag in ("off", "ext", "chOff", "chExt"):
        ET.SubElement(master_xfrm, qname(A, tag), {"x": "0", "y": "0"} if tag in ("off", "chOff") else {"cx": "0", "cy": "0"})
    ET.SubElement(master, qname(P, "clrMap"), {"bg1": "lt1", "tx1": "dk1", "bg2": "lt2", "tx2": "dk2", "accent1": "accent1", "accent2": "accent2", "accent3": "accent3", "accent4": "accent4", "accent5": "accent5", "accent6": "accent6", "hlink": "hlink", "folHlink": "folHlink"})
    layout_ids = ET.SubElement(master, qname(P, "sldLayoutIdLst"))
    ET.SubElement(layout_ids, qname(P, "sldLayoutId"), {"id": "1", qname(R, "id"): "rId1"})
    ET.SubElement(master, qname(P, "txStyles"))

    layout = ET.Element(qname(P, "sldLayout"), {"type": "blank", "preserve": "1"})
    layout_csld = ET.SubElement(layout, qname(P, "cSld"))
    layout_tree = ET.SubElement(layout_csld, qname(P, "spTree"))
    layout_nv = ET.SubElement(layout_tree, qname(P, "nvGrpSpPr"))
    ET.SubElement(layout_nv, qname(P, "cNvPr"), {"id": "1", "name": ""})
    ET.SubElement(layout_nv, qname(P, "cNvGrpSpPr"))
    ET.SubElement(layout_nv, qname(P, "nvPr"))
    layout_grp = ET.SubElement(layout_tree, qname(P, "grpSpPr"))
    layout_xfrm = ET.SubElement(layout_grp, qname(A, "xfrm"))
    for tag in ("off", "ext", "chOff", "chExt"):
        ET.SubElement(layout_xfrm, qname(A, tag), {"x": "0", "y": "0"} if tag in ("off", "chOff") else {"cx": "0", "cy": "0"})
    layout_color_map = ET.SubElement(layout, qname(P, "clrMapOvr"))
    ET.SubElement(layout_color_map, qname(A, "masterClrMapping"))

    theme = f'''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<a:theme xmlns:a="{A}" name="Rate Limiter"><a:themeElements><a:clrScheme name="Rate Limiter"><a:dk1><a:srgbClr val="07111F"/></a:dk1><a:lt1><a:srgbClr val="F2F6FC"/></a:lt1><a:dk2><a:srgbClr val="101F33"/></a:dk2><a:lt2><a:srgbClr val="C7D5E6"/></a:lt2><a:accent1><a:srgbClr val="35D0BA"/></a:accent1><a:accent2><a:srgbClr val="1B3958"/></a:accent2><a:accent3><a:srgbClr val="7CE5D6"/></a:accent3><a:accent4><a:srgbClr val="173450"/></a:accent4><a:accent5><a:srgbClr val="8EA4BD"/></a:accent5><a:accent6><a:srgbClr val="C7D5E6"/></a:accent6><a:hlink><a:srgbClr val="35D0BA"/></a:hlink><a:folHlink><a:srgbClr val="7CE5D6"/></a:folHlink></a:clrScheme><a:fontScheme name="Aptos"><a:majorFont><a:latin typeface="Aptos Display"/></a:majorFont><a:minorFont><a:latin typeface="Aptos"/></a:minorFont></a:fontScheme><a:fmtScheme name="Rate Limiter"><a:fillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:fillStyleLst><a:lnStyleLst><a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln></a:lnStyleLst><a:effectStyleLst><a:effectStyle><a:effectLst/></a:effectStyle></a:effectStyleLst><a:bgFillStyleLst><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>'''

    pres_rels = [("rId1", f"{R}/slideMaster", "slideMasters/slideMaster1.xml")]
    pres_rels.extend((f"rId{i + 2}", f"{R}/slide", f"slides/slide{i + 1}.xml") for i in range(len(SLIDES)))
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("[Content_Types].xml", content_types_xml())
        archive.writestr("_rels/.rels", relationship_xml([("rId1", f"{R}/officeDocument", "ppt/presentation.xml")]))
        archive.writestr("ppt/presentation.xml", ET.tostring(pres, encoding="utf-8", xml_declaration=True))
        archive.writestr("ppt/_rels/presentation.xml.rels", relationship_xml(pres_rels))
        archive.writestr("ppt/slideMasters/slideMaster1.xml", ET.tostring(master, encoding="utf-8", xml_declaration=True))
        archive.writestr("ppt/slideMasters/_rels/slideMaster1.xml.rels", relationship_xml([
            ("rId1", f"{R}/slideLayout", "../slideLayouts/slideLayout1.xml"),
            ("rId2", f"{R}/theme", "../theme/theme1.xml"),
        ]))
        archive.writestr("ppt/slideLayouts/slideLayout1.xml", ET.tostring(layout, encoding="utf-8", xml_declaration=True))
        archive.writestr("ppt/slideLayouts/_rels/slideLayout1.xml.rels", relationship_xml([
            ("rId1", f"{R}/slideMaster", "../slideMasters/slideMaster1.xml"),
        ]))
        archive.writestr("ppt/theme/theme1.xml", theme)
        for index, slide in enumerate(SLIDES, start=1):
            archive.writestr(f"ppt/slides/slide{index}.xml", slide_xml(slide))
            archive.writestr(f"ppt/slides/_rels/slide{index}.xml.rels", relationship_xml([
                ("rId1", f"{R}/slideLayout", "../slideLayouts/slideLayout1.xml"),
            ]))


def write_scripts():
    VIDEO_DIR.mkdir(parents=True, exist_ok=True)
    for index, filename in enumerate(SCRIPTS, start=1):
        lines = [f"# Video {index}: {filename}", ""]
        for segment, (heading, caption) in enumerate(VIDEO_SETS[index - 1], start=1):
            lines.extend([f"## {segment} — {heading}", "", caption, ""])
        (VIDEO_DIR / filename.replace(".mp4", ".txt")).write_text("\n".join(lines), encoding="utf-8")


if __name__ == "__main__":
    build_presentation()
    render_videos()
    write_scripts()
    print(f"Created {PRESENTATION_DIR / 'distributed-rate-limiter.pptx'}")
    for filename in SCRIPTS:
        print(f"Created {VIDEO_DIR / filename}")
