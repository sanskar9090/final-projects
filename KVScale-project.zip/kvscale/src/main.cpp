#include <algorithm>
#include <atomic>
#include <cassert>
#include <cerrno>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <iostream>
#include <map>
#include <new>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

#ifdef _WIN32
#include <direct.h>
#include <io.h>
#define KV_MKDIR(path) _mkdir(path)
#define KV_UNLINK(path) _unlink(path)
#else
#include <sys/stat.h>
#include <unistd.h>
#define KV_MKDIR(path) mkdir(path, 0755)
#define KV_UNLINK(path) unlink(path)
#endif

namespace {

class SpinLock {
    std::atomic_flag flag_;
public:
    SpinLock() : flag_(ATOMIC_FLAG_INIT) {}
    void lock() {
        while (flag_.test_and_set(std::memory_order_acquire)) {}
    }
    void unlock() { flag_.clear(std::memory_order_release); }
};

class LockGuard {
    SpinLock& lock_;
public:
    explicit LockGuard(SpinLock& lock) : lock_(lock) { lock_.lock(); }
    ~LockGuard() { lock_.unlock(); }
};

class GlobalPool {
    struct Header {
        std::uint64_t magic;
        std::size_t bucket;
        void* base;
        Header* next;
    };

    static const std::uint64_t kMagic = 0x4b56504f4f4c3031ULL;
    static const std::size_t kBucketCount = 8;
    static const std::size_t kBucketSizes[kBucketCount];

    Header* free_[kBucketCount];
    SpinLock mutex_;

public:
    GlobalPool() : free_() {}

    void* allocate(std::size_t requested) {
        if (requested == 0) requested = 1;
        std::size_t bucket = 0;
        while (bucket < kBucketCount && kBucketSizes[bucket] < requested) ++bucket;
        if (bucket == kBucketCount) {
            Header* h = static_cast<Header*>(std::malloc(sizeof(Header) + requested));
            if (!h) throw std::bad_alloc();
            h->magic = kMagic;
            h->bucket = kBucketCount;
            h->base = h;
            return h + 1;
        }

        LockGuard lock(mutex_);
        if (!free_[bucket]) {
            const std::size_t blockSize = sizeof(Header) + kBucketSizes[bucket];
            const std::size_t count = (64 * 1024) / blockSize;
            char* slab = static_cast<char*>(std::malloc(count * blockSize));
            if (!slab) throw std::bad_alloc();
            for (std::size_t i = 0; i < count; ++i) {
                Header* h = reinterpret_cast<Header*>(slab + i * blockSize);
                h->magic = kMagic;
                h->bucket = bucket;
                h->base = slab;
                h->next = free_[bucket];
                free_[bucket] = h;
            }
        }
        Header* h = free_[bucket];
        free_[bucket] = h->next;
        h->next = 0;
        return h + 1;
    }

    void release(void* ptr) {
        if (!ptr) return;
        Header* h = static_cast<Header*>(ptr) - 1;
        if (h->magic != kMagic) {
            std::free(ptr);
            return;
        }
        if (h->bucket == kBucketCount) {
            std::free(h->base);
            return;
        }
        LockGuard lock(mutex_);
        h->next = free_[h->bucket];
        free_[h->bucket] = h;
    }
};

const std::size_t GlobalPool::kBucketSizes[GlobalPool::kBucketCount] =
    {16, 32, 64, 128, 256, 512, 1024, 2048};

GlobalPool& globalPool() {
    static GlobalPool pool;
    return pool;
}

class Arena {
    struct Chunk {
        Chunk* next;
        std::size_t capacity;
        std::size_t used;
        char data[1];
    };
    Chunk* head_;
    std::size_t nextCapacity_;

public:
    explicit Arena(std::size_t initial = 64 * 1024)
        : head_(0), nextCapacity_(initial) {}
    ~Arena() {
        while (head_) {
            Chunk* next = head_->next;
            std::free(head_);
            head_ = next;
        }
    }

    void* allocate(std::size_t bytes, std::size_t alignment) {
        if (bytes == 0) bytes = 1;
        if (!head_ || head_->used + bytes + alignment > head_->capacity) {
            const std::size_t capacity = std::max(nextCapacity_, bytes + alignment);
            Chunk* chunk = static_cast<Chunk*>(std::malloc(sizeof(Chunk) + capacity));
            if (!chunk) throw std::bad_alloc();
            chunk->next = head_;
            chunk->capacity = capacity;
            chunk->used = 0;
            head_ = chunk;
            if (nextCapacity_ < 1024 * 1024) nextCapacity_ *= 2;
        }
        std::uintptr_t start = reinterpret_cast<std::uintptr_t>(head_->data + head_->used);
        std::uintptr_t aligned = (start + alignment - 1) & ~(static_cast<std::uintptr_t>(alignment) - 1);
        std::size_t offset = static_cast<std::size_t>(aligned - reinterpret_cast<std::uintptr_t>(head_->data));
        head_->used = offset + bytes;
        return reinterpret_cast<void*>(aligned);
    }
};

struct Value {
    std::string bytes;
    bool deleted;
    Value() : deleted(false) {}
    Value(const std::string& v, bool d) : bytes(v), deleted(d) {}
};

class SkipList {
    static const int kMaxHeight = 12;
    struct Node {
        std::string key;
        Value value;
        int height;
        Node** next;
        Node(const std::string& k, const Value& v, int h, Node** links)
            : key(k), value(v), height(h), next(links) {}
    };

    Arena arena_;
    Node* head_;
    int height_;
    std::uint32_t random_;
    std::size_t count_;

    int randomHeight() {
        int h = 1;
        while (h < kMaxHeight && (nextRandom() & 3U) == 0) ++h;
        return h;
    }
    std::uint32_t nextRandom() {
        random_ ^= random_ << 13;
        random_ ^= random_ >> 17;
        random_ ^= random_ << 5;
        return random_;
    }
    Node* makeNode(const std::string& key, const Value& value, int height) {
        Node** links = static_cast<Node**>(arena_.allocate(sizeof(Node*) * height, alignof(Node*)));
        for (int i = 0; i < height; ++i) links[i] = 0;
        void* memory = arena_.allocate(sizeof(Node), alignof(Node));
        return new (memory) Node(key, value, height, links);
    }

public:
    SkipList() : head_(0), height_(1), random_(0x9e3779b9U), count_(0) {
        head_ = makeNode("", Value(), kMaxHeight);
    }
    void put(const std::string& key, const Value& value) {
        Node* update[kMaxHeight];
        Node* current = head_;
        for (int level = height_ - 1; level >= 0; --level) {
            while (current->next[level] && current->next[level]->key < key)
                current = current->next[level];
            update[level] = current;
        }
        current = current->next[0];
        if (current && current->key == key) {
            current->value = value;
            return;
        }
        int nodeHeight = randomHeight();
        if (nodeHeight > height_) {
            for (int i = height_; i < nodeHeight; ++i) update[i] = head_;
            height_ = nodeHeight;
        }
        Node* node = makeNode(key, value, nodeHeight);
        for (int i = 0; i < nodeHeight; ++i) {
            node->next[i] = update[i]->next[i];
            update[i]->next[i] = node;
        }
        ++count_;
    }
    bool get(const std::string& key, Value& out) const {
        Node* current = head_;
        for (int level = height_ - 1; level >= 0; --level)
            while (current->next[level] && current->next[level]->key < key)
                current = current->next[level];
        current = current->next[0];
        if (!current || current->key != key) return false;
        out = current->value;
        return true;
    }
    std::vector<std::pair<std::string, Value> > entries() const {
        std::vector<std::pair<std::string, Value> > result;
        result.reserve(count_);
        for (Node* n = head_->next[0]; n; n = n->next[0])
            result.push_back(std::make_pair(n->key, n->value));
        return result;
    }
    std::size_t size() const { return count_; }
};

bool writeRecord(std::FILE* file, const std::string& key, const Value& value) {
    if (key.size() > 0xffffffffU || value.bytes.size() > 0xffffffffU) return false;
    const std::uint32_t keySize = static_cast<std::uint32_t>(key.size());
    const std::uint32_t valueSize = static_cast<std::uint32_t>(value.bytes.size());
    const std::uint8_t deleted = value.deleted ? 1 : 0;
    return std::fwrite(&keySize, sizeof(keySize), 1, file) == 1 &&
           std::fwrite(&valueSize, sizeof(valueSize), 1, file) == 1 &&
           std::fwrite(&deleted, sizeof(deleted), 1, file) == 1 &&
           std::fwrite(key.data(), 1, key.size(), file) == key.size() &&
           std::fwrite(value.bytes.data(), 1, value.bytes.size(), file) == value.bytes.size();
}

bool readRecord(std::FILE* file, std::string& key, Value& value) {
    std::uint32_t keySize = 0, valueSize = 0;
    std::uint8_t deleted = 0;
    std::size_t got = std::fread(&keySize, sizeof(keySize), 1, file);
    if (got != 1) return false;
    if (std::fread(&valueSize, sizeof(valueSize), 1, file) != 1 ||
        std::fread(&deleted, sizeof(deleted), 1, file) != 1 ||
        keySize > 64 * 1024 * 1024 || valueSize > 64 * 1024 * 1024) return false;
    key.resize(keySize);
    value.bytes.resize(valueSize);
    if (std::fread(&key[0], 1, keySize, file) != keySize ||
        std::fread(&value.bytes[0], 1, valueSize, file) != valueSize) return false;
    value.deleted = deleted != 0;
    return true;
}

class LsmStore {
    std::string directory_;
    std::string walPath_;
    SkipList* memtable_;
    std::vector<std::map<std::string, Value> > tables_;
    std::size_t threshold_;
    std::size_t approximateBytes_;
    SpinLock mutex_;

    std::string tablePath(std::size_t id) const {
        char suffix[40];
        std::snprintf(suffix, sizeof(suffix), "/table-%zu.dat", id);
        return directory_ + suffix;
    }
    void ensureDirectory() {
        if (KV_MKDIR(directory_.c_str()) != 0 && errno != EEXIST)
            throw std::runtime_error("cannot create data directory: " + directory_);
    }
    void loadTable(const std::string& path) {
        std::FILE* file = std::fopen(path.c_str(), "rb");
        if (!file) return;
        std::map<std::string, Value> table;
        std::string key;
        Value value;
        while (readRecord(file, key, value)) table[key] = value;
        std::fclose(file);
        tables_.push_back(table);
    }
    void recover() {
        for (std::size_t i = 0; i < 10000; ++i) {
            std::string path = tablePath(i);
            std::FILE* file = std::fopen(path.c_str(), "rb");
            if (!file) break;
            std::fclose(file);
            loadTable(path);
        }
        std::FILE* wal = std::fopen(walPath_.c_str(), "rb");
        if (!wal) return;
        std::string key;
        Value value;
        while (readRecord(wal, key, value)) {
            memtable_->put(key, value);
            approximateBytes_ += key.size() + value.bytes.size() + 32;
        }
        std::fclose(wal);
    }
    void appendWal(const std::string& key, const Value& value) {
        std::FILE* wal = std::fopen(walPath_.c_str(), "ab");
        if (!wal) throw std::runtime_error("cannot open write-ahead log");
        bool ok = writeRecord(wal, key, value) && std::fflush(wal) == 0;
        std::fclose(wal);
        if (!ok) throw std::runtime_error("failed to persist write-ahead log record");
    }
    void flushLocked() {
        if (memtable_->size() == 0) return;
        std::map<std::string, Value> table;
        std::vector<std::pair<std::string, Value> > entries = memtable_->entries();
        std::FILE* file = std::fopen(tablePath(tables_.size()).c_str(), "wb");
        if (!file) throw std::runtime_error("cannot create sorted table");
        for (std::size_t i = 0; i < entries.size(); ++i) {
            table[entries[i].first] = entries[i].second;
            if (!writeRecord(file, entries[i].first, entries[i].second)) {
                std::fclose(file);
                throw std::runtime_error("failed writing sorted table");
            }
        }
        bool ok = std::fflush(file) == 0;
        std::fclose(file);
        if (!ok) throw std::runtime_error("failed flushing sorted table");
        tables_.push_back(table);
        std::FILE* wal = std::fopen(walPath_.c_str(), "wb");
        if (!wal) throw std::runtime_error("cannot truncate write-ahead log");
        std::fclose(wal);
        delete memtable_;
        memtable_ = new SkipList();
        approximateBytes_ = 0;
    }

public:
    explicit LsmStore(const std::string& directory, std::size_t threshold = 64 * 1024)
        : directory_(directory), walPath_(directory + "/wal.log"), memtable_(new SkipList()),
          threshold_(threshold),
          approximateBytes_(0) {
        ensureDirectory();
        recover();
    }
    ~LsmStore() { delete memtable_; }
    void put(const std::string& key, const std::string& value) {
        LockGuard lock(mutex_);
        Value v(value, false);
        appendWal(key, v);
        memtable_->put(key, v);
        approximateBytes_ += key.size() + value.size() + 32;
        if (approximateBytes_ >= threshold_) flushLocked();
    }
    void erase(const std::string& key) {
        LockGuard lock(mutex_);
        Value v("", true);
        appendWal(key, v);
        memtable_->put(key, v);
        approximateBytes_ += key.size() + 32;
        if (approximateBytes_ >= threshold_) flushLocked();
    }
    bool get(const std::string& key, std::string& result) {
        LockGuard lock(mutex_);
        Value value;
        if (memtable_->get(key, value)) {
            if (value.deleted) return false;
            result = value.bytes;
            return true;
        }
        for (std::vector<std::map<std::string, Value> >::reverse_iterator it = tables_.rbegin();
             it != tables_.rend(); ++it) {
            std::map<std::string, Value>::const_iterator found = it->find(key);
            if (found != it->end()) {
                if (found->second.deleted) return false;
                result = found->second.bytes;
                return true;
            }
        }
        return false;
    }
    void flush() {
        LockGuard lock(mutex_);
        flushLocked();
    }
    void compact() {
        LockGuard lock(mutex_);
        flushLocked();
        if (tables_.size() < 2) return;
        std::map<std::string, Value> merged;
        for (std::vector<std::map<std::string, Value> >::const_iterator it = tables_.begin();
             it != tables_.end(); ++it)
            for (std::map<std::string, Value>::const_iterator entry = it->begin();
                 entry != it->end(); ++entry)
                merged[entry->first] = entry->second;

        std::FILE* file = std::fopen(tablePath(0).c_str(), "wb");
        if (!file) throw std::runtime_error("cannot write compacted table");
        for (std::map<std::string, Value>::const_iterator it = merged.begin(); it != merged.end(); ++it) {
            if (!writeRecord(file, it->first, it->second)) {
                std::fclose(file);
                throw std::runtime_error("failed writing compacted table");
            }
        }
        bool ok = std::fflush(file) == 0;
        std::fclose(file);
        if (!ok) throw std::runtime_error("failed flushing compacted table");
        for (std::size_t i = 1; i < tables_.size(); ++i) KV_UNLINK(tablePath(i).c_str());
        tables_.clear();
        tables_.push_back(merged);
    }
};

struct LogEntry {
    int term;
    std::string command;
    LogEntry(int t, const std::string& c) : term(t), command(c) {}
};

class RaftNode {
public:
    int id;
    int term;
    int votedFor;
    int commitIndex;
    std::vector<LogEntry> log;
    explicit RaftNode(int nodeId = 0)
        : id(nodeId), term(0), votedFor(-1), commitIndex(-1) {}
};

class RaftDemoCluster {
    RaftNode nodes_[3];
    bool links_[3][3];
    int leader_;
    bool upToDate(const RaftNode& candidate, const RaftNode& voter) const {
        if (candidate.log.size() != voter.log.size())
            return candidate.log.size() > voter.log.size();
        if (candidate.log.empty()) return true;
        return candidate.log.back().term >= voter.log.back().term;
    }
public:
    RaftDemoCluster() : nodes_(), leader_(-1) {
        for (int i = 0; i < 3; ++i) {
            nodes_[i] = RaftNode(i);
            for (int j = 0; j < 3; ++j) links_[i][j] = true;
        }
    }
    void elect(int candidate) {
        RaftNode& node = nodes_[candidate];
        int nextTerm = node.term + 1;
        node.term = nextTerm;
        node.votedFor = candidate;
        int votes = 1;
        for (int i = 0; i < 3; ++i) {
            if (i == candidate || !links_[candidate][i] || !links_[i][candidate]) continue;
            RaftNode& voter = nodes_[i];
            if (nextTerm > voter.term && upToDate(node, voter)) {
                voter.term = nextTerm;
                voter.votedFor = candidate;
                votes++;
            }
        }
        if (votes >= 2) leader_ = candidate;
    }
    void partition(int a, int b, bool connected) {
        links_[a][b] = connected;
        links_[b][a] = connected;
    }
    bool propose(const std::string& command) {
        if (leader_ < 0) return false;
        RaftNode& leader = nodes_[leader_];
        LogEntry entry(leader.term, command);
        leader.log.push_back(entry);
        int replicas = 1;
        for (int i = 0; i < 3; ++i) {
            if (i != leader_ && links_[leader_][i] && links_[i][leader_]) {
                nodes_[i].term = leader.term;
                nodes_[i].log.push_back(entry);
                replicas++;
            }
        }
        if (replicas < 2) return false;
        int index = static_cast<int>(leader.log.size()) - 1;
        leader.commitIndex = index;
        for (int i = 0; i < 3; ++i)
            if (i == leader_ || (links_[leader_][i] && links_[i][leader_]))
                nodes_[i].commitIndex = index;
        return true;
    }
    void healAndCatchUp() {
        for (int i = 0; i < 3; ++i)
            for (int j = i + 1; j < 3; ++j)
                links_[i][j] = links_[j][i] = true;
        if (leader_ < 0) return;
        for (int i = 0; i < 3; ++i) {
            if (i == leader_) continue;
            nodes_[i].log = nodes_[leader_].log;
            nodes_[i].commitIndex = nodes_[leader_].commitIndex;
            nodes_[i].term = nodes_[leader_].term;
        }
    }
    int leader() const { return leader_; }
    const RaftNode& node(int i) const { return nodes_[i]; }
};

void runDemo(const std::string& directory) {
    std::cout << "KVScale: LSM storage + allocator + Raft mechanics demo\n";
    {
        LsmStore store(directory, 1024 * 1024);
        store.put("user:42", "Ada Lovelace");
        store.put("session:abc", "active");
        std::string value;
        assert(store.get("user:42", value) && value == "Ada Lovelace");
        store.erase("session:abc");
        assert(!store.get("session:abc", value));
        store.flush();
        store.put("user:42", "Ada");
        store.compact();
        std::cout << "[LSM] PUT user:42, GET -> Ada; DELETE session:abc -> not found\n";
    }
    {
        LsmStore recovered(directory, 1024 * 1024);
        std::string value;
        assert(recovered.get("user:42", value) && value == "Ada");
        assert(!recovered.get("session:abc", value));
        std::cout << "[LSM] Reopen/recovery -> user:42=Ada, deleted key stays absent\n";
    }
    RaftDemoCluster cluster;
    cluster.elect(0);
    std::cout << "[Raft model] node " << cluster.leader() << " elected for term "
              << cluster.node(cluster.leader()).term << " with majority\n";
    cluster.partition(0, 2, false);
    bool committed = cluster.propose("PUT replicated-key=value");
    std::cout << "[Raft model] partition node 2; write "
              << (committed ? "committed by majority (2/3)\n" : "rejected\n");
    cluster.healAndCatchUp();
    std::cout << "[Raft model] heal links; node 2 catches up to commit index "
              << cluster.node(2).commitIndex << "\n";
    std::cout << "Note: Raft is an in-process teaching model, not network replication.\n";
}

} // namespace

void* operator new(std::size_t size) { return globalPool().allocate(size); }
void* operator new[](std::size_t size) { return globalPool().allocate(size); }
void operator delete(void* ptr) noexcept { globalPool().release(ptr); }
void operator delete[](void* ptr) noexcept { globalPool().release(ptr); }
void operator delete(void* ptr, std::size_t) noexcept { globalPool().release(ptr); }
void operator delete[](void* ptr, std::size_t) noexcept { globalPool().release(ptr); }

int main(int argc, char** argv) {
    try {
        std::string directory = argc > 1 ? argv[1] : "kvscale-demo-data";
        runDemo(directory);
    } catch (const std::exception& error) {
        std::cerr << "KVScale error: " << error.what() << "\n";
        return 1;
    }
    return 0;
}
