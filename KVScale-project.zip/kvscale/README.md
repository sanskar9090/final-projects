# KVScale educational prototype

KVScale is a compact C++ key-value-store prototype intended to demonstrate how
some storage-engine and consensus building blocks fit together. It is not a
production database and is not designed for Amazon/Meta/Netflix-scale traffic.

## What is implemented

- A C++14 skip-list memtable backed by a bump arena, with a binary write-ahead
  log, sorted on-disk table files, recovery, and a basic full-table compaction.
- A size-class memory pool used by global `new`/`delete` overloads.
- A small three-node **in-process Raft model** showing leader election,
  majority commit, a simulated partition, and follower catch-up.
- A runnable terminal demo and storage-engine assertions.

The Raft implementation is deliberately a deterministic teaching model. It
does not open peer connections, implement production Raft timers or snapshots,
or provide network partition recovery over the wire. The program does **not**
yet include gRPC, a TCP client protocol, or a Linux `io_uring` event loop.
Those require separate transport, membership, security, persistence, and fault
testing before they can be considered reliable.

The global allocator is included to demonstrate allocation routing and
size-class reuse; replacing the process allocator can affect third-party
libraries and must be carefully benchmarked before production use.

## Build and run

Requires a C++14 compiler. On Linux:

```sh
g++ -std=c++14 -O2 -pthread src/main.cpp -o kvscale
./kvscale
```

On Windows with MinGW:

```powershell
g++ -std=c++14 -O2 -pthread src\main.cpp -o kvscale.exe
.\kvscale.exe
```

With CMake, use the standard configure/build flow:

```sh
cmake -S . -B build
cmake --build build --config Release
```

The demo uses a temporary directory and removes it when it exits. To use a
specific data directory, pass it as the first argument:

```sh
./kvscale ./kvscale-data
```

## Terminal protocol sketch

The storage engine is currently exposed through the C++ API in `src/main.cpp`:
`put(key, value)`, `get(key)`, `erase(key)`, and `compact()`. There is no
network-facing server in this prototype.

## Short videos

The `videos/` directory contains three silent MP4 explainers:

1. `01-project-overview.mp4` — storage flow and project scope.
2. `02-code-operations.mp4` — implemented operations and memory choices.
3. `03-terminal-demo.mp4` — the successful demo transcript and Raft-model output.

## Important limitations

This is an educational starting point, not a claim of high availability or
production readiness. It lacks a network transport, TLS/authentication,
checksums, bounded WAL retention, background compaction, bloom filters,
backpressure, concurrency-safe multi-client serving, operational monitoring,
and crash/fault-injection coverage. Durability guarantees have not been
validated against power loss.
