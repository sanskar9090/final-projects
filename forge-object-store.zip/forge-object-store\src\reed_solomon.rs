use anyhow::{bail, ensure, Result};

pub fn encode(data: &[u8], data_shards: usize, parity_shards: usize) -> Result<Vec<Vec<u8>>> {
    ensure!(data_shards > 0, "data shard count must be positive");
    ensure!(parity_shards > 0, "parity shard count must be positive");
    let total = data_shards
        .checked_add(parity_shards)
        .ok_or_else(|| anyhow::anyhow!("total shard count overflows usize"))?;
    let block_len = data.len().div_ceil(data_shards);
    let mut shards = vec![vec![0; block_len]; total];
    for (index, byte) in data.iter().enumerate() {
        shards[index / block_len][index % block_len] = *byte;
    }

    let matrix = coding_matrix(data_shards, parity_shards)?;
    for output_row in data_shards..total {
        for input_row in 0..data_shards {
            let coefficient = matrix[output_row][input_row];
            for offset in 0..block_len {
                shards[output_row][offset] ^= gf_mul(coefficient, shards[input_row][offset]);
            }
        }
    }
    Ok(shards)
}

pub fn reconstruct(
    shards: &[Option<Vec<u8>>],
    data_shards: usize,
    parity_shards: usize,
) -> Result<Vec<Vec<u8>>> {
    let total = data_shards
        .checked_add(parity_shards)
        .ok_or_else(|| anyhow::anyhow!("total shard count overflows usize"))?;
    ensure!(data_shards > 0 && parity_shards > 0, "invalid shard dimensions");
    ensure!(shards.len() == total, "shard count does not match configuration");

    let available: Vec<usize> = shards
        .iter()
        .enumerate()
        .filter_map(|(index, shard)| shard.as_ref().map(|_| index))
        .take(data_shards)
        .collect();
    if available.len() < data_shards {
        bail!(
            "not enough valid shards: need {data_shards}, found {}",
            available.len()
        );
    }
    let block_len = shards[available[0]].as_ref().expect("selected shard").len();
    ensure!(
        available
            .iter()
            .all(|index| shards[*index].as_ref().expect("selected shard").len() == block_len),
        "available shards have inconsistent lengths"
    );

    let matrix = coding_matrix(data_shards, parity_shards)?;
    let selected_matrix: Vec<Vec<u8>> = available
        .iter()
        .map(|index| matrix[*index].clone())
        .collect();
    let inverse = invert_matrix(selected_matrix)?;
    let mut data = vec![vec![0; block_len]; data_shards];
    for output_row in 0..data_shards {
        for (source_index, shard_index) in available.iter().enumerate() {
            let coefficient = inverse[output_row][source_index];
            let shard = shards[*shard_index].as_ref().expect("selected shard");
            for offset in 0..block_len {
                data[output_row][offset] ^= gf_mul(coefficient, shard[offset]);
            }
        }
    }
    let mut recovered = vec![vec![0; block_len]; total];
    recovered[..data_shards].clone_from_slice(&data);
    for output_row in data_shards..total {
        for input_row in 0..data_shards {
            let coefficient = matrix[output_row][input_row];
            for offset in 0..block_len {
                recovered[output_row][offset] ^=
                    gf_mul(coefficient, recovered[input_row][offset]);
            }
        }
    }
    Ok(recovered)
}

fn coding_matrix(data_shards: usize, parity_shards: usize) -> Result<Vec<Vec<u8>>> {
    let total = data_shards
        .checked_add(parity_shards)
        .ok_or_else(|| anyhow::anyhow!("total shard count overflows usize"))?;
    ensure!(total <= 255, "GF(256) supports at most 255 total shards");
    let vandermonde: Vec<Vec<u8>> = (0..total)
        .map(|row| {
            (0..data_shards)
                .map(|column| gf_pow((row + 1) as u8, column))
                .collect()
        })
        .collect();
    let top_inverse = invert_matrix(vandermonde[..data_shards].to_vec())?;
    Ok(vandermonde
        .iter()
        .map(|row| {
            (0..data_shards)
                .map(|column| {
                    (0..data_shards).fold(0, |sum, index| {
                        sum ^ gf_mul(row[index], top_inverse[index][column])
                    })
                })
                .collect()
        })
        .collect())
}

fn invert_matrix(mut matrix: Vec<Vec<u8>>) -> Result<Vec<Vec<u8>>> {
    let size = matrix.len();
    ensure!(
        size > 0 && matrix.iter().all(|row| row.len() == size),
        "matrix must be non-empty and square"
    );
    let mut inverse = vec![vec![0; size]; size];
    for (index, row) in inverse.iter_mut().enumerate() {
        row[index] = 1;
    }

    for column in 0..size {
        let pivot = (column..size)
            .find(|row| matrix[*row][column] != 0)
            .ok_or_else(|| anyhow::anyhow!("matrix is singular"))?;
        matrix.swap(column, pivot);
        inverse.swap(column, pivot);

        let scale = gf_inv(matrix[column][column])?;
        for index in 0..size {
            matrix[column][index] = gf_mul(matrix[column][index], scale);
            inverse[column][index] = gf_mul(inverse[column][index], scale);
        }
        for row in 0..size {
            if row == column {
                continue;
            }
            let factor = matrix[row][column];
            if factor == 0 {
                continue;
            }
            for index in 0..size {
                matrix[row][index] ^= gf_mul(factor, matrix[column][index]);
                inverse[row][index] ^= gf_mul(factor, inverse[column][index]);
            }
        }
    }
    Ok(inverse)
}

fn gf_mul(mut left: u8, mut right: u8) -> u8 {
    let mut product = 0;
    while right != 0 {
        if right & 1 != 0 {
            product ^= left;
        }
        let carry = left & 0x80;
        left <<= 1;
        if carry != 0 {
            left ^= 0x1d;
        }
        right >>= 1;
    }
    product
}

fn gf_pow(base: u8, exponent: usize) -> u8 {
    (0..exponent).fold(1, |value, _| gf_mul(value, base))
}

fn gf_inv(value: u8) -> Result<u8> {
    ensure!(value != 0, "zero has no multiplicative inverse in GF(256)");
    Ok(gf_pow(value, 254))
}

#[cfg(test)]
mod tests {
    use super::{encode, reconstruct};

    #[test]
    fn recovers_every_pair_of_missing_shards() {
        let original = (0..=255).cycle().take(4097).collect::<Vec<u8>>();
        let encoded = encode(&original, 4, 2).expect("encode");
        for first_missing in 0..6 {
            for second_missing in (first_missing + 1)..6 {
                let mut partial: Vec<Option<Vec<u8>>> =
                    encoded.iter().cloned().map(Some).collect();
                partial[first_missing] = None;
                partial[second_missing] = None;
                let recovered = reconstruct(&partial, 4, 2).expect("recover");
                let mut decoded = recovered[..4].concat();
                decoded.truncate(original.len());
                assert_eq!(decoded, original);
            }
        }
    }

    #[test]
    fn rejects_more_missing_shards_than_parity_budget() {
        let encoded = encode(b"recovery test", 4, 2).expect("encode");
        let partial = encoded
            .into_iter()
            .enumerate()
            .map(|(index, shard)| (index < 3).then_some(shard))
            .collect::<Vec<_>>();
        assert!(reconstruct(&partial, 4, 2).is_err());
    }
}
