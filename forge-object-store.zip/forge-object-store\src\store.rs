use std::{
    collections::HashMap,
    path::{Path, PathBuf},
};

use anyhow::{bail, ensure, Context, Result};
use bytes::Bytes;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use tokio::{fs, io::AsyncWriteExt, sync::RwLock};
use uuid::Uuid;

use crate::reed_solomon;

pub const PART_SIZE: usize = 4 * 1024 * 1024;

#[derive(Clone, Serialize, Deserialize)]
pub struct ChunkManifest {
    original_len: usize,
    shard_len: usize,
    hashes: Vec<String>,
}

#[derive(Clone, Serialize, Deserialize)]
pub struct Manifest {
    pub id: String,
    pub key: String,
    pub size_bytes: u64,
    pub chunks: Vec<ChunkManifest>,
}

#[derive(Clone)]
pub struct UploadState {
    id: String,
    key: String,
    directory: PathBuf,
}

#[derive(Serialize, Deserialize)]
struct UploadRecord {
    id: String,
    key: String,
}

impl UploadState {
    pub fn id(&self) -> &str {
        &self.id
    }
}

pub struct ObjectStore {
    root: PathBuf,
    nodes: usize,
    data_shards: usize,
    parity_shards: usize,
    manifests: RwLock<HashMap<String, Manifest>>,
}

impl ObjectStore {
    pub async fn open(
        root: PathBuf,
        nodes: usize,
        data_shards: usize,
        parity_shards: usize,
    ) -> Result<Self> {
        for node in 0..nodes {
            fs::create_dir_all(root.join("nodes").join(format!("node-{node:03}"))).await?;
        }
        let metadata_dir = root.join("metadata");
        let uploads_dir = root.join("uploads");
        fs::create_dir_all(&metadata_dir).await?;
        fs::create_dir_all(&uploads_dir).await?;

        let mut manifests = HashMap::new();
        let mut entries = fs::read_dir(&metadata_dir).await?;
        while let Some(entry) = entries.next_entry().await? {
            if entry.path().extension().and_then(|ext| ext.to_str()) != Some("json") {
                continue;
            }
            let raw = fs::read(entry.path()).await.context("read object metadata")?;
            let manifest: Manifest =
                serde_json::from_slice(&raw).context("parse object metadata")?;
            manifests.insert(manifest.key.clone(), manifest);
        }
        Ok(Self {
            root,
            nodes,
            data_shards,
            parity_shards,
            manifests: RwLock::new(manifests),
        })
    }

    pub fn node_count(&self) -> usize {
        self.nodes
    }

    pub fn data_shards(&self) -> usize {
        self.data_shards
    }

    pub fn parity_shards(&self) -> usize {
        self.parity_shards
    }

    pub fn part_size_bytes(&self) -> usize {
        PART_SIZE
    }

    pub async fn begin_upload(&self, id: String, key: String) -> Result<UploadState> {
        let directory = self.root.join("uploads").join(&id);
        fs::create_dir_all(&directory).await?;
        let record = serde_json::to_vec(&UploadRecord {
            id: id.clone(),
            key: key.clone(),
        })?;
        write_atomically(&directory.join("upload.json"), &record).await?;
        Ok(UploadState { id, key, directory })
    }

    pub async fn load_uploads(&self) -> Result<Vec<UploadState>> {
        let mut uploads = Vec::new();
        let mut entries = fs::read_dir(self.root.join("uploads")).await?;
        while let Some(entry) = entries.next_entry().await? {
            if !entry.file_type().await?.is_dir() {
                continue;
            }
            let directory = entry.path();
            let record_path = directory.join("upload.json");
            let raw = match fs::read(&record_path).await {
                Ok(raw) => raw,
                Err(error) if error.kind() == std::io::ErrorKind::NotFound => continue,
                Err(error) => return Err(error.into()),
            };
            let record: UploadRecord = serde_json::from_slice(&raw)
                .with_context(|| format!("parse upload record {}", record_path.display()))?;
            ensure!(
                directory.file_name().and_then(|name| name.to_str())
                    == Some(record.id.as_str()),
                "upload record ID does not match its directory"
            );
            uploads.push(UploadState {
                id: record.id,
                key: record.key,
                directory,
            });
        }
        Ok(uploads)
    }

    pub async fn uploaded_parts(&self, upload: &UploadState) -> Result<Vec<u32>> {
        let mut parts = Vec::new();
        let mut entries = fs::read_dir(&upload.directory).await?;
        while let Some(entry) = entries.next_entry().await? {
            let Some(name) = entry.file_name().to_str().map(str::to_owned) else {
                continue;
            };
            if let Some(number) = name
                .strip_suffix(".part")
                .and_then(|value| value.parse::<u32>().ok())
            {
                parts.push(number);
            }
        }
        parts.sort_unstable();
        Ok(parts)
    }

    pub async fn write_part(
        &self,
        upload: &UploadState,
        part_number: u32,
        bytes: Bytes,
    ) -> Result<()> {
        let path = upload.directory.join(format!("{part_number:010}.part"));
        let temporary = upload.directory.join(format!("{part_number:010}.tmp"));
        let mut file = fs::File::create(&temporary).await?;
        file.write_all(&bytes).await?;
        file.sync_all().await?;
        fs::rename(temporary, path).await?;
        Ok(())
    }

    pub async fn complete_upload(&self, upload: &UploadState) -> Result<Manifest> {
        let part_numbers = self.uploaded_parts(upload).await?;
        ensure!(!part_numbers.is_empty(), "upload has no parts");
        ensure!(
            part_numbers.iter().copied().eq(1..=(part_numbers.len() as u32)),
            "upload parts must be contiguous starting at 1"
        );
        let mut size_bytes = 0_u64;
        let mut chunks = Vec::with_capacity(part_numbers.len());
        let id = Uuid::new_v4().to_string();
        for (chunk_index, part_number) in part_numbers.iter().enumerate() {
            let data = fs::read(upload.directory.join(format!("{part_number:010}.part")))
                .await
                .context("read upload part")?;
            ensure!(!data.is_empty(), "upload part {part_number} is empty");
            ensure!(
                data.len() <= PART_SIZE,
                "upload part {part_number} exceeds part-size limit"
            );
            size_bytes += data.len() as u64;
            let encoded = reed_solomon::encode(&data, self.data_shards, self.parity_shards)?;
            let mut hashes = Vec::with_capacity(encoded.len());
            for (shard_index, shard) in encoded.iter().enumerate() {
                let node = (chunk_index * encoded.len() + shard_index) % self.nodes;
                let node_dir = self
                    .root
                    .join("nodes")
                    .join(format!("node-{node:03}"))
                    .join(format!("object-{id}"));
                fs::create_dir_all(&node_dir).await?;
                let shard_path = self.shard_path(&id, chunk_index, shard_index);
                write_atomically(&shard_path, shard).await?;
                hashes.push(hash_hex(shard));
            }
            chunks.push(ChunkManifest {
                original_len: data.len(),
                shard_len: encoded[0].len(),
                hashes,
            });
        }
        let manifest = Manifest {
            id,
            key: upload.key.clone(),
            size_bytes,
            chunks,
        };
        let metadata_path = self.metadata_path(&manifest.id);
        let serialized = serde_json::to_vec_pretty(&manifest)?;
        write_atomically(&metadata_path, &serialized).await?;

        let old = self
            .manifests
            .write()
            .await
            .insert(manifest.key.clone(), manifest.clone());
        if let Some(old) = old {
            self.remove_shards(&old).await?;
            let _ = fs::remove_file(self.metadata_path(&old.id)).await;
        }
        fs::remove_dir_all(&upload.directory).await?;
        Ok(manifest)
    }

    pub async fn get_manifest(&self, key: &str) -> Option<Manifest> {
        self.manifests
            .read()
            .await
            .get(key)
            .cloned()
    }

    pub async fn read_chunk(&self, manifest: &Manifest, chunk_index: usize) -> Result<Vec<u8>> {
        let chunk = manifest
            .chunks
            .get(chunk_index)
            .context("chunk index is outside object manifest")?;
        let mut shards = Vec::with_capacity(self.data_shards + self.parity_shards);
        for shard_index in 0..self.data_shards + self.parity_shards {
            let path = self.shard_path(&manifest.id, chunk_index, shard_index);
            let valid = match fs::read(path).await {
                Ok(bytes)
                    if bytes.len() == chunk.shard_len
                        && hash_hex(&bytes) == chunk.hashes[shard_index] =>
                {
                    Some(bytes)
                }
                _ => None,
            };
            shards.push(valid);
        }
        let recovered =
            reed_solomon::reconstruct(&shards, self.data_shards, self.parity_shards)?;
        let data = recovered[..self.data_shards].concat();
        ensure!(
            chunk.original_len <= data.len(),
            "manifest chunk length exceeds recovered data"
        );
        Ok(data[..chunk.original_len].to_vec())
    }

    pub async fn scrub_once(&self) -> Result<()> {
        let manifests: Vec<Manifest> = self.manifests.read().await.values().cloned().collect();
        for manifest in manifests {
            for (chunk_index, chunk) in manifest.chunks.iter().enumerate() {
                let mut shards = Vec::with_capacity(self.data_shards + self.parity_shards);
                for shard_index in 0..self.data_shards + self.parity_shards {
                    let path = self.shard_path(&manifest.id, chunk_index, shard_index);
                    let valid = match fs::read(&path).await {
                        Ok(bytes)
                            if bytes.len() == chunk.shard_len
                                && hash_hex(&bytes) == chunk.hashes[shard_index] =>
                        {
                            Some(bytes)
                        }
                        _ => None,
                    };
                    shards.push(valid);
                }
                let recovered =
                    reed_solomon::reconstruct(&shards, self.data_shards, self.parity_shards)
                        .with_context(|| {
                            format!(
                                "cannot repair object {} chunk {}",
                                manifest.key, chunk_index
                            )
                        })?;
                for (shard_index, (existing, bytes)) in
                    shards.iter().zip(recovered.iter()).enumerate()
                {
                    if existing.is_none() {
                        write_atomically(
                            &self.shard_path(&manifest.id, chunk_index, shard_index),
                            bytes,
                        )
                        .await?;
                    }
                }
            }
        }
        Ok(())
    }

    pub async fn delete_object(&self, key: &str) -> Result<bool> {
        let Some(manifest) = self.manifests.write().await.remove(key) else {
            return Ok(false);
        };
        self.remove_shards(&manifest).await?;
        fs::remove_file(self.metadata_path(&manifest.id)).await?;
        Ok(true)
    }

    async fn remove_shards(&self, manifest: &Manifest) -> Result<()> {
        for chunk_index in 0..manifest.chunks.len() {
            for shard_index in 0..self.data_shards + self.parity_shards {
                match fs::remove_file(self.shard_path(&manifest.id, chunk_index, shard_index)).await {
                    Ok(()) => {}
                    Err(error) if error.kind() == std::io::ErrorKind::NotFound => {}
                    Err(error) => return Err(error.into()),
                }
            }
        }
        Ok(())
    }

    fn metadata_path(&self, id: &str) -> PathBuf {
        self.root.join("metadata").join(format!("{id}.json"))
    }

    fn shard_path(&self, id: &str, chunk_index: usize, shard_index: usize) -> PathBuf {
        let node = (chunk_index * (self.data_shards + self.parity_shards) + shard_index)
            % self.nodes;
        self.root
            .join("nodes")
            .join(format!("node-{node:03}"))
            .join(format!("object-{id}"))
            .join(format!("chunk-{chunk_index:08}-shard-{shard_index:03}.bin"))
    }
}

async fn write_atomically(path: &Path, bytes: &[u8]) -> Result<()> {
    let temporary = path.with_extension(format!("tmp-{}", Uuid::new_v4()));
    let mut file = fs::File::create(&temporary).await?;
    file.write_all(bytes).await?;
    file.sync_all().await?;
    fs::rename(&temporary, path).await?;
    Ok(())
}

fn hash_hex(bytes: &[u8]) -> String {
    hex::encode(Sha256::digest(bytes))
}
