# Forge Object Store

Forge is an educational, self-hosted object-storage reference service in Rust. It accepts resumable multipart uploads, splits each part into data shards, calculates Reed–Solomon parity in GF(2^8), distributes shards across storage-node directories, and reconstructs objects as they are downloaded. SHA-256 checks detect missing or corrupted shards; a periodic scrub repairs a shard when enough good shards remain.

## Important scope note

This is a **single-process reference implementation**, not a production MinIO replacement. Its six "nodes" are directories on one machine, so this demonstrates placement and failure recovery but does not provide independent hosts, a consensus-backed metadata plane, authentication, TLS, quotas, or production S3 compatibility. The client-facing protocol is HTTP; authenticated gRPC transport between independent storage-node processes is a planned production extension, not implemented in this milestone. Do not expose it to untrusted networks or store irreplaceable data in it. Production work should add those controls, a replicated metadata service, authenticated node RPC, secure deployment, and fault-injection testing.

## Architecture

```text
upload client -> multipart HTTP API -> 4 data + 2 parity shards
                                         |   |   |   |   |   |
                                      node0 node1 node2 node3 node4 node5
                                         |
                      manifest + per-shard SHA-256 checksums
                                         |
GET object <- verify available shards <- reconstruct with GF(256) matrix inverse
background scrub -> detect missing/corrupt shard -> reconstruct and rewrite
```

Each uploaded part is one coding unit (4 MiB maximum by default). Data is padded across four equal-sized data shards. Two parity shards permit reconstruction after any two shard losses in a chunk. Each shard is assigned to a node directory; placement rotates by chunk. Metadata and shard writes use temporary files followed by rename. Upload part writes are idempotent: sending the same part number again replaces that part.

## Run locally

Requirements: a recent stable Rust toolchain and Python 3.9+ for the retryable sample client. The sample client's advertised 4 MiB part size is currently fixed to the service default.

```powershell
cargo test
cargo run --release -- --root .\data --listen 127.0.0.1:9000
```

Or with Docker Compose:

```powershell
docker compose up --build
```

Health check: `GET http://127.0.0.1:9000/health`

## Upload, resume, download

The client asks the service for an upload ID, checks which part numbers are already present, retries transient network errors with exponential backoff, and sends any missing parts. Upload records and part files persist across service restarts. Preserve the printed upload ID and resume with `--upload-id`:

```powershell
python .\scripts\upload.py .\movie.bin backups/movie.bin
python .\scripts\upload.py .\movie.bin backups/movie.bin --upload-id <previous-upload-id>
curl.exe -o .\downloaded.bin http://127.0.0.1:9000/v1/objects/backups%2Fmovie.bin
```

Endpoints:

| Method | Path | Description |
|---|---|---|
| `GET` | `/health` | Service and shard configuration |
| `POST` | `/v1/uploads` | JSON `{"key":"object-key"}`; returns `upload_id` and maximum part size |
| `GET` | `/v1/uploads/{upload_id}` | List successfully persisted part numbers |
| `PUT` | `/v1/uploads/{upload_id}/parts/{part_number}` | Persist or replace a non-empty binary part |
| `POST` | `/v1/uploads/{upload_id}/complete` | Encode shards and commit object metadata |
| `GET` | `/v1/objects/{key}` | Stream a verified, reconstructed object |
| `DELETE` | `/v1/objects/{key}` | Remove object metadata and shards |

Keys are passed as one URL path segment; URL-encode reserved characters (including `/`) in a client. Downloads yield decoded chunks as the server reads and verifies them.

## Failure and integrity behavior

The RS coding matrix is built by transforming a Vandermonde matrix into systematic form. Recovery chooses any `k` available checksum-valid shards, inverts their coding submatrix over GF(256), and recreates all shards. The unit tests cover all two-shard loss pairs for a 4+2 layout and failure beyond the parity budget. `scrub_once` scans every chunk and repairs missing or hash-mismatched shards; the HTTP service schedules it periodically.

Try a local recovery experiment while the service is stopped: remove or alter one `.bin` shard under `data\nodes\node-*\object-*`, restart, wait for one scrub interval, and inspect the repaired shard. For immediate verification, adjust `FORGE_SCRUB_SECONDS` to a small value.

## Operations

- Keep the data root on persistent storage and back it up.
- Monitor process logs for scrub errors; a chunk with fewer than four valid shards cannot be repaired.
- Set `FORGE_NODES >= FORGE_DATA_SHARDS + FORGE_PARITY_SHARDS`.
- For real distributed deployment, replace directory placement with authenticated gRPC node clients and health-aware placement; run each storage node on independent failure domains.
- Never treat a successful HTTP response as a substitute for backups or a tested recovery plan.

## Demo walkthrough videos

The three downloadable MP4s accompany the source ZIP:

1. Project motivation and what is being built.
2. Operations, Rust/Linux concepts, and implementation stack.
3. Live local demo flow: start service, upload, inspect health, download, and test recovery.
