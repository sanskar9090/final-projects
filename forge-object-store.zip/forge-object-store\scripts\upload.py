#!/usr/bin/env python3
"""Retryable client for Forge Object Store's multipart HTTP API."""

import argparse
import json
import os
import time
import urllib.error
import urllib.request


def request(url, method="GET", body=None, content_type="application/json"):
    req = urllib.request.Request(
        url,
        data=body,
        method=method,
        headers={"Content-Type": content_type} if body is not None else {},
    )
    with urllib.request.urlopen(req, timeout=60) as response:
        return response.read()


def retry(operation, attempts=5):
    for attempt in range(attempts):
        try:
            return operation()
        except (OSError, urllib.error.URLError):
            if attempt + 1 == attempts:
                raise
            time.sleep(min(2**attempt, 8))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("file")
    parser.add_argument("key")
    parser.add_argument("--endpoint", default="http://127.0.0.1:9000")
    parser.add_argument("--upload-id", help="resume a previously started upload")
    args = parser.parse_args()
    endpoint = args.endpoint.rstrip("/")
    file_size = os.path.getsize(args.file)

    with open(args.file, "rb") as source:
        first = source.read(1)
        source.seek(0)
        if not first:
            raise SystemExit("empty files are not supported")
        if args.upload_id:
            upload_id = args.upload_id
            status = json.loads(request(f"{endpoint}/v1/uploads/{upload_id}"))
            if status["upload_id"] != upload_id:
                raise SystemExit("server returned a different upload ID")
            part_size = 4 * 1024 * 1024
        else:
            init = json.loads(
                request(
                    f"{endpoint}/v1/uploads",
                    "POST",
                    json.dumps({"key": args.key}).encode(),
                )
            )
            upload_id = init["upload_id"]
            part_size = init["part_size_bytes"]
            print(f"Upload ID: {upload_id} (reuse with --upload-id if interrupted)")
            status = json.loads(request(f"{endpoint}/v1/uploads/{upload_id}"))
        uploaded = set(status["uploaded_parts"])

        part_number = 1
        sent = 0
        while True:
            data = source.read(part_size)
            if not data:
                break
            sent += len(data)
            if part_number not in uploaded:
                url = f"{endpoint}/v1/uploads/{upload_id}/parts/{part_number}"
                retry(lambda: request(url, "PUT", data, "application/octet-stream"))
            print(f"\rUploaded/resumed {min(sent, file_size)} / {file_size} bytes", end="")
            part_number += 1
    result = json.loads(
        retry(lambda: request(f"{endpoint}/v1/uploads/{upload_id}/complete", "POST", b""))
    )
    print(f"\nStored {result['key']} ({result['size_bytes']} bytes, {result['chunks']} chunks)")


if __name__ == "__main__":
    main()
