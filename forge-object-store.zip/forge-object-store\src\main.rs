mod reed_solomon;
mod store;

use std::{net::SocketAddr, path::PathBuf, sync::Arc, time::Duration};

use axum::{
    body::Body,
    extract::{DefaultBodyLimit, Path, State},
    http::{header, HeaderMap, StatusCode},
    response::{IntoResponse, Response},
    routing::{get, post, put},
    Json, Router,
};
use bytes::Bytes;
use clap::Parser;
use anyhow::Context;
use serde::{Deserialize, Serialize};
use tokio::{net::TcpListener, sync::RwLock};
use tracing::{error, info, warn};
use uuid::Uuid;

use crate::store::{Manifest, ObjectStore, UploadState, PART_SIZE};

#[derive(Parser, Debug)]
#[command(version, about)]
struct Args {
    #[arg(long, env = "FORGE_ROOT", default_value = "./data")]
    root: PathBuf,
    #[arg(long, env = "FORGE_LISTEN", default_value = "127.0.0.1:9000")]
    listen: SocketAddr,
    #[arg(long, env = "FORGE_NODES", default_value_t = 6)]
    nodes: usize,
    #[arg(long, env = "FORGE_DATA_SHARDS", default_value_t = 4)]
    data_shards: usize,
    #[arg(long, env = "FORGE_PARITY_SHARDS", default_value_t = 2)]
    parity_shards: usize,
    #[arg(long, env = "FORGE_SCRUB_SECONDS", default_value_t = 60)]
    scrub_seconds: u64,
}

#[derive(Clone)]
struct AppState {
    store: Arc<ObjectStore>,
    uploads: Arc<RwLock<std::collections::HashMap<String, UploadState>>>,
}

#[derive(Deserialize)]
struct BeginUpload {
    key: String,
}

#[derive(Serialize)]
struct BeginUploadResponse {
    upload_id: String,
    part_size_bytes: usize,
}

#[derive(Serialize)]
struct UploadStatus {
    upload_id: String,
    uploaded_parts: Vec<u32>,
}

#[derive(Serialize)]
struct CompleteResponse {
    key: String,
    size_bytes: u64,
    chunks: usize,
    data_shards: usize,
    parity_shards: usize,
}

#[derive(Serialize)]
struct Health {
    status: &'static str,
    storage_nodes: usize,
    data_shards: usize,
    parity_shards: usize,
}

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::try_from_default_env()
                .unwrap_or_else(|_| "forge_object_store=info,tower_http=info".into()),
        )
        .init();

    let args = Args::parse();
    anyhow::ensure!(args.data_shards > 0, "data_shards must be greater than zero");
    anyhow::ensure!(args.parity_shards > 0, "parity_shards must be greater than zero");
    let total_shards = args
        .data_shards
        .checked_add(args.parity_shards)
        .context("total shard count overflows usize")?;
    anyhow::ensure!(total_shards <= 255, "GF(256) supports at most 255 total shards");
    anyhow::ensure!(
        args.nodes >= total_shards,
        "nodes must be at least data_shards + parity_shards"
    );
    anyhow::ensure!(args.scrub_seconds > 0, "scrub_seconds must be greater than zero");

    let store = Arc::new(
        ObjectStore::open(
            args.root,
            args.nodes,
            args.data_shards,
            args.parity_shards,
        )
        .await?,
    );
    let uploads = store
        .load_uploads()
        .await?
        .into_iter()
        .map(|upload| (upload.id().to_owned(), upload))
        .collect();
    let state = AppState {
        store: Arc::clone(&store),
        uploads: Arc::new(RwLock::new(uploads)),
    };

    let scrub_store = Arc::clone(&store);
    let scrub_interval = Duration::from_secs(args.scrub_seconds);
    tokio::spawn(async move {
        loop {
            tokio::time::sleep(scrub_interval).await;
            if let Err(err) = scrub_store.scrub_once().await {
                error!(error = %err, "background integrity scrub failed");
            }
        }
    });

    let app = Router::new()
        .route("/health", get(health))
        .route("/v1/uploads", post(begin_upload))
        .route("/v1/uploads/:upload_id", get(upload_status))
        .route(
            "/v1/uploads/:upload_id/parts/:part_number",
            put(put_part),
        )
        .route("/v1/uploads/:upload_id/complete", post(complete_upload))
        .route("/v1/objects/:key", get(get_object).delete(delete_object))
        .layer(DefaultBodyLimit::max(PART_SIZE))
        .with_state(state);

    let listener = TcpListener::bind(args.listen).await?;
    info!(
        address = %listener.local_addr()?,
        nodes = args.nodes,
        data_shards = args.data_shards,
        parity_shards = args.parity_shards,
        "Forge Object Store listening"
    );
    axum::serve(listener, app).await?;
    Ok(())
}

async fn health(State(state): State<AppState>) -> Json<Health> {
    Json(Health {
        status: "ok",
        storage_nodes: state.store.node_count(),
        data_shards: state.store.data_shards(),
        parity_shards: state.store.parity_shards(),
    })
}

async fn begin_upload(
    State(state): State<AppState>,
    Json(request): Json<BeginUpload>,
) -> Result<Json<BeginUploadResponse>, ApiError> {
    if request.key.trim().is_empty() || request.key.len() > 1024 {
        return Err(ApiError::bad_request(
            "key must contain 1 to 1024 non-whitespace bytes",
        ));
    }
    let upload_id = Uuid::new_v4().to_string();
    let upload = state.store.begin_upload(upload_id.clone(), request.key).await?;
    state.uploads.write().await.insert(upload_id.clone(), upload);
    Ok(Json(BeginUploadResponse {
        upload_id,
        part_size_bytes: state.store.part_size_bytes(),
    }))
}

async fn upload_status(
    State(state): State<AppState>,
    Path(upload_id): Path<String>,
) -> Result<Json<UploadStatus>, ApiError> {
    let uploads = state.uploads.read().await;
    let upload = uploads
        .get(&upload_id)
        .ok_or_else(|| ApiError::not_found("upload not found"))?;
    Ok(Json(UploadStatus {
        upload_id,
        uploaded_parts: state.store.uploaded_parts(upload).await?,
    }))
}

async fn put_part(
    State(state): State<AppState>,
    Path((upload_id, part_number)): Path<(String, u32)>,
    body: Bytes,
) -> Result<StatusCode, ApiError> {
    if part_number == 0 {
        return Err(ApiError::bad_request("part numbers start at 1"));
    }
    if body.is_empty() || body.len() > state.store.part_size_bytes() {
        return Err(ApiError::bad_request(
            "part must be non-empty and no larger than the advertised part size",
        ));
    }
    let uploads = state.uploads.read().await;
    let upload = uploads
        .get(&upload_id)
        .ok_or_else(|| ApiError::not_found("upload not found"))?;
    state.store.write_part(upload, part_number, body).await?;
    Ok(StatusCode::NO_CONTENT)
}

async fn complete_upload(
    State(state): State<AppState>,
    Path(upload_id): Path<String>,
) -> Result<Json<CompleteResponse>, ApiError> {
    let upload = state
        .uploads
        .write()
        .await
        .remove(&upload_id)
        .ok_or_else(|| ApiError::not_found("upload not found"))?;
    match state.store.complete_upload(&upload).await {
        Ok(manifest) => Ok(Json(CompleteResponse {
            key: manifest.key,
            size_bytes: manifest.size_bytes,
            chunks: manifest.chunks.len(),
            data_shards: state.store.data_shards(),
            parity_shards: state.store.parity_shards(),
        })),
        Err(err) => {
            state.uploads.write().await.insert(upload_id, upload);
            Err(err.into())
        }
    }
}

async fn get_object(
    State(state): State<AppState>,
    Path(key): Path<String>,
) -> Result<Response, ApiError> {
    let manifest = state
        .store
        .get_manifest(&key)
        .await
        .ok_or_else(|| ApiError::not_found("object not found"))?;
    let store = Arc::clone(&state.store);
    let body_stream = async_stream::try_stream! {
        for chunk_index in 0..manifest.chunks.len() {
            let chunk = store.read_chunk(&manifest, chunk_index).await
                .map_err(ApiError::from)?;
            yield Bytes::from(chunk);
        }
    };
    let mut headers = HeaderMap::new();
    headers.insert(
        header::CONTENT_LENGTH,
        manifest
            .size_bytes
            .to_string()
            .parse()
            .map_err(|error| ApiError::from(anyhow::anyhow!("invalid content length: {error}")))?,
    );
    headers.insert(
        header::CONTENT_TYPE,
        "application/octet-stream".parse().expect("static header is valid"),
    );
    Ok((headers, Body::from_stream(body_stream)).into_response())
}

async fn delete_object(
    State(state): State<AppState>,
    Path(key): Path<String>,
) -> Result<StatusCode, ApiError> {
    if !state.store.delete_object(&key).await? {
        return Err(ApiError::not_found("object not found"));
    }
    Ok(StatusCode::NO_CONTENT)
}

#[derive(Debug)]
struct ApiError {
    status: StatusCode,
    message: String,
}

impl ApiError {
    fn bad_request(message: impl Into<String>) -> Self {
        Self {
            status: StatusCode::BAD_REQUEST,
            message: message.into(),
        }
    }

    fn not_found(message: impl Into<String>) -> Self {
        Self {
            status: StatusCode::NOT_FOUND,
            message: message.into(),
        }
    }
}

impl From<anyhow::Error> for ApiError {
    fn from(error: anyhow::Error) -> Self {
        warn!(error = %error, "request failed");
        Self {
            status: StatusCode::INTERNAL_SERVER_ERROR,
            message: error.to_string(),
        }
    }
}

impl IntoResponse for ApiError {
    fn into_response(self) -> Response {
        (self.status, Json(serde_json::json!({ "error": self.message }))).into_response()
    }

    impl std::fmt::Display for ApiError {
        fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            formatter.write_str(&self.message)
        }
    }

    impl std::error::Error for ApiError {}
}
