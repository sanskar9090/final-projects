# FX Pulse

A local-first forex and digital-asset trading simulator. It combines a browser dashboard, independently deployed Node.js services, a Python ARIMA forecast API, and an ERC-20 escrow swap contract.

> This is an educational demo, not a brokerage, exchange, wallet custodian, or investment tool. Never use real funds or production credentials with the included in-memory services.

## Run locally

Requirements: Docker Desktop with Compose enabled.

```powershell
Copy-Item .env.example .env
# Change JWT_SECRET in .env before exposing the app beyond your machine.
docker compose up --build
```

Open [http://localhost:8080](http://localhost:8080) and choose **Enter demo account**. The simulator starts with USD 10,000 in virtual funds. Quotes stream to the page over WebSockets. With no provider key, every quote is simulated. To request provider data, add a Twelve Data API key as `TWELVEDATA_API_KEY` in `.env` and restart the rates service; provider plans and symbol entitlements apply. The service subscribes to the watchlist configured in `services/rates/server.js`.

The services also expose health checks at ports 3001 (auth), 3002 (rates), 3003 (wallet), and 8000 (forecast). In Compose, browser API traffic is proxied through port 8080.

## What is included

- **Auth service**: email/password registration, bcrypt password hashing, and signed 12-hour JWTs.
- **Rates service**: WebSocket quote broadcasts for forex, equities, and crypto; generated demo quotes by default, optional Twelve Data WebSocket source.
- **Wallet service**: JWT-protected virtual balances, fixed indicative conversion rates, and the latest 50 conversion records.
- **Forecast service**: FastAPI endpoint using statsmodels ARIMA(1,1,0). `POST /api/forecast` accepts `{ "pair": "EUR/USD", "history": [1.08, ...], "steps": 8 }`. If history is omitted it forecasts deterministic synthetic demo history. Estimates are experimental, not financial advice.
- **Swap contract**: `contracts/CurrencySwapEscrow.sol` escrows ERC-20 sell tokens, lets a taker fill before expiry, and allows the maker to cancel and reclaim the deposit.
- **Deployment**: Docker Compose for local use and Kubernetes manifests in `k8s/app.yaml`.

## Service map

| Component | Port | Responsibility |
| --- | ---: | --- |
| Web dashboard | 8080 | Static UI and same-origin API/WebSocket proxy |
| Auth | 3001 | Account registration and login |
| Rates | 3002 | Quote REST snapshot and `/ws` stream |
| Wallet | 3003 | Virtual conversion and history |
| Forecast | 8000 | ARIMA forecast endpoint |

## Kubernetes

Build the five images from their respective `services/<name>` directories and make them available to your cluster (push to a registry or load them into a local cluster). Create secrets before applying the manifest:

```powershell
kubectl create secret generic fx-pulse-secrets --from-literal=JWT_SECRET='replace-with-a-long-random-secret'
# Optional: enables provider quotes where supported by your account.
kubectl create secret generic fx-pulse-market-data --from-literal=TWELVEDATA_API_KEY='your-key'
kubectl apply -f k8s/app.yaml
```

The dashboard NodePort is `30080`. The manifests intentionally use one replica per service because users, balances, and quote state are held in process memory. For a real deployment, add persistent databases, shared session/token controls, secret management, rate limiting, TLS/Ingress, resource limits, and a durable message bus before scaling.

## Contract

Compile with Solidity `^0.8.24` and deploy to a test network using Remix or your preferred toolchain. The maker must approve `sellToken` before calling `createOrder`; a taker must approve `buyToken` before `fillOrder`. The contract does not bridge assets, verify off-chain exchange rates, or guarantee token compatibility. Test with audited mock ERC-20 tokens on a test network first. This repository does not include an audited production deployment.

## Limitations

- Auth accounts, wallets, and history are in-memory; restarting a service resets them.
- Default quotes are synthetic. The configured provider is optional and requires a key and supported market-data subscription.
- Forex conversion ticket rates are fixed demo values and are not sourced from the quote stream.
- The forecast is a small baseline model over synthetic or caller-supplied history, not a validated trading signal.
- The Solidity contract is a learning example, not audited. It only swaps ERC-20 tokens on one chain.
