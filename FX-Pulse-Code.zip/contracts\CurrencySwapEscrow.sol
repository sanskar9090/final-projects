// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

interface IERC20 {
    function transfer(address recipient, uint256 amount) external returns (bool);
    function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
}

contract CurrencySwapEscrow {
    struct Order {
        address maker;
        IERC20 sellToken;
        IERC20 buyToken;
        uint256 sellAmount;
        uint256 buyAmount;
        uint256 deadline;
        bool open;
    }

    uint256 public nextOrderId = 1;
    uint256 private lockState = 1;
    mapping(uint256 => Order) public orders;

    event OrderCreated(uint256 indexed orderId, address indexed maker, address sellToken, address buyToken, uint256 sellAmount, uint256 buyAmount, uint256 deadline);
    event OrderFilled(uint256 indexed orderId, address indexed taker);
    event OrderCancelled(uint256 indexed orderId);

    modifier nonReentrant() {
        require(lockState == 1, "REENTRANCY");
        lockState = 2;
        _;
        lockState = 1;
    }

    function createOrder(IERC20 sellToken, IERC20 buyToken, uint256 sellAmount, uint256 buyAmount, uint256 deadline) external nonReentrant returns (uint256 orderId) {
        require(address(sellToken) != address(0) && address(buyToken) != address(0), "INVALID_TOKEN");
        require(address(sellToken) != address(buyToken), "SAME_TOKEN");
        require(sellAmount > 0 && buyAmount > 0, "ZERO_AMOUNT");
        require(deadline > block.timestamp, "EXPIRED");
        require(sellToken.transferFrom(msg.sender, address(this), sellAmount), "DEPOSIT_FAILED");

        orderId = nextOrderId++;
        orders[orderId] = Order(msg.sender, sellToken, buyToken, sellAmount, buyAmount, deadline, true);
        emit OrderCreated(orderId, msg.sender, address(sellToken), address(buyToken), sellAmount, buyAmount, deadline);
    }

    function fillOrder(uint256 orderId) external nonReentrant {
        Order storage order = orders[orderId];
        require(order.open, "ORDER_CLOSED");
        require(block.timestamp <= order.deadline, "EXPIRED");
        order.open = false;
        require(order.buyToken.transferFrom(msg.sender, order.maker, order.buyAmount), "PAYMENT_FAILED");
        require(order.sellToken.transfer(msg.sender, order.sellAmount), "PAYOUT_FAILED");
        emit OrderFilled(orderId, msg.sender);
    }

    function cancelOrder(uint256 orderId) external nonReentrant {
        Order storage order = orders[orderId];
        require(order.open, "ORDER_CLOSED");
        require(msg.sender == order.maker, "NOT_MAKER");
        order.open = false;
        require(order.sellToken.transfer(order.maker, order.sellAmount), "REFUND_FAILED");
        emit OrderCancelled(orderId);
    }
}
