const express = require('express');
const path = require('path');
const { createProxyMiddleware } = require('http-proxy-middleware');
const app = express();
const port = Number(process.env.PORT || 8080);
app.use('/api/auth', createProxyMiddleware({ target: process.env.AUTH_URL || 'http://auth:3001', changeOrigin: true, pathRewrite: (requestPath) => `/api/auth${requestPath}` }));
app.use('/api/wallet', createProxyMiddleware({ target: process.env.WALLET_URL || 'http://wallet:3003', changeOrigin: true, pathRewrite: (requestPath) => `/api/wallet${requestPath}` }));
app.use('/api/forecast', createProxyMiddleware({ target: process.env.FORECAST_URL || 'http://forecast:8000', changeOrigin: true, pathRewrite: (requestPath) => `/api/forecast${requestPath}` }));
app.use('/api/quotes', createProxyMiddleware({ target: process.env.RATES_URL || 'http://rates:3002', changeOrigin: true, pathRewrite: (requestPath) => `/api/quotes${requestPath}` }));
app.use(express.static(path.join(__dirname, 'public')));
app.get('/health', (_req, res) => res.json({ service: 'web', status: 'ok' }));
const server = app.listen(port, '0.0.0.0', () => console.log(`FX Pulse web listening on ${port}`));
const ratesWebSocket = createProxyMiddleware({ target: process.env.RATES_URL || 'http://rates:3002', changeOrigin: true, ws: true });
server.on('upgrade', (request, socket, head) => {
	if (request.url === '/ws') ratesWebSocket.upgrade(request, socket, head);
	else socket.destroy();
});
