const API = { auth: location.origin, rates: location.origin, wallet: location.origin, forecast: location.origin };
const assets = [
  { symbol: 'EUR/USD', name: 'Euro / US Dollar', type: 'forex', icon: '€', digits: 4 },
  { symbol: 'GBP/USD', name: 'British Pound / US Dollar', type: 'forex', icon: '£', digits: 4 },
  { symbol: 'USD/JPY', name: 'US Dollar / Japanese Yen', type: 'forex', icon: '¥', digits: 2 },
  { symbol: 'AUD/USD', name: 'Australian Dollar / US Dollar', type: 'forex', icon: 'A', digits: 4 },
  { symbol: 'BTC/USD', name: 'Bitcoin', type: 'crypto', icon: '₿', digits: 2 },
  { symbol: 'ETH/USD', name: 'Ethereum', type: 'crypto', icon: 'Ξ', digits: 2 },
  { symbol: 'SOL/USD', name: 'Solana', type: 'crypto', icon: 'S', digits: 2 },
  { symbol: 'AAPL', name: 'Apple Inc.', type: 'stock', icon: 'A', digits: 2 },
  { symbol: 'NVDA', name: 'NVIDIA Corp.', type: 'stock', icon: 'N', digits: 2 },
  { symbol: 'TSLA', name: 'Tesla Inc.', type: 'stock', icon: 'T', digits: 2 }
];
const $ = (selector) => document.querySelector(selector);
let token = localStorage.getItem('fxpulse.token');
let user = JSON.parse(localStorage.getItem('fxpulse.user') || 'null');
let latestQuotes = {};
let isRegistering = false;
const dialog = $('#auth-dialog');

function api(path, options = {}) {
  return fetch(path, { ...options, headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(options.headers || {}) } });
}
function money(value, currency = 'USD') {
  try { return new Intl.NumberFormat('en-US', { style: 'currency', currency, maximumFractionDigits: 2 }).format(value); }
  catch { return `${currency} ${Number(value).toFixed(2)}`; }
}
function rateFormat(asset, price) { return Number(price).toLocaleString('en-US', { minimumFractionDigits: asset.digits, maximumFractionDigits: asset.digits }); }
function setAuth(nextToken, nextUser) {
  token = nextToken; user = nextUser;
  if (token) { localStorage.setItem('fxpulse.token', token); localStorage.setItem('fxpulse.user', JSON.stringify(user)); }
  else { localStorage.removeItem('fxpulse.token'); localStorage.removeItem('fxpulse.user'); }
  updateAuthUI();
  loadWallet();
}
function updateAuthUI() {
  $('#user-email').textContent = user?.email || 'Guest session';
  $('#auth-button').innerHTML = token ? 'Sign out <span aria-hidden="true">↗</span>' : 'Sign in <span aria-hidden="true">↗</span>';
  $('#wallet-state').textContent = token ? 'ACCOUNT CONNECTED' : 'SIGN IN TO SYNC';
  $('#trade-submit').innerHTML = token ? 'Convert virtually <span>↗</span>' : 'Sign in to trade <span>↗</span>';
  $('#history-rows').innerHTML = token ? '<tr><td colspan="5" class="loading-row">Loading account activity</td></tr>' : '<tr><td colspan="5" class="empty-row">Sign in to view your activity.</td></tr>';
}
function renderMarkets(quotes) {
  latestQuotes = quotes || {};
  const filter = document.querySelector('.filter-button.active')?.dataset.filter || 'all';
  const visible = assets.filter((asset) => filter === 'all' || asset.type === filter);
  $('#market-rows').innerHTML = visible.map((asset) => {
    const quote = latestQuotes[asset.symbol] || { price: 0, change24h: 0 };
    const change = Number(quote.change24h || 0);
    const points = Array.from({ length: 7 }, (_, i) => 13 + Math.sin(i * 1.6 + change) * 5 + i * (change >= 0 ? -0.6 : 0.65));
    const path = points.map((point, i) => `${i ? 'L' : 'M'}${i * 10},${point.toFixed(1)}`).join(' ');
    const label = asset.type === 'forex' ? 'FOREX' : asset.type.toUpperCase();
    return `<tr><td><div class="asset-cell"><span class="asset-icon">${asset.icon}</span><span><span class="asset-name">${asset.symbol}</span><span class="asset-sub">${asset.name} · ${label}</span></span></div></td><td class="price-cell">${rateFormat(asset, quote.price || 0)}</td><td class="${change >= 0 ? 'change-up' : 'change-down'}">${change >= 0 ? '+' : ''}${change.toFixed(2)}%</td><td class="chart-head"><svg class="sparkline ${change < 0 ? 'down' : ''}" viewBox="0 0 62 26" aria-hidden="true"><path d="${path}"/></svg></td><td><button class="trade-link" data-symbol="${asset.symbol}">Trade</button></td></tr>`;
  }).join('');
  document.querySelectorAll('.trade-link').forEach((button) => button.addEventListener('click', () => {
    if (!token) { dialog.showModal(); return; }
    const symbol = button.dataset.symbol;
    if (symbol.includes('/')) {
      const [from, to] = symbol.split('/');
      if ($('#from-currency').querySelector(`option[value="${from}"]`) || [...$('#from-currency').options].some((option) => option.value === from)) $('#from-currency').value = from;
      if ([...$('#to-currency').options].some((option) => option.value === to)) $('#to-currency').value = to;
      updateEstimate();
      $('#trade-form').scrollIntoView({ behavior: 'smooth', block: 'center' });
    } else { $('#forecast-pair').value = 'EUR/USD'; loadForecast(); }
  }));
  updateEstimate();
}
function connectRates() {
  const socket = new WebSocket(`${location.protocol === 'https:' ? 'wss:' : 'ws:'}//${location.host}/ws`);
  socket.onopen = () => { $('#feed-state').textContent = 'STREAMING'; $('#feed-state').classList.add('connected'); };
  socket.onmessage = (event) => { try { renderMarkets(JSON.parse(event.data).quotes); } catch {} };
  socket.onclose = () => { $('#feed-state').textContent = 'RECONNECTING'; $('#feed-state').classList.remove('connected'); setTimeout(connectRates, 1800); };
  socket.onerror = () => socket.close();
}
async function loadWallet() {
  if (!token) { $('#total-balance').textContent = '$10,000.00'; $('#balance-foot').textContent = 'USD 10,000.00'; return; }
  try {
    const response = await api(`${API.wallet}/api/wallet`);
    if (response.status === 401) return setAuth(null, null);
    const wallet = await response.json();
    const balances = wallet.balances || {};
    const total = Object.entries(balances).reduce((sum, [currency, amount]) => sum + Number(amount) * ({ USD: 1, EUR: 1.0842, GBP: 1.2716, JPY: 1 / 149.32, AUD: 0.6541 }[currency] || 0), 0);
    $('#total-balance').textContent = money(total);
    $('#balance-foot').textContent = `USD ${Number(balances.USD || 0).toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
    const history = wallet.history || [];
    $('#history-rows').innerHTML = history.length ? history.slice(0, 5).map((item) => `<tr><td><strong>${item.from} → ${item.to}</strong></td><td>${money(item.amount, item.from)}</td><td>${money(item.received, item.to)}</td><td class="mono">${item.rate}</td><td>${new Date(item.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</td></tr>`).join('') : '<tr><td colspan="5" class="empty-row">No conversions yet. Your first practice trade is one click away.</td></tr>';
  } catch { $('#history-rows').innerHTML = '<tr><td colspan="5" class="empty-row">Wallet service is not available.</td></tr>'; }
}
function conversionRate(from, to) {
  const usd = { USD: 1, EUR: 1.0842, GBP: 1.2716, JPY: 1 / 149.32, AUD: 0.6541 };
  return (usd[from] || 1) / (usd[to] || 1);
}
function updateEstimate() {
  const from = $('#from-currency').value, to = $('#to-currency').value;
  const amount = Number($('#amount').value || 0), rate = conversionRate(from, to);
  $('#received-amount').textContent = `${({ USD: '$', EUR: '€', GBP: '£', JPY: '¥', AUD: 'A$' })[to]} ${(amount * rate).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
  $('#exchange-rate').textContent = `1 ${from} = ${rate.toFixed(4)} ${to}`;
}
async function loadForecast() {
  const pair = $('#forecast-pair').value;
  try {
    const response = await fetch(`${API.forecast}/api/forecast`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ pair, steps: 8 }) });
    if (!response.ok) throw new Error('Forecast unavailable');
    const data = await response.json();
    const last = data.points[data.points.length - 1];
    $('#model-direction').textContent = data.direction === 'up' ? '↑ Bullish' : '↓ Bearish';
    $('#model-direction').style.color = data.direction === 'up' ? 'var(--green)' : 'var(--red)';
    $('#forecast-arrow').textContent = data.direction === 'up' ? '↗' : '↘';
    $('#forecast-arrow').classList.toggle('down', data.direction === 'down');
    $('#forecast-value').textContent = `${data.direction === 'up' ? 'Upward' : 'Downward'} bias`;
    $('#forecast-detail').textContent = `${pair} · ${data.model} · 8 steps`;
    $('#model-caption').textContent = `${data.model} · ${pair} · 8 steps`;
    drawForecast(data.points, data.direction);
    if (!last) throw new Error('Empty forecast');
  } catch {
    $('#forecast-value').textContent = 'Forecast unavailable';
    $('#model-direction').textContent = '--';
    $('#forecast-detail').textContent = 'Start the Python forecast service';
  }
}
function drawLine(canvas, values, color, fill = false) {
  const context = canvas.getContext('2d'), width = canvas.clientWidth, height = canvas.clientHeight, ratio = window.devicePixelRatio || 1;
  canvas.width = width * ratio; canvas.height = height * ratio; context.scale(ratio, ratio);
  const min = Math.min(...values), max = Math.max(...values), spread = max - min || 1;
  context.beginPath();
  values.forEach((value, index) => {
    const x = values.length < 2 ? 0 : index * width / (values.length - 1);
    const y = height - 3 - ((value - min) / spread) * (height - 9);
    if (index === 0) context.moveTo(x, y); else context.lineTo(x, y);
  });
  context.strokeStyle = color; context.lineWidth = 2; context.stroke();
  if (fill) { context.lineTo(width, height); context.lineTo(0, height); context.closePath(); context.fillStyle = 'rgba(70,137,94,.08)'; context.fill(); }
}
function drawForecast(points, direction) { drawLine($('#forecast-chart'), points.map((point) => point.value), direction === 'up' ? '#448461' : '#bd7168'); }
function drawPortfolio() { drawLine($('#portfolio-chart'), [37, 38, 36, 40, 39, 44, 42, 45, 47, 45, 51, 54, 52, 57, 56, 62, 64, 62, 68], '#5a956e', true); }

$('#auth-button').addEventListener('click', () => token ? setAuth(null, null) : dialog.showModal());
$('#mode-toggle').addEventListener('click', () => {
  isRegistering = !isRegistering;
  $('#auth-title').textContent = isRegistering ? 'Create your account' : 'Sign in to FX Pulse';
  $('#auth-submit').innerHTML = `${isRegistering ? 'Create account' : 'Sign in'} <span>↗</span>`;
  $('#mode-toggle').textContent = isRegistering ? 'Already registered? Sign in' : 'New here? Create an account';
});
$('#auth-form').addEventListener('submit', async (event) => {
  event.preventDefault(); $('#auth-error').textContent = '';
  const endpoint = isRegistering ? 'register' : 'login';
  try {
    const response = await fetch(`${API.auth}/api/auth/${endpoint}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email: $('#email').value, password: $('#password').value }) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Could not sign in.');
    setAuth(data.token, data.user); dialog.close();
  } catch (error) { $('#auth-error').textContent = error.message; }
});
$('#demo-login').addEventListener('click', async () => {
  $('#auth-error').textContent = '';
  const credentials = { email: 'demo@fxpulse.test', password: 'demo-pass-123' };
  try {
    let response = await fetch(`${API.auth}/api/auth/login`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(credentials) });
    if (response.status === 401) {
      response = await fetch(`${API.auth}/api/auth/register`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(credentials) });
    }
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Demo account unavailable.');
    setAuth(data.token, data.user); dialog.close();
  } catch (error) { $('#auth-error').textContent = error.message; }
});
$('#trade-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  if (!token) return dialog.showModal();
  const submit = $('#trade-submit'); submit.disabled = true; submit.textContent = 'Processing…';
  try {
    const response = await api(`${API.wallet}/api/wallet/convert`, { method: 'POST', body: JSON.stringify({ from: $('#from-currency').value, to: $('#to-currency').value, amount: Number($('#amount').value) }) });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Conversion failed.');
    await loadWallet(); submit.innerHTML = 'Converted successfully <span>✓</span>';
    setTimeout(() => { submit.innerHTML = 'Convert virtually <span>↗</span>'; submit.disabled = false; }, 1600);
  } catch (error) { window.alert(error.message); submit.disabled = false; submit.innerHTML = 'Convert virtually <span>↗</span>'; }
});
$('#swap-currencies').addEventListener('click', () => { const from = $('#from-currency'), to = $('#to-currency'), old = from.value; from.value = to.value; to.value = old; updateEstimate(); });
$('#amount').addEventListener('input', updateEstimate);
$('#from-currency').addEventListener('change', updateEstimate);
$('#to-currency').addEventListener('change', updateEstimate);
$('#forecast-pair').addEventListener('change', loadForecast);
document.querySelectorAll('.filter-button').forEach((button) => button.addEventListener('click', () => {
  document.querySelectorAll('.filter-button').forEach((item) => item.classList.toggle('active', item === button));
  renderMarkets(latestQuotes);
}));
window.addEventListener('resize', () => { drawPortfolio(); loadForecast(); });
updateAuthUI(); updateEstimate(); drawPortfolio(); connectRates(); loadWallet(); loadForecast();
