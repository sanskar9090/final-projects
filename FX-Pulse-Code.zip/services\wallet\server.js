const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const app = express();
const port = Number(process.env.PORT || 3003);
const secret = process.env.JWT_SECRET || 'local-demo-secret-change-before-deploy';
const wallets = new Map();
const usdValue = { USD: 1, EUR: 1.0842, GBP: 1.2716, JPY: 1 / 149.32, AUD: 0.6541 };
app.use(cors());
app.use(express.json());
app.get('/health', (_req, res) => res.json({ service: 'wallet', status: 'ok' }));
app.use('/api/wallet', (req, res, next) => {
  try {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const claims = jwt.verify(token, secret);
    req.userId = claims.sub;
    next();
  } catch (_error) {
    res.status(401).json({ error: 'Sign in to access your virtual wallet.' });
  }
});
app.get('/api/wallet', (req, res) => res.json(getWallet(req.userId)));
app.post('/api/wallet/convert', (req, res) => {
  const from = String(req.body.from || '').toUpperCase();
  const to = String(req.body.to || '').toUpperCase();
  const amount = Number(req.body.amount);
  if (!(from in usdValue) || !(to in usdValue) || from === to || !Number.isFinite(amount) || amount <= 0) {
    return res.status(400).json({ error: 'Choose two different supported currencies and enter a positive amount.' });
  }
  const wallet = getWallet(req.userId);
  if ((wallet.balances[from] || 0) < amount) return res.status(400).json({ error: `Insufficient ${from} balance.` });
  const rate = usdValue[from] / usdValue[to];
  const received = amount * rate;
  wallet.balances[from] = round((wallet.balances[from] || 0) - amount);
  wallet.balances[to] = round((wallet.balances[to] || 0) + received);
  const transaction = { id: crypto.randomUUID(), from, to, amount: round(amount), received: round(received), rate: Number(rate.toFixed(6)), createdAt: new Date().toISOString() };
  wallet.history.unshift(transaction);
  wallet.history = wallet.history.slice(0, 50);
  res.json({ ...wallet, transaction });
});
function getWallet(userId) {
  if (!wallets.has(userId)) wallets.set(userId, { balances: { USD: 10000, EUR: 0, GBP: 0, JPY: 0, AUD: 0 }, history: [] });
  return wallets.get(userId);
}
function round(value) { return Math.round((value + Number.EPSILON) * 100) / 100; }
app.listen(port, '0.0.0.0', () => console.log(`Wallet service listening on ${port}`));
