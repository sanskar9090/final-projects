const express = require('express');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const crypto = require('crypto');

const app = express();
const port = Number(process.env.PORT || 3001);
const secret = process.env.JWT_SECRET || 'local-demo-secret-change-before-deploy';
const users = new Map();
app.use(cors());
app.use(express.json());

app.get('/health', (_req, res) => res.json({ service: 'auth', status: 'ok' }));
app.post('/api/auth/register', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  if (!/^\S+@\S+\.\S+$/.test(email) || password.length < 8) {
    return res.status(400).json({ error: 'Use a valid email and a password of at least 8 characters.' });
  }
  if ([...users.values()].some((user) => user.email === email)) {
    return res.status(409).json({ error: 'An account with that email already exists.' });
  }
  const user = { id: crypto.randomUUID(), email, passwordHash: await bcrypt.hash(password, 10) };
  users.set(user.id, user);
  return res.status(201).json(issueToken(user));
});
app.post('/api/auth/login', async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const user = [...users.values()].find((candidate) => candidate.email === email);
  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ error: 'Email or password is incorrect.' });
  }
  return res.json(issueToken(user));
});
function issueToken(user) {
  return { token: jwt.sign({ sub: user.id, email: user.email }, secret, { expiresIn: '12h' }), user: { id: user.id, email: user.email } };
}
app.listen(port, '0.0.0.0', () => console.log(`Auth service listening on ${port}`));
