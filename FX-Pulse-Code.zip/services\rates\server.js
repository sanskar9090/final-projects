const express = require('express');
const cors = require('cors');
const WebSocket = require('ws');

const app = express();
const port = Number(process.env.PORT || 3002);
app.use(cors());
const quotes = new Map(Object.entries({
  'EUR/USD': { price: 1.0842, type: 'forex', source: 'simulated' },
  'GBP/USD': { price: 1.2716, type: 'forex', source: 'simulated' },
  'USD/JPY': { price: 149.32, type: 'forex', source: 'simulated' },
  'AUD/USD': { price: 0.6541, type: 'forex', source: 'simulated' },
  'BTC/USD': { price: 67420.50, type: 'crypto', source: 'simulated' },
  'ETH/USD': { price: 3512.80, type: 'crypto', source: 'simulated' },
  'SOL/USD': { price: 178.24, type: 'crypto', source: 'simulated' },
  'AAPL': { price: 227.52, type: 'stock', source: 'simulated' },
  'NVDA': { price: 138.85, type: 'stock', source: 'simulated' },
  'TSLA': { price: 251.44, type: 'stock', source: 'simulated' }
}));
const changes = new Map([...quotes.keys()].map((symbol) => [symbol, (Math.random() - 0.48) * 0.9]));
function snapshot() {
  return { type: 'snapshot', at: new Date().toISOString(), quotes: Object.fromEntries(quotes) };
}
app.get('/health', (_req, res) => res.json({ service: 'rates', status: 'ok', stream: 'ws://localhost:3002/ws' }));
app.get('/api/quotes', (_req, res) => res.json(snapshot()));
const server = app.listen(port, '0.0.0.0', () => console.log(`Rates service listening on ${port}`));
const wss = new WebSocket.Server({ noServer: true });
const providerSymbols = [...quotes.keys()].join(',');
let providerSocket;
function connectProvider() {
  if (!process.env.TWELVEDATA_API_KEY) return;
  providerSocket = new WebSocket(`wss://ws.twelvedata.com/v1/quotes/price?apikey=${encodeURIComponent(process.env.TWELVEDATA_API_KEY)}`);
  providerSocket.on('open', () => providerSocket.send(JSON.stringify({ action: 'subscribe', params: { symbols: providerSymbols } })));
  providerSocket.on('message', (raw) => {
    try {
      const update = JSON.parse(raw.toString());
      const symbol = String(update.symbol || '').toUpperCase();
      const quote = quotes.get(symbol);
      const price = Number(update.price);
      if (update.event !== 'price' || !quote || !Number.isFinite(price) || price <= 0) return;
      if (!quote.providerOpen) quote.providerOpen = price;
      quote.price = price;
      quote.change24h = Number((((price - quote.providerOpen) / quote.providerOpen) * 100).toFixed(2));
      quote.source = 'Twelve Data live';
    } catch (_error) {}
  });
  providerSocket.on('close', () => setTimeout(connectProvider, 5000));
  providerSocket.on('error', () => providerSocket.close());
}
connectProvider();
server.on('upgrade', (request, socket, head) => {
  if (request.url !== '/ws') return socket.destroy();
  wss.handleUpgrade(request, socket, head, (websocket) => wss.emit('connection', websocket, request));
});
wss.on('connection', (socket) => {
  socket.send(JSON.stringify(snapshot()));
  socket.on('error', () => {});
});
setInterval(() => {
  for (const [symbol, quote] of quotes) {
    if (quote.source === 'Twelve Data live') continue;
    const movement = changes.get(symbol) * (quote.type === 'crypto' ? 0.0007 : 0.00022);
    quote.price = Math.max(0.0001, quote.price * (1 + movement));
    quote.change24h = Number(((quote.change24h || 0) + movement * 100).toFixed(2));
  }
  const message = JSON.stringify({ type: 'tick', at: new Date().toISOString(), quotes: Object.fromEntries(quotes) });
  for (const socket of wss.clients) if (socket.readyState === WebSocket.OPEN) socket.send(message);
}, 2000);
