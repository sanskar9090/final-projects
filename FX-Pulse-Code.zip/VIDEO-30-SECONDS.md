# FX Pulse: 30-second walkthrough

Use a 1920x1080 or 1280x720 screen recording, 30 fps. Start with the app already running at `http://localhost:8080`; use the demo account. No real trading or external data is shown unless configured.

| Time | On-screen action | Voiceover |
| --- | --- | --- |
| 0:00-0:04 | Open the dashboard; hold on the portfolio and market status. | “This is FX Pulse, a virtual trading simulator built from independent services.” |
| 0:04-0:09 | Show streaming watchlist, switch Forex to Crypto, point to changing quote values. | “Market quotes update over WebSockets. Demo mode uses generated prices; a provider key can enable eligible live feeds.” |
| 0:09-0:15 | Sign in using Enter demo account. Show the wallet balance. | “Authentication issues a signed token, and the wallet tracks practice funds without real assets.” |
| 0:15-0:21 | Convert 250 USD to EUR and submit; show updated activity history. | “A conversion updates balances and records the transaction in the wallet service.” |
| 0:21-0:26 | Show the ARIMA trend estimate and its disclaimer. | “A separate Python API fits an ARIMA baseline to historical input and returns an experimental estimate.” |
| 0:26-0:30 | Briefly show the service map or contract file, then end on the dashboard. | “Docker Compose runs the services locally; an ERC-20 escrow contract demonstrates peer-to-peer swaps.” |

Suggested end card: “FX Pulse · Educational simulator · No real funds”.
