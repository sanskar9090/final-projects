import numpy as np
from PIL import Image, ImageDraw, ImageFont
import imageio

out = "C:/Users/rawat/Documents/FX-Pulse/FX-Pulse-demo-30s.mp4"
W, H = 1280, 720
fps = 30
frames_total = 30 * fps

font_title = ImageFont.load_default()
font_body = ImageFont.load_default()
font_small = ImageFont.load_default()


def make_frame(t):
    img = Image.new("RGB", (W, H), (9, 17, 32))
    d = ImageDraw.Draw(img)

    for y in range(H):
        ratio = y / max(1, H - 1)
        r = int(15 + 20 * ratio)
        g = int(28 + 25 * ratio)
        b = int(52 + 30 * ratio)
        d.line((0, y, W, y), fill=(r, g, b))

    d.text((60, 48), "FX Pulse", fill=(255, 255, 255), font=font_title)
    d.text((60, 112), "Virtual Forex Trading Simulator", fill=(153, 200, 255), font=font_body)

    panels = [
        (60, 170, 540, 300, "AUTH / LOGIN", (37, 99, 235)),
        (600, 170, 1210, 300, "LIVE MARKET FEED", (0, 163, 108)),
        (60, 330, 540, 560, "WALLET + HISTORY", (234, 111, 0)),
        (600, 330, 1210, 560, "AI FORECAST + SWAP", (114, 75, 170)),
    ]

    for x1, y1, x2, y2, label, color in panels:
        d.rounded_rectangle((x1, y1, x2, y2), radius=18, fill=(18, 28, 46), outline=color, width=2)
        d.text((x1 + 22, y1 + 15), label, fill=color, font=font_body)

    d.text((90, 225), "demo@fxpulse.local", fill=(255, 255, 255), font=font_body)
    d.text((90, 255), "JWT issued: 12h", fill=(178, 215, 255), font=font_body)
    d.text((90, 285), "Wallet balance: $10,000", fill=(159, 255, 191), font=font_body)

    symbols = ["EUR/USD", "USD/JPY", "BTC/USD", "ETH/USD"]
    values = [1.0826, 157.32, 61642.28, 3334.17]
    for i, sym in enumerate(symbols):
        y = 215 + i * 32
        val = values[i] * (1 + 0.002 * np.sin(t * 0.8 + i))
        if sym in ["EUR/USD", "USD/JPY"]:
            label = f"{sym}  {val:,.4f}"
        else:
            label = f"{sym}  {val:,.2f}"
        d.text((630, y), label, fill=(220, 255, 230), font=font_body)

    amount = 250 + 40 * np.sin(t * 0.9)
    d.text((90, 385), "Convert 250 USD -> EUR", fill=(255, 255, 255), font=font_body)
    d.text((90, 420), "Confirmation: EUR conversion", fill=(255, 209, 102), font=font_body)
    d.text((90, 455), "Status: successful", fill=(144, 255, 173), font=font_body)
    d.text((90, 495), "History: 12 recent trades", fill=(230, 230, 230), font=font_body)

    forecast = 1.0849 + 0.003 * np.sin(t * 0.7)
    d.text((630, 385), "ARIMA forecast", fill=(255, 255, 255), font=font_body)
    d.text((630, 420), f"EUR/USD next 8 steps: {forecast:.4f}", fill=(216, 192, 255), font=font_body)
    d.text((630, 455), "Trend: slight bullish bias", fill=(216, 192, 255), font=font_body)
    d.text((630, 495), "Swap contract: escrow enabled", fill=(200, 220, 255), font=font_body)
    d.text((630, 530), "Maker approves token | Taker fills order", fill=(200, 220, 255), font=font_small)

    d.rounded_rectangle((60, 610, 1210, 685), radius=18, fill=(0, 0, 0), outline=(86, 152, 255), width=2)
    d.text(
        (90, 635),
        "Operations shown: authentication, WebSocket market updates, virtual wallet conversion, ARIMA forecasting, and smart-contract swap flow.",
        fill=(255, 255, 255),
        font=font_small,
    )

    return np.array(img)

frames = [make_frame(i / fps) for i in range(frames_total)]
writer = imageio.get_writer(out, fps=fps, codec='libx264', quality=7)
for frame in frames:
    writer.append_data(frame)
writer.close()
print(f"Created: {out}")
