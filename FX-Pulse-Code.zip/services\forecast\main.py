from datetime import datetime, timezone
from math import sin
from typing import Optional

import numpy as np
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from statsmodels.tsa.arima.model import ARIMA

app = FastAPI(title="FX Pulse Forecast", version="1.0.0")


class ForecastRequest(BaseModel):
    pair: str = "EUR/USD"
    history: Optional[list[float]] = Field(default=None, min_length=12, max_length=2000)
    steps: int = Field(default=8, ge=1, le=30)


def demo_history(pair: str) -> list[float]:
    seed = sum(ord(char) for char in pair)
    base = {"EUR/USD": 1.0842, "GBP/USD": 1.2716, "USD/JPY": 149.32}.get(pair, 1.0)
    return [base * (1 + 0.003 * sin((index + seed) / 4) + index * 0.000015) for index in range(96)]


@app.get("/health")
def health():
    return {"service": "forecast", "status": "ok"}


@app.post("/api/forecast")
def forecast(request: ForecastRequest):
    values = np.asarray(request.history if request.history else demo_history(request.pair), dtype=float)
    if not np.isfinite(values).all() or np.any(values <= 0):
        raise HTTPException(status_code=400, detail="History must contain positive finite prices.")
    try:
        model = ARIMA(values, order=(1, 1, 0)).fit()
        prediction = model.get_forecast(steps=request.steps)
        mean = prediction.predicted_mean
        interval = prediction.conf_int(alpha=0.2)
        points = [
            {"step": index + 1, "value": round(float(mean[index]), 6), "low": round(float(interval[index][0]), 6), "high": round(float(interval[index][1]), 6)}
            for index in range(request.steps)
        ]
    except (ValueError, np.linalg.LinAlgError) as error:
        raise HTTPException(status_code=422, detail=f"Could not fit ARIMA model: {error}") from error
    direction = "up" if points[-1]["value"] >= values[-1] else "down"
    return {"pair": request.pair, "model": "ARIMA(1,1,0)", "direction": direction, "lastObserved": round(float(values[-1]), 6), "points": points, "generatedAt": datetime.now(timezone.utc).isoformat(), "demoHistory": request.history is None, "disclaimer": "Experimental statistical estimate, not financial advice."}
