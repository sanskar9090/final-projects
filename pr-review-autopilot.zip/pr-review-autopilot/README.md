# PR Review Autopilot

An asynchronous GitHub pull-request review service. A signed GitHub webhook is placed on a
durable Redis Stream, then a LangGraph workflow runs three independent reviewers (style,
correctness, security) concurrently, asks a test-design agent for additional test ideas, and
publishes one deduplicated GitHub review with validated inline comments.

## Workflow

```text
GitHub pull_request webhook
        │ HMAC verification + delivery dedupe
        ▼
     Redis Stream ── consumer group / retry / dead-letter stream
        │
        ├── style review ───────┐
        ├── correctness review ─┼─► test generation ─► validate + post review
        └── security review ────┘
```

Inline findings are only posted when their path exists in the patch, their line is an added
right-side diff line, and their confidence meets `MIN_FINDING_CONFIDENCE`. Reviews carry a
head-SHA marker so re-delivered events do not post duplicates. Stale webhook events are ignored
when the PR head has moved. Large diffs fail explicitly instead of being silently truncated.

## Requirements and launch

- Docker Engine with Docker Compose
- A GitHub App installation token or fine-grained PAT with **Pull requests: read and write**
- An OpenAI API key or a Groq API key
- A public HTTPS endpoint for GitHub webhooks (use a secure tunnel during local development)

```powershell
Copy-Item .env.example .env
# Edit .env: set secrets, provider URL/model, and API token.
docker compose up --build
```

Configure the GitHub webhook URL as `https://YOUR_HOST/webhooks/github`, select the
`pull_request` event, and set the same secret as `GITHUB_WEBHOOK_SECRET`. The service handles
`opened`, `reopened`, `synchronize`, and `ready_for_review`. Check `GET /health` for liveness.

### OpenAI and Groq

OpenAI defaults are provided in `.env.example`. For Groq, set `LLM_BASE_URL` to
`https://api.groq.com/openai/v1`, `LLM_MODEL` to a JSON-mode capable model, and use your Groq key
as `LLM_API_KEY`.

## Configuration

| Variable | Purpose |
| --- | --- |
| `GITHUB_WEBHOOK_SECRET` | HMAC-SHA256 webhook verification secret |
| `GITHUB_TOKEN` | Token with pull request read/write permissions |
| `GITHUB_API_URL` | GitHub API base URL; set to a GitHub Enterprise API URL if needed |
| `LLM_API_KEY` | OpenAI-compatible model provider credential |
| `LLM_BASE_URL`, `LLM_MODEL` | Provider endpoint and model |
| `REDIS_URL` | Redis connection URL |
| `MAX_DIFF_CHARS` | Maximum diff size; oversized changes fail explicitly |
| `MIN_FINDING_CONFIDENCE` | Minimum model confidence for an inline comment |
| `MAX_INLINE_COMMENTS` | Cap on comments in a single review |
| `WORKER_CONCURRENCY` | Concurrent Redis event deliveries per service instance |

## Operations and safeguards

- GitHub requests honor rate-limit/`Retry-After` headers and retry safe reads with bounded
  exponential backoff. Review writes are retried only for explicit rate limiting.
- Redis Streams provide durable enqueueing and a consumer group. Transient processing errors are
  retried three times; exhausted events are retained in `pr-review:dead-letter`.
- Webhook delivery IDs are deduplicated for seven days.
- Never commit `.env`; rotate any token exposed in logs or source control.
- Grant only the repository permissions required for pull request reads and review writes.
- Model output is treated as untrusted input and validated before posting; this tool does not
  merge PRs or execute suggested tests.

## Local checks

```powershell
python -m pip install -e ".[dev]"
python -m pytest
ruff check app tests
```
