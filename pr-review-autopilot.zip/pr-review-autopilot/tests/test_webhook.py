import hashlib
import hmac

from app.main import valid_signature


def test_valid_signature_uses_sha256_hmac():
    body = b'{"action":"opened"}'
    signature = "sha256=" + hmac.new(b"test-secret", body, hashlib.sha256).hexdigest()
    assert valid_signature("test-secret", body, signature)
    assert not valid_signature("wrong-secret", body, signature)
    assert not valid_signature("test-secret", body, "sha1=invalid")
    assert not valid_signature("test-secret", body, None)
