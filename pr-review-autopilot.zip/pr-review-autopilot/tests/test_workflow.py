from app.config import Settings
from app.models import AgentFindings, Finding
from app.models import TestPlan as PlanSchema
from app.workflow import ReviewWorkflow


class FakeLLM:
    async def structured(self, system, prompt, response_model):
        if response_model is PlanSchema:
            return PlanSchema(tests=["Check the boundary case"])
        return AgentFindings(
            findings=[
                Finding(
                    path="src/example.py",
                    line=2,
                    title="Handle the empty value",
                    body="This branch can receive an empty value and currently raises.",
                    severity="medium",
                    confidence=0.9,
                ),
                Finding(
                    path="src/example.py",
                    line=99,
                    title="Not in this diff",
                    body="This line is outside the changed lines.",
                    severity="low",
                    confidence=0.99,
                ),
            ]
        )


class FakeGitHub:
    def __init__(self):
        self.review = None

    async def pull_request(self, repository, number):
        return {"head": {"sha": "head-sha"}, "draft": False}

    async def pull_request_files(self, repository, number):
        return [
            {
                "filename": "src/example.py",
                "patch": "@@ -1 +1,2 @@\n context\n+new_line = value\n",
            }
        ]

    async def has_review_marker(self, repository, number, marker):
        return False

    async def post_review(self, repository, number, commit_id, body, comments):
        self.review = (commit_id, body, comments)


async def test_graph_posts_only_valid_diff_comments_and_includes_test_plan():
    settings = Settings(github_token="test", llm_api_key="test")
    github = FakeGitHub()
    workflow = ReviewWorkflow(settings, github, FakeLLM())

    await workflow.run("acme/repo", 12, "head-sha")

    assert github.review is not None
    commit_id, body, comments = github.review
    assert commit_id == "head-sha"
    assert "Check the boundary case" in body
    assert len(comments) == 1
    assert comments[0]["line"] == 2
    assert comments[0]["side"] == "RIGHT"
