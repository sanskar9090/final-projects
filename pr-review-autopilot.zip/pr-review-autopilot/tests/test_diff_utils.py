from app.diff_utils import added_lines


def test_added_lines_tracks_context_deletions_and_multiple_hunks():
    patch = """@@ -2,4 +2,5 @@
 context
-removed
+added
 context2
@@ -20,2 +21,3 @@
+another
 context3
"""
    assert added_lines(patch) == {3, 21}


def test_added_lines_ignores_metadata_and_no_newline_marker():
    patch = """+++ b/example.py
@@ -0,0 +1,2 @@
+first
+second
\\ No newline at end of file
"""
    assert added_lines(patch) == {1, 2}


def test_added_lines_handles_source_lines_that_start_with_diff_symbols():
    patch = """@@ -1,2 +1,3 @@
 context
+++ source-plus-prefix
+-- source-minus-prefix
"""
    assert added_lines(patch) == {2, 3}
