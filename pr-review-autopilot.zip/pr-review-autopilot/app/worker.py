import asyncio
import json
import logging
import uuid
from typing import Any

from redis.asyncio import Redis

from app.config import Settings
from app.github import GitHubClient
from app.llm import LLMClient
from app.workflow import ReviewWorkflow

logger = logging.getLogger(__name__)

STREAM = "pr-review:events"
GROUP = "pr-review-workers"
DEAD_LETTER_STREAM = "pr-review:dead-letter"
MAX_DELIVERIES = 3


class ReviewWorker:
    def __init__(self, redis: Redis, settings: Settings):
        self.redis = redis
        self.settings = settings
        self.consumer = f"worker-{uuid.uuid4().hex[:10]}"
        self.github = GitHubClient(settings)
        self.llm = LLMClient(settings)
        self.workflow = ReviewWorkflow(settings, self.github, self.llm)

    async def ensure_group(self) -> None:
        try:
            await self.redis.xgroup_create(STREAM, GROUP, id="0-0", mkstream=True)
        except Exception as exc:
            if "BUSYGROUP" not in str(exc):
                raise

    async def run(self) -> None:
        await self.ensure_group()
        logger.info("Review worker %s started", self.consumer)
        while True:
            reclaimed = await self._claim_pending()
            if reclaimed:
                entries = reclaimed
            else:
                messages = await self.redis.xreadgroup(
                    GROUP, self.consumer, {STREAM: ">"}, count=self.settings.worker_concurrency, block=5000
                )
                entries = messages[0][1] if messages else []
            if not entries:
                continue
            await asyncio.gather(*(self._handle(message_id, fields) for message_id, fields in entries))

    async def _claim_pending(self) -> list[tuple[str, dict[str, Any]]]:
        try:
            result = await self.redis.xautoclaim(
                STREAM, GROUP, self.consumer, min_idle_time=60_000, start_id="0-0", count=1
            )
        except Exception as exc:
            if "unknown command" in str(exc).lower():
                logger.warning("Redis lacks XAUTOCLAIM; pending events require operator recovery")
                return []
            raise
        return result[1] if result and len(result) > 1 else []

    async def _handle(self, message_id: str, fields: dict[str, Any]) -> None:
        payload = fields.get("payload")
        if isinstance(payload, bytes):
            payload = payload.decode("utf-8")
        try:
            event = json.loads(payload)
            for attempt in range(1, MAX_DELIVERIES + 1):
                try:
                    await self.workflow.run(
                        event["repository"], int(event["pull_number"]), event["head_sha"]
                    )
                    await self.redis.xack(STREAM, GROUP, message_id)
                    return
                except Exception:
                    logger.exception(
                        "Review failed for %s#%s (attempt %s/%s)",
                        event.get("repository"),
                        event.get("pull_number"),
                        attempt,
                        MAX_DELIVERIES,
                    )
                    if attempt < MAX_DELIVERIES:
                        await asyncio.sleep(attempt * 2)
            await self.redis.xadd(
                DEAD_LETTER_STREAM,
                {"payload": payload, "error": "review failed after retry budget"},
            )
            await self.redis.xack(STREAM, GROUP, message_id)
            logger.error("Moved review event %s to %s", message_id, DEAD_LETTER_STREAM)
        except (KeyError, TypeError, ValueError, json.JSONDecodeError):
            logger.exception("Malformed review event %s", message_id)
            await self.redis.xadd(
                DEAD_LETTER_STREAM,
                {"payload": str(payload), "error": "malformed review event"},
            )
            await self.redis.xack(STREAM, GROUP, message_id)

    async def close(self) -> None:
        await self.github.close()
        await self.llm.close()
