import asyncio
import logging
import time
from typing import Any

import httpx

from app.config import Settings

logger = logging.getLogger(__name__)


class GitHubClient:
    def __init__(self, settings: Settings):
        self.api_url = settings.github_api_url.rstrip("/")
        self.client = httpx.AsyncClient(
            headers={
                "Authorization": f"Bearer {settings.github_token}",
                "Accept": "application/vnd.github+json",
                "X-GitHub-Api-Version": "2022-11-28",
            },
            timeout=httpx.Timeout(30, connect=10),
        )

    async def _request(self, method: str, path: str, **kwargs: Any) -> httpx.Response:
        url = f"{self.api_url}{path}"
        for attempt in range(5):
            response = await self.client.request(method, url, **kwargs)
            limited = response.status_code == 429 or (
                response.status_code == 403
                and ("retry-after" in response.headers or response.headers.get("x-ratelimit-remaining") == "0")
            )
            transient = response.status_code in {500, 502, 503, 504}
            retry_safe = method in {"GET", "HEAD"} or limited
            if (limited or transient) and retry_safe and attempt < 4:
                retry_after = response.headers.get("retry-after")
                reset_at = response.headers.get("x-ratelimit-reset")
                if retry_after:
                    delay = float(retry_after)
                elif limited and reset_at:
                    delay = max(1, float(reset_at) - time.time())
                else:
                    delay = min(2**attempt, 16)
                logger.warning("GitHub API throttled/transient response; retrying in %.1fs", delay)
                await response.aclose()
                await asyncio.sleep(min(delay, 60))
                continue
            response.raise_for_status()
            return response
        raise RuntimeError(f"GitHub API retry budget exhausted for {method} {path}")

    async def pull_request(self, repository: str, number: int) -> dict[str, Any]:
        response = await self._request("GET", f"/repos/{repository}/pulls/{number}")
        return response.json()

    async def pull_request_files(self, repository: str, number: int) -> list[dict[str, Any]]:
        files: list[dict[str, Any]] = []
        page = 1
        while True:
            response = await self._request(
                "GET",
                f"/repos/{repository}/pulls/{number}/files",
                params={"per_page": 100, "page": page},
            )
            current = response.json()
            files.extend(current)
            if len(current) < 100:
                return files
            page += 1

    async def has_review_marker(self, repository: str, number: int, marker: str) -> bool:
        page = 1
        while True:
            response = await self._request(
                "GET",
                f"/repos/{repository}/pulls/{number}/reviews",
                params={"per_page": 100, "page": page},
            )
            reviews = response.json()
            if any(marker in (review.get("body") or "") for review in reviews):
                return True
            if len(reviews) < 100:
                return False
            page += 1

    async def post_review(
        self,
        repository: str,
        number: int,
        commit_id: str,
        body: str,
        comments: list[dict[str, Any]],
    ) -> None:
        await self._request(
            "POST",
            f"/repos/{repository}/pulls/{number}/reviews",
            json={"commit_id": commit_id, "body": body, "event": "COMMENT", "comments": comments},
        )

    async def close(self) -> None:
        await self.client.aclose()
