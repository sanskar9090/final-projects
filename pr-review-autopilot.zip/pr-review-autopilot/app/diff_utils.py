import re

HUNK_HEADER = re.compile(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@")


def added_lines(patch: str) -> set[int]:
    """Return new-side line numbers that were added and can safely receive inline comments."""
    result: set[int] = set()
    new_line: int | None = None
    for line in patch.splitlines():
        match = HUNK_HEADER.match(line)
        if match:
            new_line = int(match.group(1))
            continue
        if new_line is None or line.startswith("\\ No newline"):
            continue
        if line.startswith("+"):
            result.add(new_line)
            new_line += 1
        elif line.startswith("-"):
            continue
        else:
            new_line += 1
    return result


def format_diff(patches: dict[str, str]) -> str:
    return "\n\n".join(f"FILE: {path}\n{patch}" for path, patch in patches.items())
