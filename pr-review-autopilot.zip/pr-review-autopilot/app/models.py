from typing import Literal, TypedDict

from pydantic import BaseModel, Field


class Finding(BaseModel):
    path: str = Field(min_length=1)
    line: int = Field(ge=1)
    title: str = Field(min_length=1, max_length=120)
    body: str = Field(min_length=1, max_length=5000)
    severity: Literal["critical", "high", "medium", "low"]
    confidence: float = Field(ge=0, le=1)


class AgentFindings(BaseModel):
    findings: list[Finding] = Field(default_factory=list)


class TestPlan(BaseModel):
    tests: list[str] = Field(default_factory=list, max_length=12)


class ReviewState(TypedDict, total=False):
    repository: str
    pull_number: int
    expected_head_sha: str
    patches: dict[str, str]
    findings: list[Finding]
    tests: list[str]

