import asyncio
import hashlib
import hmac
import json
import logging
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, Header, HTTPException, Request
from redis.asyncio import Redis

from app.config import get_settings
from app.worker import STREAM, ReviewWorker

settings = get_settings()
logging.basicConfig(level=settings.log_level.upper())
logger = logging.getLogger(__name__)

SUPPORTED_ACTIONS = {"opened", "reopened", "synchronize", "ready_for_review"}


@asynccontextmanager
async def lifespan(app: FastAPI):
    missing = [
        name
        for name, value in (
            ("GITHUB_WEBHOOK_SECRET", settings.github_webhook_secret),
            ("GITHUB_TOKEN", settings.github_token),
            ("LLM_API_KEY", settings.llm_api_key),
        )
        if not value
    ]
    if missing:
        raise RuntimeError(f"Required environment variables are missing: {', '.join(missing)}")
    redis = Redis.from_url(settings.redis_url, decode_responses=True)
    await redis.ping()
    worker = ReviewWorker(redis, settings)
    app.state.redis = redis
    app.state.worker = worker
    worker_task = asyncio.create_task(worker.run(), name="pull-request-review-worker")
    try:
        yield
    finally:
        worker_task.cancel()
        try:
            await worker_task
        except asyncio.CancelledError:
            pass
        await worker.close()
        await redis.aclose()


app = FastAPI(title="PR Review Autopilot", version="0.1.0", lifespan=lifespan)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


def valid_signature(secret: str, body: bytes, signature: str | None) -> bool:
    if not signature or not signature.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


@app.post("/webhooks/github", status_code=202)
async def github_webhook(
    request: Request,
    x_github_event: str | None = Header(default=None),
    x_github_delivery: str | None = Header(default=None),
    x_hub_signature_256: str | None = Header(default=None),
) -> dict[str, Any]:
    body = await request.body()
    if not valid_signature(settings.github_webhook_secret, body, x_hub_signature_256):
        raise HTTPException(status_code=401, detail="Invalid webhook signature")
    if not x_github_delivery:
        raise HTTPException(status_code=400, detail="Missing X-GitHub-Delivery header")
    if x_github_event != "pull_request":
        return {"status": "ignored", "reason": "unsupported event"}
    try:
        payload = json.loads(body)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail="Malformed JSON payload") from exc

    action = payload.get("action")
    pull_request = payload.get("pull_request") or {}
    if action not in SUPPORTED_ACTIONS or pull_request.get("draft"):
        return {"status": "ignored", "reason": "unsupported action or draft pull request"}
    repository = (payload.get("repository") or {}).get("full_name")
    number = payload.get("number")
    head_sha = (pull_request.get("head") or {}).get("sha")
    if not repository or not isinstance(number, int) or not head_sha:
        raise HTTPException(status_code=400, detail="Missing repository, pull request number, or head SHA")

    redis: Redis = request.app.state.redis
    dedupe_key = f"webhook-delivery:{x_github_delivery}"
    if not await redis.set(dedupe_key, "1", nx=True, ex=7 * 24 * 60 * 60):
        return {"status": "duplicate"}
    event = {"repository": repository, "pull_number": number, "head_sha": head_sha}
    try:
        await redis.xadd(STREAM, {"payload": json.dumps(event, separators=(",", ":"))})
    except Exception:
        await redis.delete(dedupe_key)
        logger.exception("Could not enqueue GitHub delivery %s", x_github_delivery)
        raise HTTPException(status_code=503, detail="Review queue unavailable")
    return {"status": "queued"}
