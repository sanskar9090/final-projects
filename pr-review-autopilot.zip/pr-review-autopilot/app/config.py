from functools import lru_cache

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    github_webhook_secret: str = ""
    github_token: str = ""
    github_api_url: str = "https://api.github.com"
    llm_api_key: str = ""
    llm_base_url: str = "https://api.openai.com/v1"
    llm_model: str = "gpt-4o-mini"
    redis_url: str = "redis://localhost:6379/0"
    max_diff_chars: int = Field(default=60_000, ge=1_000, le=500_000)
    min_finding_confidence: float = Field(default=0.65, ge=0, le=1)
    max_inline_comments: int = Field(default=50, ge=1, le=100)
    worker_concurrency: int = Field(default=3, ge=1, le=20)
    log_level: str = "INFO"


@lru_cache
def get_settings() -> Settings:
    return Settings()
