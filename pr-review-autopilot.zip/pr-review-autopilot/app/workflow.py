import json
import logging
import operator
from typing import Annotated, Any, TypedDict

from langgraph.graph import END, START, StateGraph

from app.config import Settings
from app.diff_utils import added_lines, format_diff
from app.github import GitHubClient
from app.llm import LLMClient
from app.models import AgentFindings, Finding, TestPlan
from app.prompts import (
    CORRECTNESS_PROMPT,
    REVIEW_SYSTEM,
    SECURITY_PROMPT,
    STYLE_PROMPT,
    TESTS_PROMPT,
    TESTS_SYSTEM,
)

logger = logging.getLogger(__name__)


class GraphState(TypedDict, total=False):
    repository: str
    pull_number: int
    expected_head_sha: str
    patches: dict[str, str]
    findings: Annotated[list[Finding], operator.add]
    tests: list[str]


class ReviewWorkflow:
    def __init__(self, settings: Settings, github: GitHubClient, llm: LLMClient):
        self.settings = settings
        self.github = github
        self.llm = llm

        async def review_node(
            state: GraphState, prompt_template: str
        ) -> dict[str, list[Finding]]:
            result = await self.llm.structured(
                REVIEW_SYSTEM,
                prompt_template.format(diff=format_diff(state["patches"])),
                AgentFindings,
            )
            return {"findings": result.findings}

        async def style_node(state: GraphState) -> dict[str, list[Finding]]:
            return await review_node(state, STYLE_PROMPT)

        async def correctness_node(state: GraphState) -> dict[str, list[Finding]]:
            return await review_node(state, CORRECTNESS_PROMPT)

        async def security_node(state: GraphState) -> dict[str, list[Finding]]:
            return await review_node(state, SECURITY_PROMPT)

        async def test_node(state: GraphState) -> dict[str, list[str]]:
            result = await self.llm.structured(
                TESTS_SYSTEM,
                TESTS_PROMPT.format(
                    diff=format_diff(state["patches"]),
                    findings=json.dumps([item.model_dump() for item in state.get("findings", [])]),
                ),
                TestPlan,
            )
            return {"tests": result.tests}

        async def publish_node(state: GraphState) -> dict[str, Any]:
            await self._publish(state)
            return {}

        graph = StateGraph(GraphState)
        graph.add_node("style_review", style_node)
        graph.add_node("correctness_review", correctness_node)
        graph.add_node("security_review", security_node)
        graph.add_node("test_generation", test_node)
        graph.add_node("publish_review", publish_node)
        graph.add_edge(START, "style_review")
        graph.add_edge(START, "correctness_review")
        graph.add_edge(START, "security_review")
        graph.add_edge(["style_review", "correctness_review", "security_review"], "test_generation")
        graph.add_edge("test_generation", "publish_review")
        graph.add_edge("publish_review", END)
        self.graph = graph.compile()

    async def run(self, repository: str, pull_number: int, expected_head_sha: str) -> None:
        pr = await self.github.pull_request(repository, pull_number)
        actual_sha = pr["head"]["sha"]
        if actual_sha != expected_head_sha:
            logger.info(
                "Skipping stale review for %s#%s (event=%s, current=%s)",
                repository,
                pull_number,
                expected_head_sha,
                actual_sha,
            )
            return
        if pr.get("draft"):
            logger.info("Skipping draft pull request %s#%s", repository, pull_number)
            return
        marker = f"<!-- pr-review-autopilot:{expected_head_sha} -->"
        if await self.github.has_review_marker(repository, pull_number, marker):
            logger.info("Review already exists for %s#%s at %s", repository, pull_number, expected_head_sha)
            return

        files = await self.github.pull_request_files(repository, pull_number)
        patches = {item["filename"]: item["patch"] for item in files if item.get("patch")}
        diff = format_diff(patches)
        if not diff:
            logger.info("No text diff to review for %s#%s", repository, pull_number)
            return
        if len(diff) > self.settings.max_diff_chars:
            raise ValueError(
                f"Diff has {len(diff)} characters, exceeding MAX_DIFF_CHARS="
                f"{self.settings.max_diff_chars}; review was not partially submitted"
            )

        await self.graph.ainvoke(
            {
                "repository": repository,
                "pull_number": pull_number,
                "expected_head_sha": expected_head_sha,
                "patches": patches,
                "findings": [],
                "tests": [],
            }
        )

    async def _publish(self, state: GraphState) -> None:
        repository = state["repository"]
        number = state["pull_number"]
        sha = state["expected_head_sha"]
        marker = f"<!-- pr-review-autopilot:{sha} -->"
        if await self.github.has_review_marker(repository, number, marker):
            logger.info("Review already exists for %s#%s at %s", repository, number, sha)
            return

        patches = state["patches"]
        changed_lines = {path: added_lines(patch) for path, patch in patches.items()}
        findings = self._deduplicate_findings(state.get("findings", []))
        inline: list[dict[str, Any]] = []
        skipped = 0
        for finding in findings:
            if (
                finding.confidence < self.settings.min_finding_confidence
                or finding.path not in changed_lines
                or finding.line not in changed_lines[finding.path]
            ):
                skipped += 1
                continue
            inline.append(
                {
                    "path": finding.path,
                    "line": finding.line,
                    "side": "RIGHT",
                    "body": (
                        f"**{finding.severity.upper()} — {finding.title}**\n\n"
                        f"{finding.body}\n\n"
                        f"_Agent confidence: {finding.confidence:.0%}_"
                    ),
                }
            )
        inline.sort(key=lambda item: (item["path"], item["line"]))
        overflow = max(0, len(inline) - self.settings.max_inline_comments)
        inline = inline[: self.settings.max_inline_comments]
        summary = [
            "## Automated pull request review",
            "",
            (
                f"Specialists reviewed this change for style, correctness, and security. "
                f"Test ideas generated: {len(state.get('tests', []))}."
            ),
        ]
        if overflow:
            summary.append(f"{overflow} additional inline finding(s) omitted due to the configured limit.")
        if skipped:
            summary.append(
                f"{skipped} finding(s) were omitted because confidence was low or the line was not "
                "an added line in this diff."
            )
        tests = state.get("tests", [])
        if tests:
            summary.extend(["", "### Suggested tests"])
            summary.extend(f"- {test}" for test in tests)
        summary.extend(["", marker])
        await self.github.post_review(repository, number, sha, "\n".join(summary), inline)

    @staticmethod
    def _deduplicate_findings(findings: list[Finding]) -> list[Finding]:
        distinct: dict[tuple[str, int, str], Finding] = {}
        for finding in findings:
            key = (finding.path, finding.line, finding.title.casefold())
            current = distinct.get(key)
            if current is None or finding.confidence > current.confidence:
                distinct[key] = finding
        return list(distinct.values())
